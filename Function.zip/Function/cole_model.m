function Z = cole_model(params, f)
    R_inf = params(1);
    R_0 = params(2);
    f_c = params(3);
    alpha = params(4);
    
    Z = R_inf + (R_0 - R_inf) ./ (1 + (1i*f/f_c).^(1-alpha));
    
    % 返回实部和虚部
    Z = [real(Z); imag(Z)];
end
