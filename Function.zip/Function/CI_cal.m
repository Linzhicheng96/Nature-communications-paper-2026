function [ci_low, ci_high] = CI_cal(data)
    % 样本信息
    n = length(data);
    mu = mean(data);
    sigma = std(data); % 样本标准差
    
    % t值（因为样本数量少，用 t 分布）
    t = tinv(0.975, n-1); % 95% CI => alpha/2 = 0.025
    
    % CI 计算
    ci_low = mu - t * sigma / sqrt(n);
    ci_high = mu + t * sigma / sqrt(n);
end