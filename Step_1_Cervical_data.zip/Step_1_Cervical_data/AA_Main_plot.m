clc
clear
clf
%% load data ---------------------------------------------------------------------------------------------------------
% Group 1
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_Cancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_NonCancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_cancer_data_and_info.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_non_cancer_data_and_info.mat')
% Group 2
load('../../data/cervical data London/postprocessed_by_Lin/Cervical_Group_2_coleModel_MaxDiffMean_112.mat')
%% data filtering ----------------------------------------------------------------------------------------------------
%% Group 2
G2_cancer          = cat(2,Cervical_Group_2_cancer_MeanValues,          Cervical_Group_2_cancer_MaxDiff);
G2_non_cancer = cat(2,Cervical_Group_2_non_cancer_MeanValues,Cervical_Group_2_non_cancer_MaxDiff);
X_test_Group_2 = cat(1,G2_non_cancer,G2_cancer);
Y_test_Group_2 = cat(1,zeros(93,1),        ones(19,1));
Group_2_Colp_info     =cat(1,Cervical_Group_2_non_cancer_info.Colp,    Cervical_Group_2_cancer_info.Colp);
Group_2_Smear_info  =cat(1,Cervical_Group_2_non_cancer_info.Smear,Cervical_Group_2_cancer_info.Smear);
Colp_info_test_London = Group_2_Colp_info;
Smear_info_test_London = Group_2_Smear_info;
%% Group 1
G1_cancer          = cat(2,Cervical_Group_1_cancer_MeanValues,          Cervical_Group_1_cancer_MaxDiff);
G1_non_cancer = cat(2,Cervical_Group_1_non_cancer_MeanValues,Cervical_Group_1_non_cancer_MaxDiff);

%% ----------------------------------------------------------------------------------------------------------------------
% the best pair of hyper-para
MaxNumSplits_set = 15;
MinParentSize_set = 15;
MinLeafSize_set = 5;

AAA_FINAL_METRICS_SAVE = zeros(100,9);
%  AUC_test,                                    specificity_test,                    sensitivity_test,
%  AUC_test_add_Bayes_G1,       specificity_test_G1,             sensitivity_test_G1,
%  AUC_test_add_Bayes_G2,       specificity_test_G2,             sensitivity_test_G2,

for seed_nn = 4
    fprintf('the round is in %d \n',seed_nn);
    rng(seed_nn);index_record_line = 1;

    %% split the data Group1  to training and testing dataset --------------------------------------------------------------------------------------------------------------------
    % cancer data 528             vali and test      428:100
    % non cancer data 1149   vali and test      949:200
    indices_1 = randperm(528);
    Indices_train_1 = indices_1(1:428);
    Indices_test_1 = indices_1(429:end);
    
    cancer_data_train                 = G1_cancer(Indices_train_1,:);
    cancer_data_test                  =  G1_cancer(Indices_test_1,:);
    cancer_data_train_colp      = Cervical_Group_1_cancer_info.Colp_list(Indices_train_1);
    cancer_data_test_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_test_1);
    cancer_data_train_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_train_1);
    cancer_data_test_smear   = Cervical_Group_1_cancer_info.Smear_list(Indices_test_1);
    
    indices_0 = randperm(1149);
    Indices_train_0 = indices_0(1:949);
    Indices_test_0 = indices_0(950:end);
    
    non_cancer_data_train             = G1_non_cancer(Indices_train_0,:);
    non_cancer_data_test               = G1_non_cancer(Indices_test_0,:);
    non_cancer_data_train_colp    = Cervical_Group_1_non_cancer_info.Colp_list(Indices_train_0);
    non_cancer_data_test_colp      = Cervical_Group_1_non_cancer_info.Colp_list(Indices_test_0);
    non_cancer_data_train_smear = Cervical_Group_1_non_cancer_info.Smear_list(Indices_train_0);
    non_cancer_data_test_smear   = Cervical_Group_1_non_cancer_info.Smear_list(Indices_test_0);
    
    
    X_train = cat(1,non_cancer_data_train ,cancer_data_train); 
    Y_train = cat(1,zeros(949,1),ones(428,1));
    X_test = cat(1,non_cancer_data_test ,cancer_data_test);       
    Y_test = cat(1,zeros(200,1),ones(100,1));
    
    Colp_info_train = cat(1,non_cancer_data_train_colp,cancer_data_train_colp);
    Colp_info_test = cat(1,non_cancer_data_test_colp,cancer_data_test_colp);
    Smear_info_train = cat(1,non_cancer_data_train_smear,cancer_data_train_smear);
    Smear_info_test = cat(1,non_cancer_data_test_smear,cancer_data_test_smear);
    
    
    %% grid search----------------------------------------------------------------------------------------------------------------------

    treeModel = fitctree(X_train, Y_train,'MaxNumSplits',MaxNumSplits_set,'MinParentSize',MinParentSize_set,'MinLeafSize',MinLeafSize_set);

    [Y_pred_train,score_train] = predict(treeModel, X_train);
    [Y_pred_test,score_test]    = predict(treeModel, X_test);
    [Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);

    [x_G1, y_G1, T_, AUC_test] = perfcurve(Y_test, score_test(:,2), 1);
    [x_G2, y_G2, T_, AUC_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);

    %% ------------------------------------------------------------------------------------------------
    %% step 1
    % find the best threshold based on training data
    % to make the Yuden score on the training results to be the best
    % J = Sensitivity + Specificity -1
    [threshold_best_final, training_specificity_final ,training_sensitivity_final] = threshold_selection(score_train(:,2), Y_train);
    
    %% ------------------------------------------------------------------------------------------------
    %% step 3
    %% calculate the metics on testing set  for Group 1
    [accuracy_test,recall_test ,specificity_test,sensitivity_test] = ConfusionMatrix_cal(score_test(:,2),threshold_best_final,Y_test);
    %% calculate the metics on testing set  for Group 2 from London
    [accuracy_test_London,recall_test_London ,specificity_test_London,sensitivity_test_London] = ConfusionMatrix_cal(score_test_London(:,2),threshold_best_final,Y_test_Group_2);
                   
    %% step 4
    % considering the prior knowledge
    %% 4.1 calculate the prob of each dignosis statistics
    % -----------------------------------------------------------------------------------------------
    % only colp
    
    Train_HG_1_colp_0 = 0;
    Train_HG_1_colp_1 = 0;
    Train_HG_0_colp_0 = 0;
    Train_HG_0_colp_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) 
            Train_HG_1_colp_0 = Train_HG_1_colp_0 +1;
        else
            Train_HG_1_colp_1 = Train_HG_1_colp_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) 
            Train_HG_0_colp_0 = Train_HG_0_colp_0 +1;
        else
            Train_HG_0_colp_1 = Train_HG_0_colp_1 +1;
        end
    end
    
    % -----------------------------------------------------------------------------------------------
    % only smear
    
    Train_HG_1_smear_0 = 0;
    Train_HG_1_smear_1 = 0;
    Train_HG_0_smear_0 = 0;
    Train_HG_0_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_smear(i) == 0) 
            Train_HG_1_smear_0 = Train_HG_1_smear_0 +1;
        else
            Train_HG_1_smear_1 = Train_HG_1_smear_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_smear(i) == 0) 
            Train_HG_0_smear_0 = Train_HG_0_smear_0 +1;
        else
            Train_HG_0_smear_1 = Train_HG_0_smear_1 +1;
        end
    end
    
    
    
    %---------------------------------------------------------------------------------------------------------------
    % colp and smear
    Train_HG_1_colp_0_smear_0 = 0;
    Train_HG_1_colp_0_smear_1 = 0;
    Train_HG_1_colp_1_smear_0 = 0;
    Train_HG_1_colp_1_smear_1 = 0;
    
    Train_HG_0_colp_0_smear_0 = 0;
    Train_HG_0_colp_0_smear_1 = 0;
    Train_HG_0_colp_1_smear_0 = 0;
    Train_HG_0_colp_1_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_0_smear_0 = Train_HG_1_colp_0_smear_0 +1;
    
        elseif (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 1)
            Train_HG_1_colp_0_smear_1 = Train_HG_1_colp_0_smear_1 +1;
    
        elseif (cancer_data_train_colp(i) == 1) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_1_smear_0 = Train_HG_1_colp_1_smear_0 +1;
    
        else
            Train_HG_1_colp_1_smear_1 = Train_HG_1_colp_1_smear_1 +1;
          
        end
    end
    
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_0_smear_0 = Train_HG_0_colp_0_smear_0 +1;
    
        elseif (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 1)
            Train_HG_0_colp_0_smear_1 = Train_HG_0_colp_0_smear_1 +1;
    
        elseif (non_cancer_data_train_colp(i) == 1) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_1_smear_0 = Train_HG_0_colp_1_smear_0 +1;
    
        else
            Train_HG_0_colp_1_smear_1 = Train_HG_0_colp_1_smear_1 +1;
          
        end
    end
        
    %% 4.2 calculate the prob of each dignosis
    % ---------------------------------------------------------------------------------------------------------------
    %% colp
    % colp 0 
    p_h_colp_0 = Train_HG_1_colp_0 / (Train_HG_1_colp_0 + Train_HG_0_colp_0);
    % colp 1
    p_h_colp_1 = Train_HG_1_colp_1/ (Train_HG_1_colp_1 + Train_HG_0_colp_1);
    
    % ---------------------------------------------------------------------------------------------------------------
    %% smear
    % smear 0 
    p_h_smear_0 = Train_HG_1_smear_0 / (Train_HG_1_smear_0 + Train_HG_0_smear_0);
    % smear 1
    p_h_smear_1 = Train_HG_1_smear_1/ (Train_HG_1_smear_1 + Train_HG_0_smear_1);
    
    
    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    %% colp 0 smear 0
    p_h_colp_smear_00 = Train_HG_1_colp_0_smear_0 / (Train_HG_1_colp_0_smear_0 + Train_HG_0_colp_0_smear_0);
    % colp 0 smear 1
    p_h_colp_smear_01 = Train_HG_1_colp_0_smear_1 / (Train_HG_1_colp_0_smear_1 + Train_HG_0_colp_0_smear_1);
    % colp 1 smear 0
    p_h_colp_smear_10 = Train_HG_1_colp_1_smear_0 / (Train_HG_1_colp_1_smear_0 + Train_HG_0_colp_1_smear_0);
    % colp 1 smear 1
    p_h_colp_smear_11 = Train_HG_1_colp_1_smear_1 / (Train_HG_1_colp_1_smear_1 + Train_HG_0_colp_1_smear_1); 


    %% step 5
    % calculate
    % for testing data
    AA_prediction_results_with_bayes_colp_smear  = zeros(size(Y_test,1),1);


    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    for i=1:size(Y_test,1)
        if (score_test(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_test(i)==1)&&(Smear_info_test(i)==1) %  colp =1 smear 1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
                    
            if (Colp_info_test(i)==1)&&(Smear_info_test(i)==0) %  colp =1 smear 0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test(i)==0)&&(Smear_info_test(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test(i)==0)&&(Smear_info_test(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
    
        end
    
        if (score_test(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_test(i)==1)&&(Smear_info_test(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
             if (Colp_info_test(i)==1)&&(Smear_info_test(i)==0) %  colp =0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
    
             if (Colp_info_test(i)==0)&&(Smear_info_test(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
            if (Colp_info_test(i)==0)&&(Smear_info_test(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
        end
    end

    [x_G1_b, y_G1_b, T_, AUC_test_add_Bayes_colp_smear] = perfcurve(Y_test, AA_prediction_results_with_bayes_colp_smear, 1);

    % for gourp 2 data from London
    AA_prediction_results_with_bayes_colp_smear_London = zeros(112,1);

    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    for i=1:size(Y_test_Group_2,1)
        if (score_test_London(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==1) %  colp =1 smear 1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
                    
            if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==0) %  colp =1 smear 0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
    
        if (score_test_London(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
             if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==0) %  colp =0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
    
             if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
            if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
        end
    end

    [x_G2_b, y_G2_b, T_, AUC_test_add_Bayes_colp_smear_London] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_colp_smear_London, 1);






    %% Step 6
    % Bayes results in Training dataset
    % using prior on training results (Y_pred_train,   score_train )
    % and using threshold selection method to find the best threshold on Training 

    AA_prediction_results_with_bayes_colp_smear_train = zeros(1377,1);
    %% step 6.1 calulate the training results processed by prior knowledge
    % colp and smear
    for i=1:size(Y_train,1)
        if (score_train(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_train(i)==1)&&(Smear_info_train(i)==1) %  colp =1 smear 1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
                    
            if (Colp_info_train(i)==1)&&(Smear_info_train(i)==0) %  colp =1 smear 0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_train(i)==0)&&(Smear_info_train(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_train(i)==0)&&(Smear_info_train(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
    
        if (score_train(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_train(i)==1)&&(Smear_info_train(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
             if (Colp_info_train(i)==1)&&(Smear_info_train(i)==0) %  colp =0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
    
             if (Colp_info_train(i)==0)&&(Smear_info_train(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
            if (Colp_info_train(i)==0)&&(Smear_info_train(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
        end
    end
    %% Step 6.2 
    %% choose the best threshold from Bayes
    score_train_Bayes_Colp_Smear = AA_prediction_results_with_bayes_colp_smear_train;
    % find the best threshold on training curves when using prior knowledge
    [threshold_best_final_train_Bayes_Colp_Smear, nono , nono] = threshold_selection(score_train_Bayes_Colp_Smear, Y_train);

    [accuracy_test_Colp_Smear,recall_test_Colp_Smear,specificity_test_Colp_Smear,sensitivity_test_Colp_Smear]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_colp_smear,threshold_best_final_train_Bayes_Colp_Smear,Y_test);
    [accuracy_test_Colp_Smear_London,recall_test_Colp_Smear_London,specificity_test_Colp_Smear_London,sensitivity_test_Colp_Smear_London]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_colp_smear_London,threshold_best_final_train_Bayes_Colp_Smear,Y_test_Group_2);

    AAA_FINAL_METRICS_SAVE(seed_nn,1:3) = [AUC_test,specificity_test,sensitivity_test] ;
    AAA_FINAL_METRICS_SAVE(seed_nn,4:6) = [AUC_test_add_Bayes_colp_smear,specificity_test_Colp_Smear,sensitivity_test_Colp_Smear];
    AAA_FINAL_METRICS_SAVE(seed_nn,7:9) = [AUC_test_London,specificity_test_London,sensitivity_test_London];
    AAA_FINAL_METRICS_SAVE(seed_nn,10:12) = [AUC_test_add_Bayes_colp_smear_London, specificity_test_Colp_Smear_London, sensitivity_test_Colp_Smear_London];


end
AAA_compare = [];
%% calculate the CI mean and std value
for i =1:12
     [mean_val,std_val,ci_lower,ci_upper] = CI_cal(AAA_FINAL_METRICS_SAVE(:,i));
     AAA_compare(i,1) = mean_val;
     AAA_compare(i,2) = std_val;
     AAA_compare(i,3) = ci_lower;
     AAA_compare(i,4) = ci_upper;
end
%%
[Y_pred_train,score_train] = predict(treeModel, X_train);
[Y_pred_test,score_test]    = predict(treeModel, X_test);
[Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);
[x_train, y_train, T_train, AUC_train, theop_train] = perfcurve(Y_train, score_train(:,2), 1);
[x_G1, y_G1, T_G1, AUC_test,theop_test] = perfcurve(Y_test, score_test(:,2), 1);
[x_G1_b, y_G1_b, T_, AUC_test_add_Bayes_colp_smear,theop_test_b] = perfcurve(Y_test, AA_prediction_results_with_bayes_colp_smear, 1);
[x_G2, y_G2, T_G2, AUC_test_London,theop_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);
[x_G2_b, y_G2_b, T_, AUC_test_add_Bayes_colp_smear_London,theop_test_London_b] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_colp_smear_London, 1);
%% for plotting
color_1 = '[ 0 0.78 0.55]';
color_2 = '[0.25 0.41 0.88]';
color_3 = '[1 0.6 0]';
%% for group 1
figure(1);subplot(4,4,1)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G1,y_G1,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G1_b, y_G1_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_b(1),theop_test_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_colp_smear,threshold_best_final_train_Bayes_Colp_Smear,Y_test);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group1 ROC (DT)');legend([p_1,p_2],'Test results','Test results (PK)')

%% for group 2
figure(2);subplot(4,4,1)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G2,y_G2,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G2_b, y_G2_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_London_b(1),theop_test_London_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_colp_smear_London, threshold_best_final_train_Bayes_Colp_Smear, Y_test_Group_2);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group2 ROC (DT)');legend([p_1,p_2],'Test results','Test results (PK)')


%% ----------------------------------------------------------------------------------------------------------------------
%% ----------------------------------------------------------------------------------------------------------------------
clc
clear
%% load data ---------------------------------------------------------------------------------------------------------
% Group 1
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_Cancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_NonCancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_cancer_data_and_info.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_non_cancer_data_and_info.mat')
% Group 2
load('../../data/cervical data London/postprocessed_by_Lin/Cervical_Group_2_coleModel_MaxDiffMean_112.mat')
%% data filtering ----------------------------------------------------------------------------------------------------
%% Group 2
G2_cancer          = cat(2,Cervical_Group_2_cancer_MeanValues,          Cervical_Group_2_cancer_MaxDiff);
G2_non_cancer = cat(2,Cervical_Group_2_non_cancer_MeanValues,Cervical_Group_2_non_cancer_MaxDiff);
X_test_Group_2 = cat(1,G2_non_cancer,G2_cancer);
Y_test_Group_2 = cat(1,zeros(93,1),        ones(19,1));
Group_2_Colp_info     =cat(1,Cervical_Group_2_non_cancer_info.Colp,    Cervical_Group_2_cancer_info.Colp);
Group_2_Smear_info  =cat(1,Cervical_Group_2_non_cancer_info.Smear,Cervical_Group_2_cancer_info.Smear);
Colp_info_test_London = Group_2_Colp_info;
Smear_info_test_London = Group_2_Smear_info;
%% Group 1
G1_cancer          = cat(2,Cervical_Group_1_cancer_MeanValues,          Cervical_Group_1_cancer_MaxDiff);
G1_non_cancer = cat(2,Cervical_Group_1_non_cancer_MeanValues,Cervical_Group_1_non_cancer_MaxDiff);

%% ----------------------------------------------------------------------------------------------------------------------
% the best pair of hyper-para
NumTrees_set = 60;
MinLeafSize_set  = 20;
MaxNumSplits_set  = 15;

AAA_FINAL_METRICS_SAVE = zeros(100,9);
%  AUC_test,                                    specificity_test,                    sensitivity_test,
%  AUC_test_add_Bayes_G1,       specificity_test_G1,             sensitivity_test_G1,
%  AUC_test_add_Bayes_G2,       specificity_test_G2,             sensitivity_test_G2,

for seed_nn = 5
    fprintf('the round is in %d \n',seed_nn);
    rng(seed_nn);index_record_line = 1;

    %% split the data Group1  to training and testing dataset --------------------------------------------------------------------------------------------------------------------
    % cancer data 528             vali and test      428:100
    % non cancer data 1149   vali and test      949:200
    indices_1 = randperm(528);
    Indices_train_1 = indices_1(1:428);
    Indices_test_1 = indices_1(429:end);
    
    cancer_data_train                 = G1_cancer(Indices_train_1,:);
    cancer_data_test                  =  G1_cancer(Indices_test_1,:);
    cancer_data_train_colp      = Cervical_Group_1_cancer_info.Colp_list(Indices_train_1);
    cancer_data_test_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_test_1);
    cancer_data_train_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_train_1);
    cancer_data_test_smear   = Cervical_Group_1_cancer_info.Smear_list(Indices_test_1);
    
    indices_0 = randperm(1149);
    Indices_train_0 = indices_0(1:949);
    Indices_test_0 = indices_0(950:end);
    
    non_cancer_data_train             = G1_non_cancer(Indices_train_0,:);
    non_cancer_data_test               = G1_non_cancer(Indices_test_0,:);
    non_cancer_data_train_colp    = Cervical_Group_1_non_cancer_info.Colp_list(Indices_train_0);
    non_cancer_data_test_colp      = Cervical_Group_1_non_cancer_info.Colp_list(Indices_test_0);
    non_cancer_data_train_smear = Cervical_Group_1_non_cancer_info.Smear_list(Indices_train_0);
    non_cancer_data_test_smear   = Cervical_Group_1_non_cancer_info.Smear_list(Indices_test_0);
    
    
    X_train = cat(1,non_cancer_data_train ,cancer_data_train); 
    Y_train = cat(1,zeros(949,1),ones(428,1));
    X_test = cat(1,non_cancer_data_test ,cancer_data_test);       
    Y_test = cat(1,zeros(200,1),ones(100,1));
    
    Colp_info_train = cat(1,non_cancer_data_train_colp,cancer_data_train_colp);
    Colp_info_test = cat(1,non_cancer_data_test_colp,cancer_data_test_colp);
    Smear_info_train = cat(1,non_cancer_data_train_smear,cancer_data_train_smear);
    Smear_info_test = cat(1,non_cancer_data_test_smear,cancer_data_test_smear);
    
    
    %% grid search----------------------------------------------------------------------------------------------------------------------

    treeModel = TreeBagger(NumTrees_set, X_train, Y_train, 'MaxNumSplits', MaxNumSplits_set ,'MinLeafSize',MinLeafSize_set,'NumPredictorsToSample',2,'Method','classification');

    [Y_pred_train,score_train] = predict(treeModel, X_train);
    [Y_pred_test,score_test]    = predict(treeModel, X_test);
    [Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);

    [x_, y_, T_, AUC_test] = perfcurve(Y_test, score_test(:,2), 1);
    [x_, y_, T_, AUC_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);

    %% ------------------------------------------------------------------------------------------------
    %% step 1
    % find the best threshold based on training data
    % to make the Yuden score on the training results to be the best
    % J = Sensitivity + Specificity -1
    [threshold_best_final, training_specificity_final ,training_sensitivity_final] = threshold_selection(score_train(:,2), Y_train);
    
    %% ------------------------------------------------------------------------------------------------
    %% step 3
    %% calculate the metics on testing set  for Group 1
    [accuracy_test,recall_test ,specificity_test,sensitivity_test] = ConfusionMatrix_cal(score_test(:,2),threshold_best_final,Y_test);
    %% calculate the metics on testing set  for Group 2 from London
    [accuracy_test_London,recall_test_London ,specificity_test_London,sensitivity_test_London] = ConfusionMatrix_cal(score_test_London(:,2),threshold_best_final,Y_test_Group_2);
                   
    %% step 4
    % considering the prior knowledge
    %% 4.1 calculate the prob of each dignosis statistics
    % -----------------------------------------------------------------------------------------------
    % only colp
    
    Train_HG_1_colp_0 = 0;
    Train_HG_1_colp_1 = 0;
    Train_HG_0_colp_0 = 0;
    Train_HG_0_colp_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) 
            Train_HG_1_colp_0 = Train_HG_1_colp_0 +1;
        else
            Train_HG_1_colp_1 = Train_HG_1_colp_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) 
            Train_HG_0_colp_0 = Train_HG_0_colp_0 +1;
        else
            Train_HG_0_colp_1 = Train_HG_0_colp_1 +1;
        end
    end
    
    % -----------------------------------------------------------------------------------------------
    % only smear
    
    Train_HG_1_smear_0 = 0;
    Train_HG_1_smear_1 = 0;
    Train_HG_0_smear_0 = 0;
    Train_HG_0_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_smear(i) == 0) 
            Train_HG_1_smear_0 = Train_HG_1_smear_0 +1;
        else
            Train_HG_1_smear_1 = Train_HG_1_smear_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_smear(i) == 0) 
            Train_HG_0_smear_0 = Train_HG_0_smear_0 +1;
        else
            Train_HG_0_smear_1 = Train_HG_0_smear_1 +1;
        end
    end
    
    
    
    %---------------------------------------------------------------------------------------------------------------
    % colp and smear
    Train_HG_1_colp_0_smear_0 = 0;
    Train_HG_1_colp_0_smear_1 = 0;
    Train_HG_1_colp_1_smear_0 = 0;
    Train_HG_1_colp_1_smear_1 = 0;
    
    Train_HG_0_colp_0_smear_0 = 0;
    Train_HG_0_colp_0_smear_1 = 0;
    Train_HG_0_colp_1_smear_0 = 0;
    Train_HG_0_colp_1_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_0_smear_0 = Train_HG_1_colp_0_smear_0 +1;
    
        elseif (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 1)
            Train_HG_1_colp_0_smear_1 = Train_HG_1_colp_0_smear_1 +1;
    
        elseif (cancer_data_train_colp(i) == 1) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_1_smear_0 = Train_HG_1_colp_1_smear_0 +1;
    
        else
            Train_HG_1_colp_1_smear_1 = Train_HG_1_colp_1_smear_1 +1;
          
        end
    end
    
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_0_smear_0 = Train_HG_0_colp_0_smear_0 +1;
    
        elseif (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 1)
            Train_HG_0_colp_0_smear_1 = Train_HG_0_colp_0_smear_1 +1;
    
        elseif (non_cancer_data_train_colp(i) == 1) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_1_smear_0 = Train_HG_0_colp_1_smear_0 +1;
    
        else
            Train_HG_0_colp_1_smear_1 = Train_HG_0_colp_1_smear_1 +1;
          
        end
    end
        
    %% 4.2 calculate the prob of each dignosis
    % ---------------------------------------------------------------------------------------------------------------
    %% colp
    % colp 0 
    p_h_colp_0 = Train_HG_1_colp_0 / (Train_HG_1_colp_0 + Train_HG_0_colp_0);
    % colp 1
    p_h_colp_1 = Train_HG_1_colp_1/ (Train_HG_1_colp_1 + Train_HG_0_colp_1);
    
    % ---------------------------------------------------------------------------------------------------------------
    %% smear
    % smear 0 
    p_h_smear_0 = Train_HG_1_smear_0 / (Train_HG_1_smear_0 + Train_HG_0_smear_0);
    % smear 1
    p_h_smear_1 = Train_HG_1_smear_1/ (Train_HG_1_smear_1 + Train_HG_0_smear_1);
    
    
    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    %% colp 0 smear 0
    p_h_colp_smear_00 = Train_HG_1_colp_0_smear_0 / (Train_HG_1_colp_0_smear_0 + Train_HG_0_colp_0_smear_0);
    % colp 0 smear 1
    p_h_colp_smear_01 = Train_HG_1_colp_0_smear_1 / (Train_HG_1_colp_0_smear_1 + Train_HG_0_colp_0_smear_1);
    % colp 1 smear 0
    p_h_colp_smear_10 = Train_HG_1_colp_1_smear_0 / (Train_HG_1_colp_1_smear_0 + Train_HG_0_colp_1_smear_0);
    % colp 1 smear 1
    p_h_colp_smear_11 = Train_HG_1_colp_1_smear_1 / (Train_HG_1_colp_1_smear_1 + Train_HG_0_colp_1_smear_1); 


    %% step 5
    % calculate
    % for testing data
    AA_prediction_results_with_bayes_colp_smear  = zeros(size(Y_test,1),1);


    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    for i=1:size(Y_test,1)
        if (score_test(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_test(i)==1)&&(Smear_info_test(i)==1) %  colp =1 smear 1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
                    
            if (Colp_info_test(i)==1)&&(Smear_info_test(i)==0) %  colp =1 smear 0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test(i)==0)&&(Smear_info_test(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test(i)==0)&&(Smear_info_test(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
    
        end
    
        if (score_test(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_test(i)==1)&&(Smear_info_test(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
             if (Colp_info_test(i)==1)&&(Smear_info_test(i)==0) %  colp =0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
    
             if (Colp_info_test(i)==0)&&(Smear_info_test(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
            if (Colp_info_test(i)==0)&&(Smear_info_test(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
        end
    end

    [x_, y_, T_, AUC_test_add_Bayes_colp_smear] = perfcurve(Y_test, AA_prediction_results_with_bayes_colp_smear, 1);

    % for gourp 2 data from London
    AA_prediction_results_with_bayes_colp_smear_London = zeros(112,1);

    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    for i=1:size(Y_test_Group_2,1)
        if (score_test_London(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==1) %  colp =1 smear 1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
                    
            if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==0) %  colp =1 smear 0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
    
        if (score_test_London(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
             if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==0) %  colp =0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
    
             if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
            if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
        end
    end

    [x_, y_, T_, AUC_test_add_Bayes_colp_smear_London] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_colp_smear_London, 1);






    %% Step 6
    % Bayes results in Training dataset
    % using prior on training results (Y_pred_train,   score_train )
    % and using threshold selection method to find the best threshold on Training 

    AA_prediction_results_with_bayes_colp_smear_train = zeros(1377,1);
    %% step 6.1 calulate the training results processed by prior knowledge
    % colp and smear
    for i=1:size(Y_train,1)
        if (score_train(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_train(i)==1)&&(Smear_info_train(i)==1) %  colp =1 smear 1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
                    
            if (Colp_info_train(i)==1)&&(Smear_info_train(i)==0) %  colp =1 smear 0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_train(i)==0)&&(Smear_info_train(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_train(i)==0)&&(Smear_info_train(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
    
        if (score_train(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_train(i)==1)&&(Smear_info_train(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
             if (Colp_info_train(i)==1)&&(Smear_info_train(i)==0) %  colp =0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
    
             if (Colp_info_train(i)==0)&&(Smear_info_train(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
            if (Colp_info_train(i)==0)&&(Smear_info_train(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
        end
    end

    %% Step 6.2 
    %% choose the best threshold from Bayes

    score_train_Bayes_Colp_Smear = AA_prediction_results_with_bayes_colp_smear_train;
    % find the best threshold on training curves when using prior knowledge
    [threshold_best_final_train_Bayes_Colp_Smear, nono , nono] = threshold_selection(score_train_Bayes_Colp_Smear, Y_train);

    [accuracy_test_Colp_Smear,recall_test_Colp_Smear,specificity_test_Colp_Smear,sensitivity_test_Colp_Smear]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_colp_smear,threshold_best_final_train_Bayes_Colp_Smear,Y_test);
    [accuracy_test_Colp_Smear_London,recall_test_Colp_Smear_London,specificity_test_Colp_Smear_London,sensitivity_test_Colp_Smear_London]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_colp_smear_London,threshold_best_final_train_Bayes_Colp_Smear,Y_test_Group_2);

    AAA_FINAL_METRICS_SAVE(seed_nn,1:3) = [AUC_test,specificity_test,sensitivity_test] ;
    AAA_FINAL_METRICS_SAVE(seed_nn,4:6) = [AUC_test_add_Bayes_colp_smear,specificity_test_Colp_Smear,sensitivity_test_Colp_Smear];
    AAA_FINAL_METRICS_SAVE(seed_nn,7:9) = [AUC_test_London,specificity_test_London,sensitivity_test_London];
    AAA_FINAL_METRICS_SAVE(seed_nn,10:12) = [AUC_test_add_Bayes_colp_smear_London, specificity_test_Colp_Smear_London, sensitivity_test_Colp_Smear_London];


end

AAA_compare = [];
%% calculate the CI mean and std value
for i =1:12
     [mean_val,std_val,ci_lower,ci_upper] = CI_cal(AAA_FINAL_METRICS_SAVE(:,i));
     AAA_compare(i,1) = mean_val;
     AAA_compare(i,2) = std_val;
     AAA_compare(i,3) = ci_lower;
     AAA_compare(i,4) = ci_upper;
end
[Y_pred_train,score_train] = predict(treeModel, X_train);
[Y_pred_test,score_test]    = predict(treeModel, X_test);
[Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);
[x_train, y_train, T_train, AUC_train, theop_train] = perfcurve(Y_train, score_train(:,2), 1);
[x_G1, y_G1, T_G1, AUC_test,theop_test] = perfcurve(Y_test, score_test(:,2), 1);
[x_G1_b, y_G1_b, T_, AUC_test_add_Bayes_colp_smear,theop_test_b] = perfcurve(Y_test, AA_prediction_results_with_bayes_colp_smear, 1);
[x_G2, y_G2, T_G2, AUC_test_London,theop_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);
[x_G2_b, y_G2_b, T_, AUC_test_add_Bayes_colp_smear_London,theop_test_London_b] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_colp_smear_London, 1);
%% for plotting
color_1 = '[ 0 0.78 0.55]';
color_2 = '[0.25 0.41 0.88]';
color_3 = '[1 0.6 0]';
%% for group 1
figure(1);subplot(4,4,2)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G1,y_G1,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G1_b, y_G1_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_b(1),theop_test_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_colp_smear,threshold_best_final_train_Bayes_Colp_Smear,Y_test);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group1 ROC (RF)');legend([p_1,p_2],'Test results','Test results (PK)')

%% for group 2
figure(2);subplot(4,4,2)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G2,y_G2,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G2_b, y_G2_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_London_b(1),theop_test_London_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_colp_smear_London, threshold_best_final_train_Bayes_Colp_Smear, Y_test_Group_2);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group2 ROC (RF)');legend([p_1,p_2],'Test results','Test results (PK)')

%% ----------------------------------------------------------------------------------------------------------------------
%% ----------------------------------------------------------------------------------------------------------------------
clc
clear
%% load data ---------------------------------------------------------------------------------------------------------
% Group 1
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_Cancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_NonCancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_cancer_data_and_info.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_non_cancer_data_and_info.mat')
% Group 2
load('../../data/cervical data London/postprocessed_by_Lin/Cervical_Group_2_coleModel_MaxDiffMean_112.mat')
%% data filtering ----------------------------------------------------------------------------------------------------
%% Group 2
G2_cancer          = cat(2,Cervical_Group_2_cancer_MeanValues,          Cervical_Group_2_cancer_MaxDiff);
G2_non_cancer = cat(2,Cervical_Group_2_non_cancer_MeanValues,Cervical_Group_2_non_cancer_MaxDiff);
X_test_Group_2 = cat(1,G2_non_cancer,G2_cancer);
Y_test_Group_2 = cat(1,zeros(93,1),        ones(19,1));
Group_2_Colp_info     =cat(1,Cervical_Group_2_non_cancer_info.Colp,    Cervical_Group_2_cancer_info.Colp);
Group_2_Smear_info  =cat(1,Cervical_Group_2_non_cancer_info.Smear,Cervical_Group_2_cancer_info.Smear);
Colp_info_test_London = Group_2_Colp_info;
Smear_info_test_London = Group_2_Smear_info;
%% Group 1
G1_cancer          = cat(2,Cervical_Group_1_cancer_MeanValues,          Cervical_Group_1_cancer_MaxDiff);
G1_non_cancer = cat(2,Cervical_Group_1_non_cancer_MeanValues,Cervical_Group_1_non_cancer_MaxDiff);

%% ----------------------------------------------------------------------------------------------------------------------
% the best pair of hyper-para
BoxConstraint_set = 0.001;
KernelFunction_set ='linear';

AAA_FINAL_METRICS_SAVE = zeros(100,9);
%  AUC_test,                                    specificity_test,                    sensitivity_test,
%  AUC_test_add_Bayes_G1,       specificity_test_G1,             sensitivity_test_G1,
%  AUC_test_add_Bayes_G2,       specificity_test_G2,             sensitivity_test_G2,

for seed_nn = 4
    fprintf('the round is in %d \n',seed_nn);
    rng(seed_nn);index_record_line = 1;

    %% split the data Group1  to training and testing dataset --------------------------------------------------------------------------------------------------------------------
    % cancer data 528             vali and test      428:100
    % non cancer data 1149   vali and test      949:200
    indices_1 = randperm(528);
    Indices_train_1 = indices_1(1:428);
    Indices_test_1 = indices_1(429:end);
    
    cancer_data_train                 = G1_cancer(Indices_train_1,:);
    cancer_data_test                  =  G1_cancer(Indices_test_1,:);
    cancer_data_train_colp      = Cervical_Group_1_cancer_info.Colp_list(Indices_train_1);
    cancer_data_test_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_test_1);
    cancer_data_train_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_train_1);
    cancer_data_test_smear   = Cervical_Group_1_cancer_info.Smear_list(Indices_test_1);
    
    indices_0 = randperm(1149);
    Indices_train_0 = indices_0(1:949);
    Indices_test_0 = indices_0(950:end);
    
    non_cancer_data_train             = G1_non_cancer(Indices_train_0,:);
    non_cancer_data_test               = G1_non_cancer(Indices_test_0,:);
    non_cancer_data_train_colp    = Cervical_Group_1_non_cancer_info.Colp_list(Indices_train_0);
    non_cancer_data_test_colp      = Cervical_Group_1_non_cancer_info.Colp_list(Indices_test_0);
    non_cancer_data_train_smear = Cervical_Group_1_non_cancer_info.Smear_list(Indices_train_0);
    non_cancer_data_test_smear   = Cervical_Group_1_non_cancer_info.Smear_list(Indices_test_0);
    
    
    X_train = cat(1,non_cancer_data_train ,cancer_data_train); 
    Y_train = cat(1,zeros(949,1),ones(428,1));
    X_test = cat(1,non_cancer_data_test ,cancer_data_test);       
    Y_test = cat(1,zeros(200,1),ones(100,1));
    
    Colp_info_train = cat(1,non_cancer_data_train_colp,cancer_data_train_colp);
    Colp_info_test = cat(1,non_cancer_data_test_colp,cancer_data_test_colp);
    Smear_info_train = cat(1,non_cancer_data_train_smear,cancer_data_train_smear);
    Smear_info_test = cat(1,non_cancer_data_test_smear,cancer_data_test_smear);
    
    
    %% grid search----------------------------------------------------------------------------------------------------------------------

    treeModel = fitcsvm(X_train, Y_train,'KernelFunction',KernelFunction_set,'BoxConstraint', BoxConstraint_set,'Standardize',true);

    [Y_pred_train,score_train] = predict(treeModel, X_train);
    [Y_pred_test,score_test]    = predict(treeModel, X_test);
    [Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);

    [x_, y_, T_, AUC_test] = perfcurve(Y_test, score_test(:,2), 1);
    [x_, y_, T_, AUC_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);

    %% ------------------------------------------------------------------------------------------------
    %% step 1
    % find the best threshold based on training data
    % to make the Yuden score on the training results to be the best
    % J = Sensitivity + Specificity -1
    [threshold_best_final, training_specificity_final ,training_sensitivity_final] = threshold_selection(score_train(:,2), Y_train);
    
    %% ------------------------------------------------------------------------------------------------
    %% step 3
    %% calculate the metics on testing set  for Group 1
    [accuracy_test,recall_test ,specificity_test,sensitivity_test] = ConfusionMatrix_cal(score_test(:,2),threshold_best_final,Y_test);
    %% calculate the metics on testing set  for Group 2 from London
    [accuracy_test_London,recall_test_London ,specificity_test_London,sensitivity_test_London] = ConfusionMatrix_cal(score_test_London(:,2),threshold_best_final,Y_test_Group_2);
                   
    %% step 4
    % considering the prior knowledge
    %% 4.1 calculate the prob of each dignosis statistics
    % -----------------------------------------------------------------------------------------------
    % only colp
    
    Train_HG_1_colp_0 = 0;
    Train_HG_1_colp_1 = 0;
    Train_HG_0_colp_0 = 0;
    Train_HG_0_colp_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) 
            Train_HG_1_colp_0 = Train_HG_1_colp_0 +1;
        else
            Train_HG_1_colp_1 = Train_HG_1_colp_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) 
            Train_HG_0_colp_0 = Train_HG_0_colp_0 +1;
        else
            Train_HG_0_colp_1 = Train_HG_0_colp_1 +1;
        end
    end
    
    % -----------------------------------------------------------------------------------------------
    % only smear
    
    Train_HG_1_smear_0 = 0;
    Train_HG_1_smear_1 = 0;
    Train_HG_0_smear_0 = 0;
    Train_HG_0_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_smear(i) == 0) 
            Train_HG_1_smear_0 = Train_HG_1_smear_0 +1;
        else
            Train_HG_1_smear_1 = Train_HG_1_smear_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_smear(i) == 0) 
            Train_HG_0_smear_0 = Train_HG_0_smear_0 +1;
        else
            Train_HG_0_smear_1 = Train_HG_0_smear_1 +1;
        end
    end
    
    
    
    %---------------------------------------------------------------------------------------------------------------
    % colp and smear
    Train_HG_1_colp_0_smear_0 = 0;
    Train_HG_1_colp_0_smear_1 = 0;
    Train_HG_1_colp_1_smear_0 = 0;
    Train_HG_1_colp_1_smear_1 = 0;
    
    Train_HG_0_colp_0_smear_0 = 0;
    Train_HG_0_colp_0_smear_1 = 0;
    Train_HG_0_colp_1_smear_0 = 0;
    Train_HG_0_colp_1_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_0_smear_0 = Train_HG_1_colp_0_smear_0 +1;
    
        elseif (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 1)
            Train_HG_1_colp_0_smear_1 = Train_HG_1_colp_0_smear_1 +1;
    
        elseif (cancer_data_train_colp(i) == 1) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_1_smear_0 = Train_HG_1_colp_1_smear_0 +1;
    
        else
            Train_HG_1_colp_1_smear_1 = Train_HG_1_colp_1_smear_1 +1;
          
        end
    end
    
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_0_smear_0 = Train_HG_0_colp_0_smear_0 +1;
    
        elseif (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 1)
            Train_HG_0_colp_0_smear_1 = Train_HG_0_colp_0_smear_1 +1;
    
        elseif (non_cancer_data_train_colp(i) == 1) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_1_smear_0 = Train_HG_0_colp_1_smear_0 +1;
    
        else
            Train_HG_0_colp_1_smear_1 = Train_HG_0_colp_1_smear_1 +1;
          
        end
    end
        
    %% 4.2 calculate the prob of each dignosis
    % ---------------------------------------------------------------------------------------------------------------
    %% colp
    % colp 0 
    p_h_colp_0 = Train_HG_1_colp_0 / (Train_HG_1_colp_0 + Train_HG_0_colp_0);
    % colp 1
    p_h_colp_1 = Train_HG_1_colp_1/ (Train_HG_1_colp_1 + Train_HG_0_colp_1);
    
    % ---------------------------------------------------------------------------------------------------------------
    %% smear
    % smear 0 
    p_h_smear_0 = Train_HG_1_smear_0 / (Train_HG_1_smear_0 + Train_HG_0_smear_0);
    % smear 1
    p_h_smear_1 = Train_HG_1_smear_1/ (Train_HG_1_smear_1 + Train_HG_0_smear_1);
    
    
    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    %% colp 0 smear 0
    p_h_colp_smear_00 = Train_HG_1_colp_0_smear_0 / (Train_HG_1_colp_0_smear_0 + Train_HG_0_colp_0_smear_0);
    % colp 0 smear 1
    p_h_colp_smear_01 = Train_HG_1_colp_0_smear_1 / (Train_HG_1_colp_0_smear_1 + Train_HG_0_colp_0_smear_1);
    % colp 1 smear 0
    p_h_colp_smear_10 = Train_HG_1_colp_1_smear_0 / (Train_HG_1_colp_1_smear_0 + Train_HG_0_colp_1_smear_0);
    % colp 1 smear 1
    p_h_colp_smear_11 = Train_HG_1_colp_1_smear_1 / (Train_HG_1_colp_1_smear_1 + Train_HG_0_colp_1_smear_1); 


    %% step 5
    % calculate
    % for testing data
    AA_prediction_results_with_bayes_colp_smear  = zeros(size(Y_test,1),1);


    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    for i=1:size(Y_test,1)
        if (score_test(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_test(i)==1)&&(Smear_info_test(i)==1) %  colp =1 smear 1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
                    
            if (Colp_info_test(i)==1)&&(Smear_info_test(i)==0) %  colp =1 smear 0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test(i)==0)&&(Smear_info_test(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test(i)==0)&&(Smear_info_test(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
    
        end
    
        if (score_test(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_test(i)==1)&&(Smear_info_test(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
             if (Colp_info_test(i)==1)&&(Smear_info_test(i)==0) %  colp =0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
    
             if (Colp_info_test(i)==0)&&(Smear_info_test(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
            if (Colp_info_test(i)==0)&&(Smear_info_test(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
        end
    end

    [x_, y_, T_, AUC_test_add_Bayes_colp_smear] = perfcurve(Y_test, AA_prediction_results_with_bayes_colp_smear, 1);

    % for gourp 2 data from London
    AA_prediction_results_with_bayes_colp_smear_London = zeros(112,1);

    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    for i=1:size(Y_test_Group_2,1)
        if (score_test_London(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==1) %  colp =1 smear 1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
                    
            if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==0) %  colp =1 smear 0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
    
        if (score_test_London(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
             if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==0) %  colp =0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
    
             if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
            if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
        end
    end

    [x_, y_, T_, AUC_test_add_Bayes_colp_smear_London] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_colp_smear_London, 1);






    %% Step 6
    % Bayes results in Training dataset
    % using prior on training results (Y_pred_train,   score_train )
    % and using threshold selection method to find the best threshold on Training 

    AA_prediction_results_with_bayes_colp_smear_train = zeros(1377,1);
    %% step 6.1 calulate the training results processed by prior knowledge
    % colp and smear
    for i=1:size(Y_train,1)
        if (score_train(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_train(i)==1)&&(Smear_info_train(i)==1) %  colp =1 smear 1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
                    
            if (Colp_info_train(i)==1)&&(Smear_info_train(i)==0) %  colp =1 smear 0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_train(i)==0)&&(Smear_info_train(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_train(i)==0)&&(Smear_info_train(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
    
        if (score_train(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_train(i)==1)&&(Smear_info_train(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
             if (Colp_info_train(i)==1)&&(Smear_info_train(i)==0) %  colp =0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
    
             if (Colp_info_train(i)==0)&&(Smear_info_train(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
            if (Colp_info_train(i)==0)&&(Smear_info_train(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
        end
    end

    %% Step 6.2 
    %% choose the best threshold from Bayes

    score_train_Bayes_Colp_Smear = AA_prediction_results_with_bayes_colp_smear_train;
    % find the best threshold on training curves when using prior knowledge
    [threshold_best_final_train_Bayes_Colp_Smear, nono , nono] = threshold_selection(score_train_Bayes_Colp_Smear, Y_train);

    [accuracy_test_Colp_Smear,recall_test_Colp_Smear,specificity_test_Colp_Smear,sensitivity_test_Colp_Smear]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_colp_smear,threshold_best_final_train_Bayes_Colp_Smear,Y_test);
    [accuracy_test_Colp_Smear_London,recall_test_Colp_Smear_London,specificity_test_Colp_Smear_London,sensitivity_test_Colp_Smear_London]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_colp_smear_London,threshold_best_final_train_Bayes_Colp_Smear,Y_test_Group_2);

    AAA_FINAL_METRICS_SAVE(seed_nn,1:3) = [AUC_test,specificity_test,sensitivity_test] ;
    AAA_FINAL_METRICS_SAVE(seed_nn,4:6) = [AUC_test_add_Bayes_colp_smear,specificity_test_Colp_Smear,sensitivity_test_Colp_Smear];
    AAA_FINAL_METRICS_SAVE(seed_nn,7:9) = [AUC_test_London,specificity_test_London,sensitivity_test_London];
    AAA_FINAL_METRICS_SAVE(seed_nn,10:12) = [AUC_test_add_Bayes_colp_smear_London, specificity_test_Colp_Smear_London, sensitivity_test_Colp_Smear_London];


end

AAA_compare = [];
%% calculate the CI mean and std value
for i =1:12
     [mean_val,std_val,ci_lower,ci_upper] = CI_cal(AAA_FINAL_METRICS_SAVE(:,i));
     AAA_compare(i,1) = mean_val;
     AAA_compare(i,2) = std_val;
     AAA_compare(i,3) = ci_lower;
     AAA_compare(i,4) = ci_upper;
end
[Y_pred_train,score_train] = predict(treeModel, X_train);
[Y_pred_test,score_test]    = predict(treeModel, X_test);
[Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);
[x_train, y_train, T_train, AUC_train, theop_train] = perfcurve(Y_train, score_train(:,2), 1);
[x_G1, y_G1, T_G1, AUC_test,theop_test] = perfcurve(Y_test, score_test(:,2), 1);
[x_G1_b, y_G1_b, T_, AUC_test_add_Bayes_colp_smear,theop_test_b] = perfcurve(Y_test, AA_prediction_results_with_bayes_colp_smear, 1);
[x_G2, y_G2, T_G2, AUC_test_London,theop_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);
[x_G2_b, y_G2_b, T_, AUC_test_add_Bayes_colp_smear_London,theop_test_London_b] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_colp_smear_London, 1);
%% for plotting
color_1 = '[ 0 0.78 0.55]';
color_2 = '[0.25 0.41 0.88]';
color_3 = '[1 0.6 0]';
%% for group 1
figure(1);subplot(4,4,3)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G1,y_G1,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G1_b, y_G1_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_b(1),theop_test_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_colp_smear,threshold_best_final_train_Bayes_Colp_Smear,Y_test);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group1 ROC (SVM)');legend([p_1,p_2],'Test results','Test results (PK)')

%% for group 2
figure(2);subplot(4,4,3)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G2,y_G2,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G2_b, y_G2_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_London_b(1),theop_test_London_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_colp_smear_London, threshold_best_final_train_Bayes_Colp_Smear, Y_test_Group_2);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group2 ROC (SVM)');legend([p_1,p_2],'Test results','Test results (PK)')

%% ----------------------------------------------------------------------------------------------------------------------
%% ----------------------------------------------------------------------------------------------------------------------
clc
clear
%% load data ---------------------------------------------------------------------------------------------------------
% Group 1
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_Cancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_NonCancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_cancer_data_and_info.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_non_cancer_data_and_info.mat')
% Group 2
load('../../data/cervical data London/postprocessed_by_Lin/Cervical_Group_2_coleModel_MaxDiffMean_112.mat')
%% data filtering ----------------------------------------------------------------------------------------------------
%% Group 2
G2_cancer          = cat(2,Cervical_Group_2_cancer_MeanValues,          Cervical_Group_2_cancer_MaxDiff);
G2_non_cancer = cat(2,Cervical_Group_2_non_cancer_MeanValues,Cervical_Group_2_non_cancer_MaxDiff);
X_test_Group_2 = cat(1,G2_non_cancer,G2_cancer);
Y_test_Group_2 = cat(1,zeros(93,1),        ones(19,1));
Group_2_Colp_info     =cat(1,Cervical_Group_2_non_cancer_info.Colp,    Cervical_Group_2_cancer_info.Colp);
Group_2_Smear_info  =cat(1,Cervical_Group_2_non_cancer_info.Smear,Cervical_Group_2_cancer_info.Smear);
Colp_info_test_London = Group_2_Colp_info;
Smear_info_test_London = Group_2_Smear_info;
%% Group 1
G1_cancer          = cat(2,Cervical_Group_1_cancer_MeanValues,          Cervical_Group_1_cancer_MaxDiff);
G1_non_cancer = cat(2,Cervical_Group_1_non_cancer_MeanValues,Cervical_Group_1_non_cancer_MaxDiff);

%% ----------------------------------------------------------------------------------------------------------------------
% the best pair of hyper-para


AAA_FINAL_METRICS_SAVE = zeros(100,9);
%  AUC_test,                                    specificity_test,                    sensitivity_test,
%  AUC_test_add_Bayes_G1,       specificity_test_G1,             sensitivity_test_G1,
%  AUC_test_add_Bayes_G2,       specificity_test_G2,             sensitivity_test_G2,

for seed_nn = 4
    fprintf('the round is in %d \n',seed_nn);
    rng(seed_nn);index_record_line = 1;

    %% split the data Group1  to training and testing dataset --------------------------------------------------------------------------------------------------------------------
    % cancer data 528             vali and test      428:100
    % non cancer data 1149   vali and test      949:200
    indices_1 = randperm(528);
    Indices_train_1 = indices_1(1:428);
    Indices_test_1 = indices_1(429:end);
    
    cancer_data_train                 = G1_cancer(Indices_train_1,:);
    cancer_data_test                  =  G1_cancer(Indices_test_1,:);
    cancer_data_train_colp      = Cervical_Group_1_cancer_info.Colp_list(Indices_train_1);
    cancer_data_test_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_test_1);
    cancer_data_train_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_train_1);
    cancer_data_test_smear   = Cervical_Group_1_cancer_info.Smear_list(Indices_test_1);
    
    indices_0 = randperm(1149);
    Indices_train_0 = indices_0(1:949);
    Indices_test_0 = indices_0(950:end);
    
    non_cancer_data_train             = G1_non_cancer(Indices_train_0,:);
    non_cancer_data_test               = G1_non_cancer(Indices_test_0,:);
    non_cancer_data_train_colp    = Cervical_Group_1_non_cancer_info.Colp_list(Indices_train_0);
    non_cancer_data_test_colp      = Cervical_Group_1_non_cancer_info.Colp_list(Indices_test_0);
    non_cancer_data_train_smear = Cervical_Group_1_non_cancer_info.Smear_list(Indices_train_0);
    non_cancer_data_test_smear   = Cervical_Group_1_non_cancer_info.Smear_list(Indices_test_0);
    
    
    X_train = cat(1,non_cancer_data_train ,cancer_data_train); 
    Y_train = cat(1,zeros(949,1),ones(428,1));
    X_test = cat(1,non_cancer_data_test ,cancer_data_test);       
    Y_test = cat(1,zeros(200,1),ones(100,1));
    
    Colp_info_train = cat(1,non_cancer_data_train_colp,cancer_data_train_colp);
    Colp_info_test = cat(1,non_cancer_data_test_colp,cancer_data_test_colp);
    Smear_info_train = cat(1,non_cancer_data_train_smear,cancer_data_train_smear);
    Smear_info_test = cat(1,non_cancer_data_test_smear,cancer_data_test_smear);
    
    
    %% grid search----------------------------------------------------------------------------------------------------------------------

                        treeModel = fitcnet(X_train, Y_train, ...
                                        'Standardize', true, ...
                                        'LayerSizes', [10], ...  % 两层隐藏层，分别有 10 和 5 个神经元
                                        'Activations', 'relu');     % 可选：'relu', 'tanh', 'sigmoid'

    [Y_pred_train,score_train] = predict(treeModel, X_train);
    [Y_pred_test,score_test]    = predict(treeModel, X_test);
    [Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);

    [x_, y_, T_, AUC_test] = perfcurve(Y_test, score_test(:,2), 1);
    [x_, y_, T_, AUC_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);

    %% ------------------------------------------------------------------------------------------------
    %% step 1
    % find the best threshold based on training data
    % to make the Yuden score on the training results to be the best
    % J = Sensitivity + Specificity -1
    [threshold_best_final, training_specificity_final ,training_sensitivity_final] = threshold_selection(score_train(:,2), Y_train);
    
    %% ------------------------------------------------------------------------------------------------
    %% step 3
    %% calculate the metics on testing set  for Group 1
    [accuracy_test,recall_test ,specificity_test,sensitivity_test] = ConfusionMatrix_cal(score_test(:,2),threshold_best_final,Y_test);
    %% calculate the metics on testing set  for Group 2 from London
    [accuracy_test_London,recall_test_London ,specificity_test_London,sensitivity_test_London] = ConfusionMatrix_cal(score_test_London(:,2),threshold_best_final,Y_test_Group_2);
                   
    %% step 4
    % considering the prior knowledge
    %% 4.1 calculate the prob of each dignosis statistics
    % -----------------------------------------------------------------------------------------------
    % only colp
    
    Train_HG_1_colp_0 = 0;
    Train_HG_1_colp_1 = 0;
    Train_HG_0_colp_0 = 0;
    Train_HG_0_colp_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) 
            Train_HG_1_colp_0 = Train_HG_1_colp_0 +1;
        else
            Train_HG_1_colp_1 = Train_HG_1_colp_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) 
            Train_HG_0_colp_0 = Train_HG_0_colp_0 +1;
        else
            Train_HG_0_colp_1 = Train_HG_0_colp_1 +1;
        end
    end
    
    % -----------------------------------------------------------------------------------------------
    % only smear
    
    Train_HG_1_smear_0 = 0;
    Train_HG_1_smear_1 = 0;
    Train_HG_0_smear_0 = 0;
    Train_HG_0_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_smear(i) == 0) 
            Train_HG_1_smear_0 = Train_HG_1_smear_0 +1;
        else
            Train_HG_1_smear_1 = Train_HG_1_smear_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_smear(i) == 0) 
            Train_HG_0_smear_0 = Train_HG_0_smear_0 +1;
        else
            Train_HG_0_smear_1 = Train_HG_0_smear_1 +1;
        end
    end
    
    
    
    %---------------------------------------------------------------------------------------------------------------
    % colp and smear
    Train_HG_1_colp_0_smear_0 = 0;
    Train_HG_1_colp_0_smear_1 = 0;
    Train_HG_1_colp_1_smear_0 = 0;
    Train_HG_1_colp_1_smear_1 = 0;
    
    Train_HG_0_colp_0_smear_0 = 0;
    Train_HG_0_colp_0_smear_1 = 0;
    Train_HG_0_colp_1_smear_0 = 0;
    Train_HG_0_colp_1_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_0_smear_0 = Train_HG_1_colp_0_smear_0 +1;
    
        elseif (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 1)
            Train_HG_1_colp_0_smear_1 = Train_HG_1_colp_0_smear_1 +1;
    
        elseif (cancer_data_train_colp(i) == 1) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_1_smear_0 = Train_HG_1_colp_1_smear_0 +1;
    
        else
            Train_HG_1_colp_1_smear_1 = Train_HG_1_colp_1_smear_1 +1;
          
        end
    end
    
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_0_smear_0 = Train_HG_0_colp_0_smear_0 +1;
    
        elseif (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 1)
            Train_HG_0_colp_0_smear_1 = Train_HG_0_colp_0_smear_1 +1;
    
        elseif (non_cancer_data_train_colp(i) == 1) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_1_smear_0 = Train_HG_0_colp_1_smear_0 +1;
    
        else
            Train_HG_0_colp_1_smear_1 = Train_HG_0_colp_1_smear_1 +1;
          
        end
    end
        
    %% 4.2 calculate the prob of each dignosis
    % ---------------------------------------------------------------------------------------------------------------
    %% colp
    % colp 0 
    p_h_colp_0 = Train_HG_1_colp_0 / (Train_HG_1_colp_0 + Train_HG_0_colp_0);
    % colp 1
    p_h_colp_1 = Train_HG_1_colp_1/ (Train_HG_1_colp_1 + Train_HG_0_colp_1);
    
    % ---------------------------------------------------------------------------------------------------------------
    %% smear
    % smear 0 
    p_h_smear_0 = Train_HG_1_smear_0 / (Train_HG_1_smear_0 + Train_HG_0_smear_0);
    % smear 1
    p_h_smear_1 = Train_HG_1_smear_1/ (Train_HG_1_smear_1 + Train_HG_0_smear_1);
    
    
    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    %% colp 0 smear 0
    p_h_colp_smear_00 = Train_HG_1_colp_0_smear_0 / (Train_HG_1_colp_0_smear_0 + Train_HG_0_colp_0_smear_0);
    % colp 0 smear 1
    p_h_colp_smear_01 = Train_HG_1_colp_0_smear_1 / (Train_HG_1_colp_0_smear_1 + Train_HG_0_colp_0_smear_1);
    % colp 1 smear 0
    p_h_colp_smear_10 = Train_HG_1_colp_1_smear_0 / (Train_HG_1_colp_1_smear_0 + Train_HG_0_colp_1_smear_0);
    % colp 1 smear 1
    p_h_colp_smear_11 = Train_HG_1_colp_1_smear_1 / (Train_HG_1_colp_1_smear_1 + Train_HG_0_colp_1_smear_1); 


    %% step 5
    % calculate
    % for testing data
    AA_prediction_results_with_bayes_colp_smear  = zeros(size(Y_test,1),1);


    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    for i=1:size(Y_test,1)
        if (score_test(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_test(i)==1)&&(Smear_info_test(i)==1) %  colp =1 smear 1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
                    
            if (Colp_info_test(i)==1)&&(Smear_info_test(i)==0) %  colp =1 smear 0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test(i)==0)&&(Smear_info_test(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test(i)==0)&&(Smear_info_test(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
    
        end
    
        if (score_test(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_test(i)==1)&&(Smear_info_test(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
             if (Colp_info_test(i)==1)&&(Smear_info_test(i)==0) %  colp =0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
    
             if (Colp_info_test(i)==0)&&(Smear_info_test(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
            if (Colp_info_test(i)==0)&&(Smear_info_test(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
        end
    end

    [x_, y_, T_, AUC_test_add_Bayes_colp_smear] = perfcurve(Y_test, AA_prediction_results_with_bayes_colp_smear, 1);

    % for gourp 2 data from London
    AA_prediction_results_with_bayes_colp_smear_London = zeros(112,1);

    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    for i=1:size(Y_test_Group_2,1)
        if (score_test_London(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==1) %  colp =1 smear 1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
                    
            if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==0) %  colp =1 smear 0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
    
        if (score_test_London(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
             if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==0) %  colp =0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
    
             if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
            if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
        end
    end

    [x_, y_, T_, AUC_test_add_Bayes_colp_smear_London] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_colp_smear_London, 1);






    %% Step 6
    % Bayes results in Training dataset
    % using prior on training results (Y_pred_train,   score_train )
    % and using threshold selection method to find the best threshold on Training 

    AA_prediction_results_with_bayes_colp_smear_train = zeros(1377,1);
    %% step 6.1 calulate the training results processed by prior knowledge
    % colp and smear
    for i=1:size(Y_train,1)
        if (score_train(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_train(i)==1)&&(Smear_info_train(i)==1) %  colp =1 smear 1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
                    
            if (Colp_info_train(i)==1)&&(Smear_info_train(i)==0) %  colp =1 smear 0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_train(i)==0)&&(Smear_info_train(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_train(i)==0)&&(Smear_info_train(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
    
        if (score_train(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_train(i)==1)&&(Smear_info_train(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
             if (Colp_info_train(i)==1)&&(Smear_info_train(i)==0) %  colp =0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
    
             if (Colp_info_train(i)==0)&&(Smear_info_train(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
    
            if (Colp_info_train(i)==0)&&(Smear_info_train(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
        end
    end

    %% Step 6.2 
    %% choose the best threshold from Bayes

    score_train_Bayes_Colp_Smear = AA_prediction_results_with_bayes_colp_smear_train;
    % find the best threshold on training curves when using prior knowledge
    [threshold_best_final_train_Bayes_Colp_Smear, nono , nono] = threshold_selection(score_train_Bayes_Colp_Smear, Y_train);

    [accuracy_test_Colp_Smear,recall_test_Colp_Smear,specificity_test_Colp_Smear,sensitivity_test_Colp_Smear]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_colp_smear,threshold_best_final_train_Bayes_Colp_Smear,Y_test);
    [accuracy_test_Colp_Smear_London,recall_test_Colp_Smear_London,specificity_test_Colp_Smear_London,sensitivity_test_Colp_Smear_London]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_colp_smear_London,threshold_best_final_train_Bayes_Colp_Smear,Y_test_Group_2);

    AAA_FINAL_METRICS_SAVE(seed_nn,1:3) = [AUC_test,specificity_test,sensitivity_test] ;
    AAA_FINAL_METRICS_SAVE(seed_nn,4:6) = [AUC_test_add_Bayes_colp_smear,specificity_test_Colp_Smear,sensitivity_test_Colp_Smear];
    AAA_FINAL_METRICS_SAVE(seed_nn,7:9) = [AUC_test_London,specificity_test_London,sensitivity_test_London];
    AAA_FINAL_METRICS_SAVE(seed_nn,10:12) = [AUC_test_add_Bayes_colp_smear_London, specificity_test_Colp_Smear_London, sensitivity_test_Colp_Smear_London];


end

AAA_compare = [];
%% calculate the CI mean and std value
for i =1:12
     [mean_val,std_val,ci_lower,ci_upper] = CI_cal(AAA_FINAL_METRICS_SAVE(:,i));
     AAA_compare(i,1) = mean_val;
     AAA_compare(i,2) = std_val;
     AAA_compare(i,3) = ci_lower;
     AAA_compare(i,4) = ci_upper;
end
[Y_pred_train,score_train] = predict(treeModel, X_train);
[Y_pred_test,score_test]    = predict(treeModel, X_test);
[Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);
[x_train, y_train, T_train, AUC_train, theop_train] = perfcurve(Y_train, score_train(:,2), 1);
[x_G1, y_G1, T_G1, AUC_test,theop_test] = perfcurve(Y_test, score_test(:,2), 1);
[x_G1_b, y_G1_b, T_, AUC_test_add_Bayes_colp_smear,theop_test_b] = perfcurve(Y_test, AA_prediction_results_with_bayes_colp_smear, 1);
[x_G2, y_G2, T_G2, AUC_test_London,theop_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);
[x_G2_b, y_G2_b, T_, AUC_test_add_Bayes_colp_smear_London,theop_test_London_b] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_colp_smear_London, 1);
%% for plotting
color_1 = '[ 0 0.78 0.55]';
color_2 = '[0.25 0.41 0.88]';
color_3 = '[1 0.6 0]';
%% for group 1
figure(1);subplot(4,4,4)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G1,y_G1,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G1_b, y_G1_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_b(1),theop_test_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_colp_smear,threshold_best_final_train_Bayes_Colp_Smear,Y_test);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group1 ROC (MLP)');legend([p_1,p_2],'Test results','Test results (PK)')

%% for group 2
figure(2);subplot(4,4,4)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G2,y_G2,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G2_b, y_G2_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_London_b(1),theop_test_London_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_colp_smear_London, threshold_best_final_train_Bayes_Colp_Smear, Y_test_Group_2);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group2 ROC (MLP)');legend([p_1,p_2],'Test results','Test results (PK)')

%% ----------------------------------------------------------------------------------------------------------------------
%% ----------------------------------------------------------------------------------------------------------------------
clc
clear
%% load data ---------------------------------------------------------------------------------------------------------
% Group 1
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_Cancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_NonCancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_cancer_data_and_info.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_non_cancer_data_and_info.mat')
% Group 2
load('../../data/cervical data London/postprocessed_by_Lin/Cervical_Group_2_coleModel_MaxDiffMean_112.mat')
%% data filtering ----------------------------------------------------------------------------------------------------
%% Group 2
G2_cancer          = cat(2,Cervical_Group_2_cancer_MeanValues,          Cervical_Group_2_cancer_MaxDiff);
G2_non_cancer = cat(2,Cervical_Group_2_non_cancer_MeanValues,Cervical_Group_2_non_cancer_MaxDiff);
X_test_Group_2 = cat(1,G2_non_cancer,G2_cancer);
Y_test_Group_2 = cat(1,zeros(93,1),        ones(19,1));
Group_2_Colp_info     =cat(1,Cervical_Group_2_non_cancer_info.Colp,    Cervical_Group_2_cancer_info.Colp);
Group_2_Smear_info  =cat(1,Cervical_Group_2_non_cancer_info.Smear,Cervical_Group_2_cancer_info.Smear);
Colp_info_test_London = Group_2_Colp_info;
Smear_info_test_London = Group_2_Smear_info;
%% Group 1
G1_cancer          = cat(2,Cervical_Group_1_cancer_MeanValues,          Cervical_Group_1_cancer_MaxDiff);
G1_non_cancer = cat(2,Cervical_Group_1_non_cancer_MeanValues,Cervical_Group_1_non_cancer_MaxDiff);

%% ----------------------------------------------------------------------------------------------------------------------
% the best pair of hyper-para

AAA_FINAL_METRICS_SAVE = zeros(100,9);
%  AUC_test,                                    specificity_test,                    sensitivity_test,
%  AUC_test_add_Bayes_G1,       specificity_test_G1,             sensitivity_test_G1,
%  AUC_test_add_Bayes_G2,       specificity_test_G2,             sensitivity_test_G2,

MaxNumSplits_set = 	10
MinParentSize_set = 	25
MinLeafSize_set = 	5

for seed_nn = 4
    fprintf('the round is in %d \n',seed_nn);
    rng(seed_nn);index_record_line = 1;

    %% split the data Group1  to training and testing dataset --------------------------------------------------------------------------------------------------------------------
    % cancer data 528             vali and test      428:100
    % non cancer data 1149   vali and test      949:200
    indices_1 = randperm(528);
    Indices_train_1 = indices_1(1:428);
    Indices_test_1 = indices_1(429:end);
    
    cancer_data_train                 = G1_cancer(Indices_train_1,:);
    cancer_data_test                  =  G1_cancer(Indices_test_1,:);
    cancer_data_train_colp      = Cervical_Group_1_cancer_info.Colp_list(Indices_train_1);
    cancer_data_test_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_test_1);
    cancer_data_train_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_train_1);
    cancer_data_test_smear   = Cervical_Group_1_cancer_info.Smear_list(Indices_test_1);
    
    indices_0 = randperm(1149);
    Indices_train_0 = indices_0(1:949);
    Indices_test_0 = indices_0(950:end);
    
    non_cancer_data_train             = G1_non_cancer(Indices_train_0,:);
    non_cancer_data_test               = G1_non_cancer(Indices_test_0,:);
    non_cancer_data_train_colp    = Cervical_Group_1_non_cancer_info.Colp_list(Indices_train_0);
    non_cancer_data_test_colp      = Cervical_Group_1_non_cancer_info.Colp_list(Indices_test_0);
    non_cancer_data_train_smear = Cervical_Group_1_non_cancer_info.Smear_list(Indices_train_0);
    non_cancer_data_test_smear   = Cervical_Group_1_non_cancer_info.Smear_list(Indices_test_0);
    
    
    X_train = cat(1,non_cancer_data_train ,cancer_data_train); 
    Y_train = cat(1,zeros(949,1),ones(428,1));
    X_test = cat(1,non_cancer_data_test ,cancer_data_test);       
    Y_test = cat(1,zeros(200,1),ones(100,1));
    
    Colp_info_train = cat(1,non_cancer_data_train_colp,cancer_data_train_colp);
    Colp_info_test = cat(1,non_cancer_data_test_colp,cancer_data_test_colp);
    Smear_info_train = cat(1,non_cancer_data_train_smear,cancer_data_train_smear);
    Smear_info_test = cat(1,non_cancer_data_test_smear,cancer_data_test_smear);
    
    
    %% grid search----------------------------------------------------------------------------------------------------------------------

    treeModel = fitctree(X_train, Y_train,'MaxNumSplits',MaxNumSplits_set,'MinParentSize',MinParentSize_set,'MinLeafSize',MinLeafSize_set);

    [Y_pred_train,score_train] = predict(treeModel, X_train);
    [Y_pred_test,score_test]    = predict(treeModel, X_test);
    [Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);

    [x_, y_, T_, AUC_test] = perfcurve(Y_test, score_test(:,2), 1);
    [x_, y_, T_, AUC_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);

    %% ------------------------------------------------------------------------------------------------
    %% step 1
    % find the best threshold based on training data
    % to make the Yuden score on the training results to be the best
    % J = Sensitivity + Specificity -1
    [threshold_best_final, training_specificity_final ,training_sensitivity_final] = threshold_selection(score_train(:,2), Y_train);
    
    %% ------------------------------------------------------------------------------------------------
    %% step 3
    %% calculate the metics on testing set  for Group 1
    [accuracy_test,recall_test ,specificity_test,sensitivity_test] = ConfusionMatrix_cal(score_test(:,2),threshold_best_final,Y_test);
    %% calculate the metics on testing set  for Group 2 from London
    [accuracy_test_London,recall_test_London ,specificity_test_London,sensitivity_test_London] = ConfusionMatrix_cal(score_test_London(:,2),threshold_best_final,Y_test_Group_2);
                   
    %% step 4
    % considering the prior knowledge
    %% 4.1 calculate the prob of each dignosis statistics
    % -----------------------------------------------------------------------------------------------
    % only colp
    
    Train_HG_1_colp_0 = 0;
    Train_HG_1_colp_1 = 0;
    Train_HG_0_colp_0 = 0;
    Train_HG_0_colp_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) 
            Train_HG_1_colp_0 = Train_HG_1_colp_0 +1;
        else
            Train_HG_1_colp_1 = Train_HG_1_colp_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) 
            Train_HG_0_colp_0 = Train_HG_0_colp_0 +1;
        else
            Train_HG_0_colp_1 = Train_HG_0_colp_1 +1;
        end
    end
    
    % -----------------------------------------------------------------------------------------------
    % only smear
    
    Train_HG_1_smear_0 = 0;
    Train_HG_1_smear_1 = 0;
    Train_HG_0_smear_0 = 0;
    Train_HG_0_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_smear(i) == 0) 
            Train_HG_1_smear_0 = Train_HG_1_smear_0 +1;
        else
            Train_HG_1_smear_1 = Train_HG_1_smear_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_smear(i) == 0) 
            Train_HG_0_smear_0 = Train_HG_0_smear_0 +1;
        else
            Train_HG_0_smear_1 = Train_HG_0_smear_1 +1;
        end
    end
    
    
    
    %---------------------------------------------------------------------------------------------------------------
    % colp and smear
    Train_HG_1_colp_0_smear_0 = 0;
    Train_HG_1_colp_0_smear_1 = 0;
    Train_HG_1_colp_1_smear_0 = 0;
    Train_HG_1_colp_1_smear_1 = 0;
    
    Train_HG_0_colp_0_smear_0 = 0;
    Train_HG_0_colp_0_smear_1 = 0;
    Train_HG_0_colp_1_smear_0 = 0;
    Train_HG_0_colp_1_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_0_smear_0 = Train_HG_1_colp_0_smear_0 +1;
    
        elseif (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 1)
            Train_HG_1_colp_0_smear_1 = Train_HG_1_colp_0_smear_1 +1;
    
        elseif (cancer_data_train_colp(i) == 1) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_1_smear_0 = Train_HG_1_colp_1_smear_0 +1;
    
        else
            Train_HG_1_colp_1_smear_1 = Train_HG_1_colp_1_smear_1 +1;
          
        end
    end
    
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_0_smear_0 = Train_HG_0_colp_0_smear_0 +1;
    
        elseif (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 1)
            Train_HG_0_colp_0_smear_1 = Train_HG_0_colp_0_smear_1 +1;
    
        elseif (non_cancer_data_train_colp(i) == 1) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_1_smear_0 = Train_HG_0_colp_1_smear_0 +1;
    
        else
            Train_HG_0_colp_1_smear_1 = Train_HG_0_colp_1_smear_1 +1;
          
        end
    end
        
    %% 4.2 calculate the prob of each dignosis
    % ---------------------------------------------------------------------------------------------------------------
    %% colp
    % colp 0 
    p_h_colp_0 = Train_HG_1_colp_0 / (Train_HG_1_colp_0 + Train_HG_0_colp_0);
    % colp 1
    p_h_colp_1 = Train_HG_1_colp_1/ (Train_HG_1_colp_1 + Train_HG_0_colp_1);
    
    % ---------------------------------------------------------------------------------------------------------------
    %% smear
    % smear 0 
    p_h_smear_0 = Train_HG_1_smear_0 / (Train_HG_1_smear_0 + Train_HG_0_smear_0);
    % smear 1
    p_h_smear_1 = Train_HG_1_smear_1/ (Train_HG_1_smear_1 + Train_HG_0_smear_1);
    
    
    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    %% colp 0 smear 0
    p_h_colp_smear_00 = Train_HG_1_colp_0_smear_0 / (Train_HG_1_colp_0_smear_0 + Train_HG_0_colp_0_smear_0);
    % colp 0 smear 1
    p_h_colp_smear_01 = Train_HG_1_colp_0_smear_1 / (Train_HG_1_colp_0_smear_1 + Train_HG_0_colp_0_smear_1);
    % colp 1 smear 0
    p_h_colp_smear_10 = Train_HG_1_colp_1_smear_0 / (Train_HG_1_colp_1_smear_0 + Train_HG_0_colp_1_smear_0);
    % colp 1 smear 1
    p_h_colp_smear_11 = Train_HG_1_colp_1_smear_1 / (Train_HG_1_colp_1_smear_1 + Train_HG_0_colp_1_smear_1); 


    %% step 5
    % calculate
    % for testing data
    AA_prediction_results_with_bayes_colp  = zeros(size(Y_test,1),1);


    % ---------------------------------------------------------------------------------------------------------------
    % just colp
    for i=1:size(Y_test,1)
        if (score_test(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_test(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Colp_info_test(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_test(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_test(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Colp_info_test(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end
                   
    [x_, y_, T_, AUC_test_add_Bayes_colp] = perfcurve(Y_test, AA_prediction_results_with_bayes_colp, 1);

    % for gourp 2 data from London
    AA_prediction_results_with_bayes_colp_London = zeros(112,1);

    % ---------------------------------------------------------------------------------------------------------------


    for i=1:size(Y_test_Group_2,1)
        if (score_test_London(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_test_London(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Colp_info_test_London(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_test_London(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_test_London(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Colp_info_test_London(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end
    [x_, y_, T_, AUC_test_add_Bayes_colp_London] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_colp_London, 1);




    %% Step 6
    % Bayes results in Training dataset
    % using prior on training results (Y_pred_train,   score_train )
    % and using threshold selection method to find the best threshold on Training 

    AA_prediction_results_with_bayes_colp_train = zeros(1377,1);
    %% step 6.1 calulate the training results processed by prior knowledge
    % just colp
    for i=1:size(Y_train,1)
        if (score_train(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_train(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Colp_info_train(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_train(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_train(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Colp_info_train(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end

    %% Step 6.2 
    %% choose the best threshold from Bayes

    score_train_Bayes_Colp = AA_prediction_results_with_bayes_colp_train;
    % find the best threshold on training curves when using prior knowledge
    [threshold_best_final_train_Bayes_Colp, nono , nono] = threshold_selection(score_train_Bayes_Colp, Y_train);

    [accuracy_test_Colp,recall_test_Colp,specificity_test_Colp,sensitivity_test_Colp]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_colp,threshold_best_final_train_Bayes_Colp,Y_test);
    [accuracy_test_Colp_London,recall_test_Colp_London,specificity_test_Colp_London,sensitivity_test_Colp_London]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_colp_London,threshold_best_final_train_Bayes_Colp,Y_test_Group_2);

    AAA_FINAL_METRICS_SAVE(seed_nn,1:3) = [AUC_test,specificity_test,sensitivity_test] ;
    AAA_FINAL_METRICS_SAVE(seed_nn,4:6) = [AUC_test_add_Bayes_colp,specificity_test_Colp,sensitivity_test_Colp];
    AAA_FINAL_METRICS_SAVE(seed_nn,7:9) = [AUC_test_London,specificity_test_London,sensitivity_test_London];
    AAA_FINAL_METRICS_SAVE(seed_nn,10:12) = [AUC_test_add_Bayes_colp_London, specificity_test_Colp_London, sensitivity_test_Colp_London];
end
AAA_compare = [];
%% calculate the CI mean and std value
for i =1:12
     [mean_val,std_val,ci_lower,ci_upper] = CI_cal(AAA_FINAL_METRICS_SAVE(:,i));
     AAA_compare(i,1) = mean_val;
     AAA_compare(i,2) = std_val;
     AAA_compare(i,3) = ci_lower;
     AAA_compare(i,4) = ci_upper;
end
[Y_pred_train,score_train] = predict(treeModel, X_train);
[Y_pred_test,score_test]    = predict(treeModel, X_test);
[Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);
[x_train, y_train, T_train, AUC_train, theop_train] = perfcurve(Y_train, score_train(:,2), 1);
[x_G1, y_G1, T_G1, AUC_test,theop_test] = perfcurve(Y_test, score_test(:,2), 1);
[x_G1_b, y_G1_b, T_, AUC_test_add_Bayes_colp,theop_test_b] = perfcurve(Y_test, AA_prediction_results_with_bayes_colp, 1);
[x_G2, y_G2, T_G2, AUC_test_London,theop_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);
[x_G2_b, y_G2_b, T_, AUC_test_add_Bayes_colp_London,theop_test_London_b] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_colp_London, 1);
%% for plotting
color_1 = '[ 0 0.78 0.55]';
color_2 = '[0.25 0.41 0.88]';
color_3 = '[1 0.6 0]';
%% for group 1
figure(1);subplot(4,4,5)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G1,y_G1,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G1_b, y_G1_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_b(1),theop_test_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_colp,threshold_best_final_train_Bayes_Colp,Y_test);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group1 ROC (DT)');legend([p_1,p_2],'Test results','Test results (PK)')

%% for group 2
figure(2);subplot(4,4,5)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G2,y_G2,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G2_b, y_G2_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_London_b(1),theop_test_London_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_colp_London, threshold_best_final_train_Bayes_Colp, Y_test_Group_2);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group2 ROC (DT)');legend([p_1,p_2],'Test results','Test results (PK)')

%% -----------------------------------------------------------------------------------------------------------------------
%% -----------------------------------------------------------------------------------------------------------------------

clc
clear
%% load data ---------------------------------------------------------------------------------------------------------
% Group 1
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_Cancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_NonCancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_cancer_data_and_info.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_non_cancer_data_and_info.mat')
% Group 2
load('../../data/cervical data London/postprocessed_by_Lin/Cervical_Group_2_coleModel_MaxDiffMean_112.mat')
%% data filtering ----------------------------------------------------------------------------------------------------
%% Group 2
G2_cancer          = cat(2,Cervical_Group_2_cancer_MeanValues,          Cervical_Group_2_cancer_MaxDiff);
G2_non_cancer = cat(2,Cervical_Group_2_non_cancer_MeanValues,Cervical_Group_2_non_cancer_MaxDiff);
X_test_Group_2 = cat(1,G2_non_cancer,G2_cancer);
Y_test_Group_2 = cat(1,zeros(93,1),        ones(19,1));
Group_2_Colp_info     =cat(1,Cervical_Group_2_non_cancer_info.Colp,    Cervical_Group_2_cancer_info.Colp);
Group_2_Smear_info  =cat(1,Cervical_Group_2_non_cancer_info.Smear,Cervical_Group_2_cancer_info.Smear);
Colp_info_test_London = Group_2_Colp_info;
Smear_info_test_London = Group_2_Smear_info;
%% Group 1
G1_cancer          = cat(2,Cervical_Group_1_cancer_MeanValues,          Cervical_Group_1_cancer_MaxDiff);
G1_non_cancer = cat(2,Cervical_Group_1_non_cancer_MeanValues,Cervical_Group_1_non_cancer_MaxDiff);

%% ----------------------------------------------------------------------------------------------------------------------
% the best pair of hyper-para
NumTrees_set = 120;
MinLeafSize_set  = 10;
MaxNumSplits_set  = 10;

AAA_FINAL_METRICS_SAVE = zeros(100,9);
%  AUC_test,                                    specificity_test,                    sensitivity_test,
%  AUC_test_add_Bayes_G1,       specificity_test_G1,             sensitivity_test_G1,
%  AUC_test_add_Bayes_G2,       specificity_test_G2,             sensitivity_test_G2,

for seed_nn = 4
    fprintf('the round is in %d \n',seed_nn);
    rng(seed_nn);index_record_line = 1;

    %% split the data Group1  to training and testing dataset --------------------------------------------------------------------------------------------------------------------
    % cancer data 528             vali and test      428:100
    % non cancer data 1149   vali and test      949:200
    indices_1 = randperm(528);
    Indices_train_1 = indices_1(1:428);
    Indices_test_1 = indices_1(429:end);
    
    cancer_data_train                 = G1_cancer(Indices_train_1,:);
    cancer_data_test                  =  G1_cancer(Indices_test_1,:);
    cancer_data_train_colp      = Cervical_Group_1_cancer_info.Colp_list(Indices_train_1);
    cancer_data_test_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_test_1);
    cancer_data_train_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_train_1);
    cancer_data_test_smear   = Cervical_Group_1_cancer_info.Smear_list(Indices_test_1);
    
    indices_0 = randperm(1149);
    Indices_train_0 = indices_0(1:949);
    Indices_test_0 = indices_0(950:end);
    
    non_cancer_data_train             = G1_non_cancer(Indices_train_0,:);
    non_cancer_data_test               = G1_non_cancer(Indices_test_0,:);
    non_cancer_data_train_colp    = Cervical_Group_1_non_cancer_info.Colp_list(Indices_train_0);
    non_cancer_data_test_colp      = Cervical_Group_1_non_cancer_info.Colp_list(Indices_test_0);
    non_cancer_data_train_smear = Cervical_Group_1_non_cancer_info.Smear_list(Indices_train_0);
    non_cancer_data_test_smear   = Cervical_Group_1_non_cancer_info.Smear_list(Indices_test_0);
    
    
    X_train = cat(1,non_cancer_data_train ,cancer_data_train); 
    Y_train = cat(1,zeros(949,1),ones(428,1));
    X_test = cat(1,non_cancer_data_test ,cancer_data_test);       
    Y_test = cat(1,zeros(200,1),ones(100,1));
    
    Colp_info_train = cat(1,non_cancer_data_train_colp,cancer_data_train_colp);
    Colp_info_test = cat(1,non_cancer_data_test_colp,cancer_data_test_colp);
    Smear_info_train = cat(1,non_cancer_data_train_smear,cancer_data_train_smear);
    Smear_info_test = cat(1,non_cancer_data_test_smear,cancer_data_test_smear);
    
    
    %% grid search----------------------------------------------------------------------------------------------------------------------

    treeModel = TreeBagger(NumTrees_set, X_train, Y_train, 'MaxNumSplits', MaxNumSplits_set ,'MinLeafSize',MinLeafSize_set,'NumPredictorsToSample',2,'Method','classification');

    [Y_pred_train,score_train] = predict(treeModel, X_train);
    [Y_pred_test,score_test]    = predict(treeModel, X_test);
    [Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);

    [x_, y_, T_, AUC_test] = perfcurve(Y_test, score_test(:,2), 1);
    [x_, y_, T_, AUC_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);

    %% ------------------------------------------------------------------------------------------------
    %% step 1
    % find the best threshold based on training data
    % to make the Yuden score on the training results to be the best
    % J = Sensitivity + Specificity -1
    [threshold_best_final, training_specificity_final ,training_sensitivity_final] = threshold_selection(score_train(:,2), Y_train);
    
    %% ------------------------------------------------------------------------------------------------
    %% step 3
    %% calculate the metics on testing set  for Group 1
    [accuracy_test,recall_test ,specificity_test,sensitivity_test] = ConfusionMatrix_cal(score_test(:,2),threshold_best_final,Y_test);
    %% calculate the metics on testing set  for Group 2 from London
    [accuracy_test_London,recall_test_London ,specificity_test_London,sensitivity_test_London] = ConfusionMatrix_cal(score_test_London(:,2),threshold_best_final,Y_test_Group_2);
                   
    %% step 4
    % considering the prior knowledge
    %% 4.1 calculate the prob of each dignosis statistics
    % -----------------------------------------------------------------------------------------------
    % only colp
    
    Train_HG_1_colp_0 = 0;
    Train_HG_1_colp_1 = 0;
    Train_HG_0_colp_0 = 0;
    Train_HG_0_colp_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) 
            Train_HG_1_colp_0 = Train_HG_1_colp_0 +1;
        else
            Train_HG_1_colp_1 = Train_HG_1_colp_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) 
            Train_HG_0_colp_0 = Train_HG_0_colp_0 +1;
        else
            Train_HG_0_colp_1 = Train_HG_0_colp_1 +1;
        end
    end
    
    % -----------------------------------------------------------------------------------------------
    % only smear
    
    Train_HG_1_smear_0 = 0;
    Train_HG_1_smear_1 = 0;
    Train_HG_0_smear_0 = 0;
    Train_HG_0_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_smear(i) == 0) 
            Train_HG_1_smear_0 = Train_HG_1_smear_0 +1;
        else
            Train_HG_1_smear_1 = Train_HG_1_smear_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_smear(i) == 0) 
            Train_HG_0_smear_0 = Train_HG_0_smear_0 +1;
        else
            Train_HG_0_smear_1 = Train_HG_0_smear_1 +1;
        end
    end
    
    
    
    %---------------------------------------------------------------------------------------------------------------
    % colp and smear
    Train_HG_1_colp_0_smear_0 = 0;
    Train_HG_1_colp_0_smear_1 = 0;
    Train_HG_1_colp_1_smear_0 = 0;
    Train_HG_1_colp_1_smear_1 = 0;
    
    Train_HG_0_colp_0_smear_0 = 0;
    Train_HG_0_colp_0_smear_1 = 0;
    Train_HG_0_colp_1_smear_0 = 0;
    Train_HG_0_colp_1_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_0_smear_0 = Train_HG_1_colp_0_smear_0 +1;
    
        elseif (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 1)
            Train_HG_1_colp_0_smear_1 = Train_HG_1_colp_0_smear_1 +1;
    
        elseif (cancer_data_train_colp(i) == 1) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_1_smear_0 = Train_HG_1_colp_1_smear_0 +1;
    
        else
            Train_HG_1_colp_1_smear_1 = Train_HG_1_colp_1_smear_1 +1;
          
        end
    end
    
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_0_smear_0 = Train_HG_0_colp_0_smear_0 +1;
    
        elseif (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 1)
            Train_HG_0_colp_0_smear_1 = Train_HG_0_colp_0_smear_1 +1;
    
        elseif (non_cancer_data_train_colp(i) == 1) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_1_smear_0 = Train_HG_0_colp_1_smear_0 +1;
    
        else
            Train_HG_0_colp_1_smear_1 = Train_HG_0_colp_1_smear_1 +1;
          
        end
    end
        
    %% 4.2 calculate the prob of each dignosis
    % ---------------------------------------------------------------------------------------------------------------
    %% colp
    % colp 0 
    p_h_colp_0 = Train_HG_1_colp_0 / (Train_HG_1_colp_0 + Train_HG_0_colp_0);
    % colp 1
    p_h_colp_1 = Train_HG_1_colp_1/ (Train_HG_1_colp_1 + Train_HG_0_colp_1);
    
    % ---------------------------------------------------------------------------------------------------------------
    %% smear
    % smear 0 
    p_h_smear_0 = Train_HG_1_smear_0 / (Train_HG_1_smear_0 + Train_HG_0_smear_0);
    % smear 1
    p_h_smear_1 = Train_HG_1_smear_1/ (Train_HG_1_smear_1 + Train_HG_0_smear_1);
    
    
    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    %% colp 0 smear 0
    p_h_colp_smear_00 = Train_HG_1_colp_0_smear_0 / (Train_HG_1_colp_0_smear_0 + Train_HG_0_colp_0_smear_0);
    % colp 0 smear 1
    p_h_colp_smear_01 = Train_HG_1_colp_0_smear_1 / (Train_HG_1_colp_0_smear_1 + Train_HG_0_colp_0_smear_1);
    % colp 1 smear 0
    p_h_colp_smear_10 = Train_HG_1_colp_1_smear_0 / (Train_HG_1_colp_1_smear_0 + Train_HG_0_colp_1_smear_0);
    % colp 1 smear 1
    p_h_colp_smear_11 = Train_HG_1_colp_1_smear_1 / (Train_HG_1_colp_1_smear_1 + Train_HG_0_colp_1_smear_1); 


    %% step 5
    % calculate
    % for testing data
    AA_prediction_results_with_bayes_colp  = zeros(size(Y_test,1),1);


    % ---------------------------------------------------------------------------------------------------------------
    % just colp
    for i=1:size(Y_test,1)
        if (score_test(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_test(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Colp_info_test(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_test(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_test(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Colp_info_test(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end
                   
    [x_, y_, T_, AUC_test_add_Bayes_colp] = perfcurve(Y_test, AA_prediction_results_with_bayes_colp, 1);

    % for gourp 2 data from London
    AA_prediction_results_with_bayes_colp_London = zeros(112,1);

    % ---------------------------------------------------------------------------------------------------------------


    for i=1:size(Y_test_Group_2,1)
        if (score_test_London(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_test_London(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Colp_info_test_London(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_test_London(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_test_London(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Colp_info_test_London(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end
    [x_, y_, T_, AUC_test_add_Bayes_colp_London] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_colp_London, 1);




    %% Step 6
    % Bayes results in Training dataset
    % using prior on training results (Y_pred_train,   score_train )
    % and using threshold selection method to find the best threshold on Training 

    AA_prediction_results_with_bayes_colp_train = zeros(1377,1);
    %% step 6.1 calulate the training results processed by prior knowledge
    % just colp
    for i=1:size(Y_train,1)
        if (score_train(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_train(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Colp_info_train(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_train(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_train(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Colp_info_train(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end

    %% Step 6.2 
    %% choose the best threshold from Bayes

    score_train_Bayes_Colp = AA_prediction_results_with_bayes_colp_train;
    % find the best threshold on training curves when using prior knowledge
    [threshold_best_final_train_Bayes_Colp, nono , nono] = threshold_selection(score_train_Bayes_Colp, Y_train);

    [accuracy_test_Colp,recall_test_Colp,specificity_test_Colp,sensitivity_test_Colp]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_colp,threshold_best_final_train_Bayes_Colp,Y_test);
    [accuracy_test_Colp_London,recall_test_Colp_London,specificity_test_Colp_London,sensitivity_test_Colp_London]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_colp_London,threshold_best_final_train_Bayes_Colp,Y_test_Group_2);

    AAA_FINAL_METRICS_SAVE(seed_nn,1:3) = [AUC_test,specificity_test,sensitivity_test] ;
    AAA_FINAL_METRICS_SAVE(seed_nn,4:6) = [AUC_test_add_Bayes_colp,specificity_test_Colp,sensitivity_test_Colp];
    AAA_FINAL_METRICS_SAVE(seed_nn,7:9) = [AUC_test_London,specificity_test_London,sensitivity_test_London];
    AAA_FINAL_METRICS_SAVE(seed_nn,10:12) = [AUC_test_add_Bayes_colp_London, specificity_test_Colp_London, sensitivity_test_Colp_London];


end

AAA_compare = [];
%% calculate the CI mean and std value
for i =1:12
     [mean_val,std_val,ci_lower,ci_upper] = CI_cal(AAA_FINAL_METRICS_SAVE(:,i));
     AAA_compare(i,1) = mean_val;
     AAA_compare(i,2) = std_val;
     AAA_compare(i,3) = ci_lower;
     AAA_compare(i,4) = ci_upper;
end
[Y_pred_train,score_train] = predict(treeModel, X_train);
[Y_pred_test,score_test]    = predict(treeModel, X_test);
[Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);
[x_train, y_train, T_train, AUC_train, theop_train] = perfcurve(Y_train, score_train(:,2), 1);
[x_G1, y_G1, T_G1, AUC_test,theop_test] = perfcurve(Y_test, score_test(:,2), 1);
[x_G1_b, y_G1_b, T_, AUC_test_add_Bayes_colp,theop_test_b] = perfcurve(Y_test, AA_prediction_results_with_bayes_colp, 1);
[x_G2, y_G2, T_G2, AUC_test_London,theop_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);
[x_G2_b, y_G2_b, T_, AUC_test_add_Bayes_colp_London,theop_test_London_b] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_colp_London, 1);
%% for plotting
color_1 = '[ 0 0.78 0.55]';
color_2 = '[0.25 0.41 0.88]';
color_3 = '[1 0.6 0]';
%% for group 1
figure(1);subplot(4,4,6)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G1,y_G1,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G1_b, y_G1_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_b(1),theop_test_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_colp,threshold_best_final_train_Bayes_Colp,Y_test);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group1 ROC (RF)');legend([p_1,p_2],'Test results','Test results (PK)')

%% for group 2
figure(2);subplot(4,4,6)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G2,y_G2,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G2_b, y_G2_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_London_b(1),theop_test_London_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_colp_London, threshold_best_final_train_Bayes_Colp, Y_test_Group_2);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group2 ROC (RF)');legend([p_1,p_2],'Test results','Test results (PK)')


%% ----------------------------------------------------------------------------------------------------------------------
%% ----------------------------------------------------------------------------------------------------------------------
clc
clear
%% load data ---------------------------------------------------------------------------------------------------------
% Group 1
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_Cancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_NonCancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_cancer_data_and_info.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_non_cancer_data_and_info.mat')
% Group 2
load('../../data/cervical data London/postprocessed_by_Lin/Cervical_Group_2_coleModel_MaxDiffMean_112.mat')
%% data filtering ----------------------------------------------------------------------------------------------------
%% Group 2
G2_cancer          = cat(2,Cervical_Group_2_cancer_MeanValues,          Cervical_Group_2_cancer_MaxDiff);
G2_non_cancer = cat(2,Cervical_Group_2_non_cancer_MeanValues,Cervical_Group_2_non_cancer_MaxDiff);
X_test_Group_2 = cat(1,G2_non_cancer,G2_cancer);
Y_test_Group_2 = cat(1,zeros(93,1),        ones(19,1));
Group_2_Colp_info     =cat(1,Cervical_Group_2_non_cancer_info.Colp,    Cervical_Group_2_cancer_info.Colp);
Group_2_Smear_info  =cat(1,Cervical_Group_2_non_cancer_info.Smear,Cervical_Group_2_cancer_info.Smear);
Colp_info_test_London = Group_2_Colp_info;
Smear_info_test_London = Group_2_Smear_info;
%% Group 1
G1_cancer          = cat(2,Cervical_Group_1_cancer_MeanValues,          Cervical_Group_1_cancer_MaxDiff);
G1_non_cancer = cat(2,Cervical_Group_1_non_cancer_MeanValues,Cervical_Group_1_non_cancer_MaxDiff);

%% ----------------------------------------------------------------------------------------------------------------------
% the best pair of hyper-para


AAA_FINAL_METRICS_SAVE = zeros(100,9);
%  AUC_test,                                    specificity_test,                    sensitivity_test,
%  AUC_test_add_Bayes_G1,       specificity_test_G1,             sensitivity_test_G1,
%  AUC_test_add_Bayes_G2,       specificity_test_G2,             sensitivity_test_G2,

for seed_nn = 4
    fprintf('the round is in %d \n',seed_nn);
    rng(seed_nn);index_record_line = 1;

    %% split the data Group1  to training and testing dataset --------------------------------------------------------------------------------------------------------------------
    % cancer data 528             vali and test      428:100
    % non cancer data 1149   vali and test      949:200
    indices_1 = randperm(528);
    Indices_train_1 = indices_1(1:428);
    Indices_test_1 = indices_1(429:end);
    
    cancer_data_train                 = G1_cancer(Indices_train_1,:);
    cancer_data_test                  =  G1_cancer(Indices_test_1,:);
    cancer_data_train_colp      = Cervical_Group_1_cancer_info.Colp_list(Indices_train_1);
    cancer_data_test_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_test_1);
    cancer_data_train_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_train_1);
    cancer_data_test_smear   = Cervical_Group_1_cancer_info.Smear_list(Indices_test_1);
    
    indices_0 = randperm(1149);
    Indices_train_0 = indices_0(1:949);
    Indices_test_0 = indices_0(950:end);
    
    non_cancer_data_train             = G1_non_cancer(Indices_train_0,:);
    non_cancer_data_test               = G1_non_cancer(Indices_test_0,:);
    non_cancer_data_train_colp    = Cervical_Group_1_non_cancer_info.Colp_list(Indices_train_0);
    non_cancer_data_test_colp      = Cervical_Group_1_non_cancer_info.Colp_list(Indices_test_0);
    non_cancer_data_train_smear = Cervical_Group_1_non_cancer_info.Smear_list(Indices_train_0);
    non_cancer_data_test_smear   = Cervical_Group_1_non_cancer_info.Smear_list(Indices_test_0);
    
    
    X_train = cat(1,non_cancer_data_train ,cancer_data_train); 
    Y_train = cat(1,zeros(949,1),ones(428,1));
    X_test = cat(1,non_cancer_data_test ,cancer_data_test);       
    Y_test = cat(1,zeros(200,1),ones(100,1));
    
    Colp_info_train = cat(1,non_cancer_data_train_colp,cancer_data_train_colp);
    Colp_info_test = cat(1,non_cancer_data_test_colp,cancer_data_test_colp);
    Smear_info_train = cat(1,non_cancer_data_train_smear,cancer_data_train_smear);
    Smear_info_test = cat(1,non_cancer_data_test_smear,cancer_data_test_smear);
    
    
    %% grid search----------------------------------------------------------------------------------------------------------------------

    treeModel = fitcsvm(X_train, Y_train,'KernelFunction','rbf','BoxConstraint', 0.001,'Standardize',true);

    [Y_pred_train,score_train] = predict(treeModel, X_train);
    [Y_pred_test,score_test]    = predict(treeModel, X_test);
    [Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);

    [x_, y_, T_, AUC_test] = perfcurve(Y_test, score_test(:,2), 1);
    [x_, y_, T_, AUC_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);

    %% ------------------------------------------------------------------------------------------------
    %% step 1
    % find the best threshold based on training data
    % to make the Yuden score on the training results to be the best
    % J = Sensitivity + Specificity -1
    [threshold_best_final, training_specificity_final ,training_sensitivity_final] = threshold_selection(score_train(:,2), Y_train);
    
    %% ------------------------------------------------------------------------------------------------
    %% step 3
    %% calculate the metics on testing set  for Group 1
    [accuracy_test,recall_test ,specificity_test,sensitivity_test] = ConfusionMatrix_cal(score_test(:,2),threshold_best_final,Y_test);
    %% calculate the metics on testing set  for Group 2 from London
    [accuracy_test_London,recall_test_London ,specificity_test_London,sensitivity_test_London] = ConfusionMatrix_cal(score_test_London(:,2),threshold_best_final,Y_test_Group_2);
                   
    %% step 4
    % considering the prior knowledge
    %% 4.1 calculate the prob of each dignosis statistics
    % -----------------------------------------------------------------------------------------------
    % only colp
    
    Train_HG_1_colp_0 = 0;
    Train_HG_1_colp_1 = 0;
    Train_HG_0_colp_0 = 0;
    Train_HG_0_colp_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) 
            Train_HG_1_colp_0 = Train_HG_1_colp_0 +1;
        else
            Train_HG_1_colp_1 = Train_HG_1_colp_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) 
            Train_HG_0_colp_0 = Train_HG_0_colp_0 +1;
        else
            Train_HG_0_colp_1 = Train_HG_0_colp_1 +1;
        end
    end
    
    % -----------------------------------------------------------------------------------------------
    % only smear
    
    Train_HG_1_smear_0 = 0;
    Train_HG_1_smear_1 = 0;
    Train_HG_0_smear_0 = 0;
    Train_HG_0_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_smear(i) == 0) 
            Train_HG_1_smear_0 = Train_HG_1_smear_0 +1;
        else
            Train_HG_1_smear_1 = Train_HG_1_smear_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_smear(i) == 0) 
            Train_HG_0_smear_0 = Train_HG_0_smear_0 +1;
        else
            Train_HG_0_smear_1 = Train_HG_0_smear_1 +1;
        end
    end
    
    
    
    %---------------------------------------------------------------------------------------------------------------
    % colp and smear
    Train_HG_1_colp_0_smear_0 = 0;
    Train_HG_1_colp_0_smear_1 = 0;
    Train_HG_1_colp_1_smear_0 = 0;
    Train_HG_1_colp_1_smear_1 = 0;
    
    Train_HG_0_colp_0_smear_0 = 0;
    Train_HG_0_colp_0_smear_1 = 0;
    Train_HG_0_colp_1_smear_0 = 0;
    Train_HG_0_colp_1_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_0_smear_0 = Train_HG_1_colp_0_smear_0 +1;
    
        elseif (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 1)
            Train_HG_1_colp_0_smear_1 = Train_HG_1_colp_0_smear_1 +1;
    
        elseif (cancer_data_train_colp(i) == 1) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_1_smear_0 = Train_HG_1_colp_1_smear_0 +1;
    
        else
            Train_HG_1_colp_1_smear_1 = Train_HG_1_colp_1_smear_1 +1;
          
        end
    end
    
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_0_smear_0 = Train_HG_0_colp_0_smear_0 +1;
    
        elseif (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 1)
            Train_HG_0_colp_0_smear_1 = Train_HG_0_colp_0_smear_1 +1;
    
        elseif (non_cancer_data_train_colp(i) == 1) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_1_smear_0 = Train_HG_0_colp_1_smear_0 +1;
    
        else
            Train_HG_0_colp_1_smear_1 = Train_HG_0_colp_1_smear_1 +1;
          
        end
    end
        
    %% 4.2 calculate the prob of each dignosis
    % ---------------------------------------------------------------------------------------------------------------
    %% colp
    % colp 0 
    p_h_colp_0 = Train_HG_1_colp_0 / (Train_HG_1_colp_0 + Train_HG_0_colp_0);
    % colp 1
    p_h_colp_1 = Train_HG_1_colp_1/ (Train_HG_1_colp_1 + Train_HG_0_colp_1);
    
    % ---------------------------------------------------------------------------------------------------------------
    %% smear
    % smear 0 
    p_h_smear_0 = Train_HG_1_smear_0 / (Train_HG_1_smear_0 + Train_HG_0_smear_0);
    % smear 1
    p_h_smear_1 = Train_HG_1_smear_1/ (Train_HG_1_smear_1 + Train_HG_0_smear_1);
    
    
    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    %% colp 0 smear 0
    p_h_colp_smear_00 = Train_HG_1_colp_0_smear_0 / (Train_HG_1_colp_0_smear_0 + Train_HG_0_colp_0_smear_0);
    % colp 0 smear 1
    p_h_colp_smear_01 = Train_HG_1_colp_0_smear_1 / (Train_HG_1_colp_0_smear_1 + Train_HG_0_colp_0_smear_1);
    % colp 1 smear 0
    p_h_colp_smear_10 = Train_HG_1_colp_1_smear_0 / (Train_HG_1_colp_1_smear_0 + Train_HG_0_colp_1_smear_0);
    % colp 1 smear 1
    p_h_colp_smear_11 = Train_HG_1_colp_1_smear_1 / (Train_HG_1_colp_1_smear_1 + Train_HG_0_colp_1_smear_1); 


    %% step 5
    % calculate
    % for testing data
    AA_prediction_results_with_bayes_colp  = zeros(size(Y_test,1),1);


    % ---------------------------------------------------------------------------------------------------------------
    % just colp
    for i=1:size(Y_test,1)
        if (score_test(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_test(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Colp_info_test(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_test(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_test(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Colp_info_test(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end
                   
    [x_, y_, T_, AUC_test_add_Bayes_colp] = perfcurve(Y_test, AA_prediction_results_with_bayes_colp, 1);

    % for gourp 2 data from London
    AA_prediction_results_with_bayes_colp_London = zeros(112,1);

    % ---------------------------------------------------------------------------------------------------------------


    for i=1:size(Y_test_Group_2,1)
        if (score_test_London(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_test_London(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Colp_info_test_London(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_test_London(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_test_London(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Colp_info_test_London(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end
    [x_, y_, T_, AUC_test_add_Bayes_colp_London] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_colp_London, 1);




    %% Step 6
    % Bayes results in Training dataset
    % using prior on training results (Y_pred_train,   score_train )
    % and using threshold selection method to find the best threshold on Training 

    AA_prediction_results_with_bayes_colp_train = zeros(1377,1);
    %% step 6.1 calulate the training results processed by prior knowledge
    % just colp
    for i=1:size(Y_train,1)
        if (score_train(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_train(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Colp_info_train(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_train(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_train(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Colp_info_train(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end

    %% Step 6.2 
    %% choose the best threshold from Bayes

    score_train_Bayes_Colp = AA_prediction_results_with_bayes_colp_train;
    % find the best threshold on training curves when using prior knowledge
    [threshold_best_final_train_Bayes_Colp, nono , nono] = threshold_selection(score_train_Bayes_Colp, Y_train);

    [accuracy_test_Colp,recall_test_Colp,specificity_test_Colp,sensitivity_test_Colp]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_colp,threshold_best_final_train_Bayes_Colp,Y_test);
    [accuracy_test_Colp_London,recall_test_Colp_London,specificity_test_Colp_London,sensitivity_test_Colp_London]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_colp_London,threshold_best_final_train_Bayes_Colp,Y_test_Group_2);

    AAA_FINAL_METRICS_SAVE(seed_nn,1:3) = [AUC_test,specificity_test,sensitivity_test] ;
    AAA_FINAL_METRICS_SAVE(seed_nn,4:6) = [AUC_test_add_Bayes_colp,specificity_test_Colp,sensitivity_test_Colp];
    AAA_FINAL_METRICS_SAVE(seed_nn,7:9) = [AUC_test_London,specificity_test_London,sensitivity_test_London];
    AAA_FINAL_METRICS_SAVE(seed_nn,10:12) = [AUC_test_add_Bayes_colp_London, specificity_test_Colp_London, sensitivity_test_Colp_London];


end
AAA_compare = [];
%% calculate the CI mean and std value
for i =1:12
     [mean_val,std_val,ci_lower,ci_upper] = CI_cal(AAA_FINAL_METRICS_SAVE(:,i));
     AAA_compare(i,1) = mean_val;
     AAA_compare(i,2) = std_val;
     AAA_compare(i,3) = ci_lower;
     AAA_compare(i,4) = ci_upper;
end
[Y_pred_train,score_train] = predict(treeModel, X_train);
[Y_pred_test,score_test]    = predict(treeModel, X_test);
[Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);
[x_train, y_train, T_train, AUC_train, theop_train] = perfcurve(Y_train, score_train(:,2), 1);
[x_G1, y_G1, T_G1, AUC_test,theop_test] = perfcurve(Y_test, score_test(:,2), 1);
[x_G1_b, y_G1_b, T_, AUC_test_add_Bayes_colp,theop_test_b] = perfcurve(Y_test, AA_prediction_results_with_bayes_colp, 1);
[x_G2, y_G2, T_G2, AUC_test_London,theop_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);
[x_G2_b, y_G2_b, T_, AUC_test_add_Bayes_colp_London,theop_test_London_b] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_colp_London, 1);
%% for plotting
color_1 = '[ 0 0.78 0.55]';
color_2 = '[0.25 0.41 0.88]';
color_3 = '[1 0.6 0]';
%% for group 1
figure(1);subplot(4,4,7)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G1,y_G1,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G1_b, y_G1_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_b(1),theop_test_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_colp,threshold_best_final_train_Bayes_Colp,Y_test);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group1 ROC (SVM)');legend([p_1,p_2],'Test results','Test results (PK)')

%% for group 2
figure(2);subplot(4,4,7)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G2,y_G2,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G2_b, y_G2_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_London_b(1),theop_test_London_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_colp_London, threshold_best_final_train_Bayes_Colp, Y_test_Group_2);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group2 ROC (SVM)');legend([p_1,p_2],'Test results','Test results (PK)')


%% -----------------------------------------------------------------------------------------------------------------------
%% -----------------------------------------------------------------------------------------------------------------------
clc
clear
%% load data ---------------------------------------------------------------------------------------------------------
% Group 1
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_Cancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_NonCancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_cancer_data_and_info.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_non_cancer_data_and_info.mat')
% Group 2
load('../../data/cervical data London/postprocessed_by_Lin/Cervical_Group_2_coleModel_MaxDiffMean_112.mat')
%% data filtering ----------------------------------------------------------------------------------------------------
%% Group 2
G2_cancer          = cat(2,Cervical_Group_2_cancer_MeanValues,          Cervical_Group_2_cancer_MaxDiff);
G2_non_cancer = cat(2,Cervical_Group_2_non_cancer_MeanValues,Cervical_Group_2_non_cancer_MaxDiff);
X_test_Group_2 = cat(1,G2_non_cancer,G2_cancer);
Y_test_Group_2 = cat(1,zeros(93,1),        ones(19,1));
Group_2_Colp_info     =cat(1,Cervical_Group_2_non_cancer_info.Colp,    Cervical_Group_2_cancer_info.Colp);
Group_2_Smear_info  =cat(1,Cervical_Group_2_non_cancer_info.Smear,Cervical_Group_2_cancer_info.Smear);
Colp_info_test_London = Group_2_Colp_info;
Smear_info_test_London = Group_2_Smear_info;
%% Group 1
G1_cancer          = cat(2,Cervical_Group_1_cancer_MeanValues,          Cervical_Group_1_cancer_MaxDiff);
G1_non_cancer = cat(2,Cervical_Group_1_non_cancer_MeanValues,Cervical_Group_1_non_cancer_MaxDiff);

%% ----------------------------------------------------------------------------------------------------------------------
% the best pair of hyper-para
NumTrees_set = 120;
MinLeafSize_set  = 10;
MaxNumSplits_set  = 10;

AAA_FINAL_METRICS_SAVE = zeros(100,9);
%  AUC_test,                                    specificity_test,                    sensitivity_test,
%  AUC_test_add_Bayes_G1,       specificity_test_G1,             sensitivity_test_G1,
%  AUC_test_add_Bayes_G2,       specificity_test_G2,             sensitivity_test_G2,

for seed_nn = 4
    fprintf('the round is in %d \n',seed_nn);
    rng(seed_nn);index_record_line = 1;

    %% split the data Group1  to training and testing dataset --------------------------------------------------------------------------------------------------------------------
    % cancer data 528             vali and test      428:100
    % non cancer data 1149   vali and test      949:200
    indices_1 = randperm(528);
    Indices_train_1 = indices_1(1:428);
    Indices_test_1 = indices_1(429:end);
    
    cancer_data_train                 = G1_cancer(Indices_train_1,:);
    cancer_data_test                  =  G1_cancer(Indices_test_1,:);
    cancer_data_train_colp      = Cervical_Group_1_cancer_info.Colp_list(Indices_train_1);
    cancer_data_test_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_test_1);
    cancer_data_train_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_train_1);
    cancer_data_test_smear   = Cervical_Group_1_cancer_info.Smear_list(Indices_test_1);
    
    indices_0 = randperm(1149);
    Indices_train_0 = indices_0(1:949);
    Indices_test_0 = indices_0(950:end);
    
    non_cancer_data_train             = G1_non_cancer(Indices_train_0,:);
    non_cancer_data_test               = G1_non_cancer(Indices_test_0,:);
    non_cancer_data_train_colp    = Cervical_Group_1_non_cancer_info.Colp_list(Indices_train_0);
    non_cancer_data_test_colp      = Cervical_Group_1_non_cancer_info.Colp_list(Indices_test_0);
    non_cancer_data_train_smear = Cervical_Group_1_non_cancer_info.Smear_list(Indices_train_0);
    non_cancer_data_test_smear   = Cervical_Group_1_non_cancer_info.Smear_list(Indices_test_0);
    
    
    X_train = cat(1,non_cancer_data_train ,cancer_data_train); 
    Y_train = cat(1,zeros(949,1),ones(428,1));
    X_test = cat(1,non_cancer_data_test ,cancer_data_test);       
    Y_test = cat(1,zeros(200,1),ones(100,1));
    
    Colp_info_train = cat(1,non_cancer_data_train_colp,cancer_data_train_colp);
    Colp_info_test = cat(1,non_cancer_data_test_colp,cancer_data_test_colp);
    Smear_info_train = cat(1,non_cancer_data_train_smear,cancer_data_train_smear);
    Smear_info_test = cat(1,non_cancer_data_test_smear,cancer_data_test_smear);
    
    
    %% grid search----------------------------------------------------------------------------------------------------------------------

    treeModel = fitcnet(X_train, Y_train, ...
                                        'Standardize', true, ...
                                        'LayerSizes', [10], ...  % 两层隐藏层，分别有 10 和 5 个神经元
                                        'Activations', 'relu');     % 可选：'relu', 'tanh', 'sigmoid'
    [Y_pred_train,score_train] = predict(treeModel, X_train);
    [Y_pred_test,score_test]    = predict(treeModel, X_test);
    [Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);

    [x_, y_, T_, AUC_test] = perfcurve(Y_test, score_test(:,2), 1);
    [x_, y_, T_, AUC_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);

    %% ------------------------------------------------------------------------------------------------
    %% step 1
    % find the best threshold based on training data
    % to make the Yuden score on the training results to be the best
    % J = Sensitivity + Specificity -1
    [threshold_best_final, training_specificity_final ,training_sensitivity_final] = threshold_selection(score_train(:,2), Y_train);
    
    %% ------------------------------------------------------------------------------------------------
    %% step 3
    %% calculate the metics on testing set  for Group 1
    [accuracy_test,recall_test ,specificity_test,sensitivity_test] = ConfusionMatrix_cal(score_test(:,2),threshold_best_final,Y_test);
    %% calculate the metics on testing set  for Group 2 from London
    [accuracy_test_London,recall_test_London ,specificity_test_London,sensitivity_test_London] = ConfusionMatrix_cal(score_test_London(:,2),threshold_best_final,Y_test_Group_2);
                   
    %% step 4
    % considering the prior knowledge
    %% 4.1 calculate the prob of each dignosis statistics
    % -----------------------------------------------------------------------------------------------
    % only colp
    
    Train_HG_1_colp_0 = 0;
    Train_HG_1_colp_1 = 0;
    Train_HG_0_colp_0 = 0;
    Train_HG_0_colp_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) 
            Train_HG_1_colp_0 = Train_HG_1_colp_0 +1;
        else
            Train_HG_1_colp_1 = Train_HG_1_colp_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) 
            Train_HG_0_colp_0 = Train_HG_0_colp_0 +1;
        else
            Train_HG_0_colp_1 = Train_HG_0_colp_1 +1;
        end
    end
    
    % -----------------------------------------------------------------------------------------------
    % only smear
    
    Train_HG_1_smear_0 = 0;
    Train_HG_1_smear_1 = 0;
    Train_HG_0_smear_0 = 0;
    Train_HG_0_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_smear(i) == 0) 
            Train_HG_1_smear_0 = Train_HG_1_smear_0 +1;
        else
            Train_HG_1_smear_1 = Train_HG_1_smear_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_smear(i) == 0) 
            Train_HG_0_smear_0 = Train_HG_0_smear_0 +1;
        else
            Train_HG_0_smear_1 = Train_HG_0_smear_1 +1;
        end
    end
    
    
    
    %---------------------------------------------------------------------------------------------------------------
    % colp and smear
    Train_HG_1_colp_0_smear_0 = 0;
    Train_HG_1_colp_0_smear_1 = 0;
    Train_HG_1_colp_1_smear_0 = 0;
    Train_HG_1_colp_1_smear_1 = 0;
    
    Train_HG_0_colp_0_smear_0 = 0;
    Train_HG_0_colp_0_smear_1 = 0;
    Train_HG_0_colp_1_smear_0 = 0;
    Train_HG_0_colp_1_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_0_smear_0 = Train_HG_1_colp_0_smear_0 +1;
    
        elseif (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 1)
            Train_HG_1_colp_0_smear_1 = Train_HG_1_colp_0_smear_1 +1;
    
        elseif (cancer_data_train_colp(i) == 1) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_1_smear_0 = Train_HG_1_colp_1_smear_0 +1;
    
        else
            Train_HG_1_colp_1_smear_1 = Train_HG_1_colp_1_smear_1 +1;
          
        end
    end
    
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_0_smear_0 = Train_HG_0_colp_0_smear_0 +1;
    
        elseif (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 1)
            Train_HG_0_colp_0_smear_1 = Train_HG_0_colp_0_smear_1 +1;
    
        elseif (non_cancer_data_train_colp(i) == 1) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_1_smear_0 = Train_HG_0_colp_1_smear_0 +1;
    
        else
            Train_HG_0_colp_1_smear_1 = Train_HG_0_colp_1_smear_1 +1;
          
        end
    end
        
    %% 4.2 calculate the prob of each dignosis
    % ---------------------------------------------------------------------------------------------------------------
    %% colp
    % colp 0 
    p_h_colp_0 = Train_HG_1_colp_0 / (Train_HG_1_colp_0 + Train_HG_0_colp_0);
    % colp 1
    p_h_colp_1 = Train_HG_1_colp_1/ (Train_HG_1_colp_1 + Train_HG_0_colp_1);
    
    % ---------------------------------------------------------------------------------------------------------------
    %% smear
    % smear 0 
    p_h_smear_0 = Train_HG_1_smear_0 / (Train_HG_1_smear_0 + Train_HG_0_smear_0);
    % smear 1
    p_h_smear_1 = Train_HG_1_smear_1/ (Train_HG_1_smear_1 + Train_HG_0_smear_1);
    
    
    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    %% colp 0 smear 0
    p_h_colp_smear_00 = Train_HG_1_colp_0_smear_0 / (Train_HG_1_colp_0_smear_0 + Train_HG_0_colp_0_smear_0);
    % colp 0 smear 1
    p_h_colp_smear_01 = Train_HG_1_colp_0_smear_1 / (Train_HG_1_colp_0_smear_1 + Train_HG_0_colp_0_smear_1);
    % colp 1 smear 0
    p_h_colp_smear_10 = Train_HG_1_colp_1_smear_0 / (Train_HG_1_colp_1_smear_0 + Train_HG_0_colp_1_smear_0);
    % colp 1 smear 1
    p_h_colp_smear_11 = Train_HG_1_colp_1_smear_1 / (Train_HG_1_colp_1_smear_1 + Train_HG_0_colp_1_smear_1); 


    %% step 5
    % calculate
    % for testing data
    AA_prediction_results_with_bayes_colp  = zeros(size(Y_test,1),1);


    % ---------------------------------------------------------------------------------------------------------------
    % just colp
    for i=1:size(Y_test,1)
        if (score_test(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_test(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Colp_info_test(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_test(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_test(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Colp_info_test(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end
                   
    [x_, y_, T_, AUC_test_add_Bayes_colp] = perfcurve(Y_test, AA_prediction_results_with_bayes_colp, 1);

    % for gourp 2 data from London
    AA_prediction_results_with_bayes_colp_London = zeros(112,1);

    % ---------------------------------------------------------------------------------------------------------------


    for i=1:size(Y_test_Group_2,1)
        if (score_test_London(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_test_London(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Colp_info_test_London(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_test_London(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_test_London(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Colp_info_test_London(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end
    [x_, y_, T_, AUC_test_add_Bayes_colp_London] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_colp_London, 1);




    %% Step 6
    % Bayes results in Training dataset
    % using prior on training results (Y_pred_train,   score_train )
    % and using threshold selection method to find the best threshold on Training 

    AA_prediction_results_with_bayes_colp_train = zeros(1377,1);
    %% step 6.1 calulate the training results processed by prior knowledge
    % just colp
    for i=1:size(Y_train,1)
        if (score_train(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_train(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Colp_info_train(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_train(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_train(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_1;
                AA_prediction_results_with_bayes_colp_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Colp_info_train(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_0;
                AA_prediction_results_with_bayes_colp_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end

    %% Step 6.2 
    %% choose the best threshold from Bayes

    score_train_Bayes_Colp = AA_prediction_results_with_bayes_colp_train;
    % find the best threshold on training curves when using prior knowledge
    [threshold_best_final_train_Bayes_Colp, nono , nono] = threshold_selection(score_train_Bayes_Colp, Y_train);

    [accuracy_test_Colp,recall_test_Colp,specificity_test_Colp,sensitivity_test_Colp]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_colp,threshold_best_final_train_Bayes_Colp,Y_test);
    [accuracy_test_Colp_London,recall_test_Colp_London,specificity_test_Colp_London,sensitivity_test_Colp_London]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_colp_London,threshold_best_final_train_Bayes_Colp,Y_test_Group_2);

    AAA_FINAL_METRICS_SAVE(seed_nn,1:3) = [AUC_test,specificity_test,sensitivity_test] ;
    AAA_FINAL_METRICS_SAVE(seed_nn,4:6) = [AUC_test_add_Bayes_colp,specificity_test_Colp,sensitivity_test_Colp];
    AAA_FINAL_METRICS_SAVE(seed_nn,7:9) = [AUC_test_London,specificity_test_London,sensitivity_test_London];
    AAA_FINAL_METRICS_SAVE(seed_nn,10:12) = [AUC_test_add_Bayes_colp_London, specificity_test_Colp_London, sensitivity_test_Colp_London];
end
AAA_compare = [];
%% calculate the CI mean and std value
for i =1:12
     [mean_val,std_val,ci_lower,ci_upper] = CI_cal(AAA_FINAL_METRICS_SAVE(:,i));
     AAA_compare(i,1) = mean_val;
     AAA_compare(i,2) = std_val;
     AAA_compare(i,3) = ci_lower;
     AAA_compare(i,4) = ci_upper;
end
[Y_pred_train,score_train] = predict(treeModel, X_train);
[Y_pred_test,score_test]    = predict(treeModel, X_test);
[Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);
[x_train, y_train, T_train, AUC_train, theop_train] = perfcurve(Y_train, score_train(:,2), 1);
[x_G1, y_G1, T_G1, AUC_test,theop_test] = perfcurve(Y_test, score_test(:,2), 1);
[x_G1_b, y_G1_b, T_, AUC_test_add_Bayes_colp,theop_test_b] = perfcurve(Y_test, AA_prediction_results_with_bayes_colp, 1);
[x_G2, y_G2, T_G2, AUC_test_London,theop_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);
[x_G2_b, y_G2_b, T_, AUC_test_add_Bayes_colp_London,theop_test_London_b] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_colp_London, 1);
%% for plotting
color_1 = '[ 0 0.78 0.55]';
color_2 = '[0.25 0.41 0.88]';
color_3 = '[1 0.6 0]';
%% for group 1
figure(1);subplot(4,4,8)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G1,y_G1,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G1_b, y_G1_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_b(1),theop_test_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_colp,threshold_best_final_train_Bayes_Colp,Y_test);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group1 ROC (MLP)');legend([p_1,p_2],'Test results','Test results (PK)')

%% for group 2
figure(2);subplot(4,4,8)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G2,y_G2,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G2_b, y_G2_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_London_b(1),theop_test_London_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_colp_London, threshold_best_final_train_Bayes_Colp, Y_test_Group_2);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group2 ROC (MLP)');legend([p_1,p_2],'Test results','Test results (PK)')


%% -----------------------------------------------------------------------------------------------------------------------
%% -----------------------------------------------------------------------------------------------------------------------
clc
clear
%% load data ---------------------------------------------------------------------------------------------------------
% Group 1
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_Cancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_NonCancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_cancer_data_and_info.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_non_cancer_data_and_info.mat')
% Group 2
load('../../data/cervical data London/postprocessed_by_Lin/Cervical_Group_2_coleModel_MaxDiffMean_112.mat')
%% data filtering ----------------------------------------------------------------------------------------------------
%% Group 2
G2_cancer          = cat(2,Cervical_Group_2_cancer_MeanValues,          Cervical_Group_2_cancer_MaxDiff);
G2_non_cancer = cat(2,Cervical_Group_2_non_cancer_MeanValues,Cervical_Group_2_non_cancer_MaxDiff);
X_test_Group_2 = cat(1,G2_non_cancer,G2_cancer);
Y_test_Group_2 = cat(1,zeros(93,1),        ones(19,1));
Group_2_Colp_info     =cat(1,Cervical_Group_2_non_cancer_info.Colp,    Cervical_Group_2_cancer_info.Colp);
Group_2_Smear_info  =cat(1,Cervical_Group_2_non_cancer_info.Smear,Cervical_Group_2_cancer_info.Smear);
Colp_info_test_London = Group_2_Colp_info;
Smear_info_test_London = Group_2_Smear_info;
%% Group 1
G1_cancer          = cat(2,Cervical_Group_1_cancer_MeanValues,          Cervical_Group_1_cancer_MaxDiff);
G1_non_cancer = cat(2,Cervical_Group_1_non_cancer_MeanValues,Cervical_Group_1_non_cancer_MaxDiff);

%% ----------------------------------------------------------------------------------------------------------------------
% the best pair of hyper-para
MaxNumSplits_set = 15;
MinParentSize_set = 15;
 MinLeafSize_set  = 5;

AAA_FINAL_METRICS_SAVE = zeros(100,9);
%  AUC_test,                                    specificity_test,                    sensitivity_test,
%  AUC_test_add_Bayes_G1,       specificity_test_G1,             sensitivity_test_G1,
%  AUC_test_add_Bayes_G2,       specificity_test_G2,             sensitivity_test_G2,

for seed_nn = 4
    fprintf('the round is in %d \n',seed_nn);
    rng(seed_nn);index_record_line = 1;

    %% split the data Group1  to training and testing dataset --------------------------------------------------------------------------------------------------------------------
    % cancer data 528             vali and test      428:100
    % non cancer data 1149   vali and test      949:200
    indices_1 = randperm(528);
    Indices_train_1 = indices_1(1:428);
    Indices_test_1 = indices_1(429:end);
    
    cancer_data_train                 = G1_cancer(Indices_train_1,:);
    cancer_data_test                  =  G1_cancer(Indices_test_1,:);
    cancer_data_train_colp      = Cervical_Group_1_cancer_info.Colp_list(Indices_train_1);
    cancer_data_test_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_test_1);
    cancer_data_train_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_train_1);
    cancer_data_test_smear   = Cervical_Group_1_cancer_info.Smear_list(Indices_test_1);
    
    indices_0 = randperm(1149);
    Indices_train_0 = indices_0(1:949);
    Indices_test_0 = indices_0(950:end);
    
    non_cancer_data_train             = G1_non_cancer(Indices_train_0,:);
    non_cancer_data_test               = G1_non_cancer(Indices_test_0,:);
    non_cancer_data_train_colp    = Cervical_Group_1_non_cancer_info.Colp_list(Indices_train_0);
    non_cancer_data_test_colp      = Cervical_Group_1_non_cancer_info.Colp_list(Indices_test_0);
    non_cancer_data_train_smear = Cervical_Group_1_non_cancer_info.Smear_list(Indices_train_0);
    non_cancer_data_test_smear   = Cervical_Group_1_non_cancer_info.Smear_list(Indices_test_0);
    
    
    X_train = cat(1,non_cancer_data_train ,cancer_data_train); 
    Y_train = cat(1,zeros(949,1),ones(428,1));
    X_test = cat(1,non_cancer_data_test ,cancer_data_test);       
    Y_test = cat(1,zeros(200,1),ones(100,1));
    
    Colp_info_train = cat(1,non_cancer_data_train_colp,cancer_data_train_colp);
    Colp_info_test = cat(1,non_cancer_data_test_colp,cancer_data_test_colp);
    Smear_info_train = cat(1,non_cancer_data_train_smear,cancer_data_train_smear);
    Smear_info_test = cat(1,non_cancer_data_test_smear,cancer_data_test_smear);
    
    
    %% grid search----------------------------------------------------------------------------------------------------------------------

    treeModel = fitctree(X_train, Y_train,'MaxNumSplits',MaxNumSplits_set,'MinParentSize',MinParentSize_set,'MinLeafSize',MinLeafSize_set);

    [Y_pred_train,score_train] = predict(treeModel, X_train);
    [Y_pred_test,score_test]    = predict(treeModel, X_test);
    [Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);

    [x_, y_, T_, AUC_test] = perfcurve(Y_test, score_test(:,2), 1);
    [x_, y_, T_, AUC_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);

    %% ------------------------------------------------------------------------------------------------
    %% step 1
    % find the best threshold based on training data
    % to make the Yuden score on the training results to be the best
    % J = Sensitivity + Specificity -1
    [threshold_best_final, training_specificity_final ,training_sensitivity_final] = threshold_selection(score_train(:,2), Y_train);
    
    %% ------------------------------------------------------------------------------------------------
    %% step 3
    %% calculate the metics on testing set  for Group 1
    [accuracy_test,recall_test ,specificity_test,sensitivity_test] = ConfusionMatrix_cal(score_test(:,2),threshold_best_final,Y_test);
    %% calculate the metics on testing set  for Group 2 from London
    [accuracy_test_London,recall_test_London ,specificity_test_London,sensitivity_test_London] = ConfusionMatrix_cal(score_test_London(:,2),threshold_best_final,Y_test_Group_2);
                   
    %% step 4
    % considering the prior knowledge
    %% 4.1 calculate the prob of each dignosis statistics
    % -----------------------------------------------------------------------------------------------
    % only colp
    
    Train_HG_1_colp_0 = 0;
    Train_HG_1_colp_1 = 0;
    Train_HG_0_colp_0 = 0;
    Train_HG_0_colp_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) 
            Train_HG_1_colp_0 = Train_HG_1_colp_0 +1;
        else
            Train_HG_1_colp_1 = Train_HG_1_colp_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) 
            Train_HG_0_colp_0 = Train_HG_0_colp_0 +1;
        else
            Train_HG_0_colp_1 = Train_HG_0_colp_1 +1;
        end
    end
    
    % -----------------------------------------------------------------------------------------------
    % only smear
    
    Train_HG_1_smear_0 = 0;
    Train_HG_1_smear_1 = 0;
    Train_HG_0_smear_0 = 0;
    Train_HG_0_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_smear(i) == 0) 
            Train_HG_1_smear_0 = Train_HG_1_smear_0 +1;
        else
            Train_HG_1_smear_1 = Train_HG_1_smear_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_smear(i) == 0) 
            Train_HG_0_smear_0 = Train_HG_0_smear_0 +1;
        else
            Train_HG_0_smear_1 = Train_HG_0_smear_1 +1;
        end
    end
    
    
    
    %---------------------------------------------------------------------------------------------------------------
    % colp and smear
    Train_HG_1_colp_0_smear_0 = 0;
    Train_HG_1_colp_0_smear_1 = 0;
    Train_HG_1_colp_1_smear_0 = 0;
    Train_HG_1_colp_1_smear_1 = 0;
    
    Train_HG_0_colp_0_smear_0 = 0;
    Train_HG_0_colp_0_smear_1 = 0;
    Train_HG_0_colp_1_smear_0 = 0;
    Train_HG_0_colp_1_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_0_smear_0 = Train_HG_1_colp_0_smear_0 +1;
    
        elseif (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 1)
            Train_HG_1_colp_0_smear_1 = Train_HG_1_colp_0_smear_1 +1;
    
        elseif (cancer_data_train_colp(i) == 1) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_1_smear_0 = Train_HG_1_colp_1_smear_0 +1;
    
        else
            Train_HG_1_colp_1_smear_1 = Train_HG_1_colp_1_smear_1 +1;
          
        end
    end
    
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_0_smear_0 = Train_HG_0_colp_0_smear_0 +1;
    
        elseif (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 1)
            Train_HG_0_colp_0_smear_1 = Train_HG_0_colp_0_smear_1 +1;
    
        elseif (non_cancer_data_train_colp(i) == 1) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_1_smear_0 = Train_HG_0_colp_1_smear_0 +1;
    
        else
            Train_HG_0_colp_1_smear_1 = Train_HG_0_colp_1_smear_1 +1;
          
        end
    end
        
    %% 4.2 calculate the prob of each dignosis
    % ---------------------------------------------------------------------------------------------------------------
    %% colp
    % colp 0 
    p_h_colp_0 = Train_HG_1_colp_0 / (Train_HG_1_colp_0 + Train_HG_0_colp_0);
    % colp 1
    p_h_colp_1 = Train_HG_1_colp_1/ (Train_HG_1_colp_1 + Train_HG_0_colp_1);
    
    % ---------------------------------------------------------------------------------------------------------------
    %% smear
    % smear 0 
    p_h_smear_0 = Train_HG_1_smear_0 / (Train_HG_1_smear_0 + Train_HG_0_smear_0);
    % smear 1
    p_h_smear_1 = Train_HG_1_smear_1/ (Train_HG_1_smear_1 + Train_HG_0_smear_1);
    
    
    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    %% colp 0 smear 0
    p_h_colp_smear_00 = Train_HG_1_colp_0_smear_0 / (Train_HG_1_colp_0_smear_0 + Train_HG_0_colp_0_smear_0);
    % colp 0 smear 1
    p_h_colp_smear_01 = Train_HG_1_colp_0_smear_1 / (Train_HG_1_colp_0_smear_1 + Train_HG_0_colp_0_smear_1);
    % colp 1 smear 0
    p_h_colp_smear_10 = Train_HG_1_colp_1_smear_0 / (Train_HG_1_colp_1_smear_0 + Train_HG_0_colp_1_smear_0);
    % colp 1 smear 1
    p_h_colp_smear_11 = Train_HG_1_colp_1_smear_1 / (Train_HG_1_colp_1_smear_1 + Train_HG_0_colp_1_smear_1); 


    %% step 5
    % calculate
    % for testing data
    AA_prediction_results_with_bayes_smear = zeros(300,1);


    % ---------------------------------------------------------------------------------------------------------------
    % just colp
    for i=1:size(Y_test,1)
        if (score_test(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Smear_info_test(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Smear_info_test(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_test(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Smear_info_test(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Smear_info_test(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end
                   
    [x_, y_, T_, AUC_test_add_Bayes_smear] = perfcurve(Y_test, AA_prediction_results_with_bayes_smear, 1);

    % for gourp 2 data from London
    AA_prediction_results_with_bayes_smear_London = zeros(112,1);

    % ---------------------------------------------------------------------------------------------------------------


    for i=1:size(Y_test_Group_2,1)
        if (score_test_London(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Smear_info_test_London(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Smear_info_test_London(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_test_London(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Smear_info_test_London(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Smear_info_test_London(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end
    [x_, y_, T_, AUC_test_add_Bayes_smear_London] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_smear_London, 1);




    %% Step 6
    % Bayes results in Training dataset
    % using prior on training results (Y_pred_train,   score_train )
    % and using threshold selection method to find the best threshold on Training 

    AA_prediction_results_with_bayes_smear_train = zeros(1377,1);
    %% step 6.1 calulate the training results processed by prior knowledge
    % just colp
    for i=1:size(Y_train,1)
        if (score_train(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Smear_info_train(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Smear_info_train(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_train(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Smear_info_train(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Smear_info_train(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end

    %% Step 6.2 
    %% choose the best threshold from Bayes

    score_train_Bayes_Smear = AA_prediction_results_with_bayes_smear_train;
    % find the best threshold on training curves when using prior knowledge
    [threshold_best_final_train_Bayes_Smear, nono , nono] = threshold_selection(score_train_Bayes_Smear, Y_train);

    [accuracy_test_Smear,recall_test_Smear,specificity_test_Smear,sensitivity_test_Smear]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_smear,threshold_best_final_train_Bayes_Smear,Y_test);
    [accuracy_test_Smear_London,recall_test_Smear_London,specificity_test_Smear_London,sensitivity_test_Smear_London]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_smear_London,threshold_best_final_train_Bayes_Smear,Y_test_Group_2);

    AAA_FINAL_METRICS_SAVE(seed_nn,1:3) = [AUC_test,specificity_test,sensitivity_test] ;
    AAA_FINAL_METRICS_SAVE(seed_nn,4:6) = [AUC_test_add_Bayes_smear,specificity_test_Smear,sensitivity_test_Smear];
    AAA_FINAL_METRICS_SAVE(seed_nn,7:9) = [AUC_test_London,specificity_test_London,sensitivity_test_London];
    AAA_FINAL_METRICS_SAVE(seed_nn,10:12) = [AUC_test_add_Bayes_smear_London, specificity_test_Smear_London, sensitivity_test_Smear_London];


end
AAA_compare = [];
%% calculate the CI mean and std value
for i =1:12
     [mean_val,std_val,ci_lower,ci_upper] = CI_cal(AAA_FINAL_METRICS_SAVE(:,i));
     AAA_compare(i,1) = mean_val;
     AAA_compare(i,2) = std_val;
     AAA_compare(i,3) = ci_lower;
     AAA_compare(i,4) = ci_upper;
end
[Y_pred_train,score_train] = predict(treeModel, X_train);
[Y_pred_test,score_test]    = predict(treeModel, X_test);
[Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);
[x_train, y_train, T_train, AUC_train, theop_train] = perfcurve(Y_train, score_train(:,2), 1);
[x_G1, y_G1, T_G1, AUC_test,theop_test] = perfcurve(Y_test, score_test(:,2), 1);
[x_G1_b, y_G1_b, T_, AUC_test_add_Bayes_smear,theop_test_b] = perfcurve(Y_test, AA_prediction_results_with_bayes_smear, 1);
[x_G2, y_G2, T_G2, AUC_test_London,theop_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);
[x_G2_b, y_G2_b, T_, AUC_test_add_Bayes_smear_London,theop_test_London_b] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_smear_London, 1);
%% for plotting
color_1 = '[ 0 0.78 0.55]';
color_2 = '[0.25 0.41 0.88]';
color_3 = '[1 0.6 0]';
%% for group 1
figure(1);subplot(4,4,9)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G1,y_G1,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G1_b, y_G1_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_b(1),theop_test_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_smear,threshold_best_final_train_Bayes_Smear,Y_test);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group1 ROC (DT)');legend([p_1,p_2],'Test results','Test results (PK)')

%% for group 2
figure(2);subplot(4,4,9)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G2,y_G2,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G2_b, y_G2_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_London_b(1),theop_test_London_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_smear_London, threshold_best_final_train_Bayes_Smear, Y_test_Group_2);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group2 ROC (DT)');legend([p_1,p_2],'Test results','Test results (PK)')

%% -----------------------------------------------------------------------------------------------------------------------
%% -----------------------------------------------------------------------------------------------------------------------
clc
clear
%% load data ---------------------------------------------------------------------------------------------------------
% Group 1
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_Cancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_NonCancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_cancer_data_and_info.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_non_cancer_data_and_info.mat')
% Group 2
load('../../data/cervical data London/postprocessed_by_Lin/Cervical_Group_2_coleModel_MaxDiffMean_112.mat')
%% data filtering ----------------------------------------------------------------------------------------------------
%% Group 2
G2_cancer          = cat(2,Cervical_Group_2_cancer_MeanValues,          Cervical_Group_2_cancer_MaxDiff);
G2_non_cancer = cat(2,Cervical_Group_2_non_cancer_MeanValues,Cervical_Group_2_non_cancer_MaxDiff);
X_test_Group_2 = cat(1,G2_non_cancer,G2_cancer);
Y_test_Group_2 = cat(1,zeros(93,1),        ones(19,1));
Group_2_Colp_info     =cat(1,Cervical_Group_2_non_cancer_info.Colp,    Cervical_Group_2_cancer_info.Colp);
Group_2_Smear_info  =cat(1,Cervical_Group_2_non_cancer_info.Smear,Cervical_Group_2_cancer_info.Smear);
Colp_info_test_London = Group_2_Colp_info;
Smear_info_test_London = Group_2_Smear_info;
%% Group 1
G1_cancer          = cat(2,Cervical_Group_1_cancer_MeanValues,          Cervical_Group_1_cancer_MaxDiff);
G1_non_cancer = cat(2,Cervical_Group_1_non_cancer_MeanValues,Cervical_Group_1_non_cancer_MaxDiff);

%% ----------------------------------------------------------------------------------------------------------------------
% the best pair of hyper-para
NumTrees_set = 60;
MinLeafSize_set  = 20;
MaxNumSplits_set  = 15;

AAA_FINAL_METRICS_SAVE = zeros(100,9);
%  AUC_test,                                    specificity_test,                    sensitivity_test,
%  AUC_test_add_Bayes_G1,       specificity_test_G1,             sensitivity_test_G1,
%  AUC_test_add_Bayes_G2,       specificity_test_G2,             sensitivity_test_G2,

for seed_nn = 4
    fprintf('the round is in %d \n',seed_nn);
    rng(seed_nn);index_record_line = 1;

    %% split the data Group1  to training and testing dataset --------------------------------------------------------------------------------------------------------------------
    % cancer data 528             vali and test      428:100
    % non cancer data 1149   vali and test      949:200
    indices_1 = randperm(528);
    Indices_train_1 = indices_1(1:428);
    Indices_test_1 = indices_1(429:end);
    
    cancer_data_train                 = G1_cancer(Indices_train_1,:);
    cancer_data_test                  =  G1_cancer(Indices_test_1,:);
    cancer_data_train_colp      = Cervical_Group_1_cancer_info.Colp_list(Indices_train_1);
    cancer_data_test_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_test_1);
    cancer_data_train_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_train_1);
    cancer_data_test_smear   = Cervical_Group_1_cancer_info.Smear_list(Indices_test_1);
    
    indices_0 = randperm(1149);
    Indices_train_0 = indices_0(1:949);
    Indices_test_0 = indices_0(950:end);
    
    non_cancer_data_train             = G1_non_cancer(Indices_train_0,:);
    non_cancer_data_test               = G1_non_cancer(Indices_test_0,:);
    non_cancer_data_train_colp    = Cervical_Group_1_non_cancer_info.Colp_list(Indices_train_0);
    non_cancer_data_test_colp      = Cervical_Group_1_non_cancer_info.Colp_list(Indices_test_0);
    non_cancer_data_train_smear = Cervical_Group_1_non_cancer_info.Smear_list(Indices_train_0);
    non_cancer_data_test_smear   = Cervical_Group_1_non_cancer_info.Smear_list(Indices_test_0);
    
    
    X_train = cat(1,non_cancer_data_train ,cancer_data_train); 
    Y_train = cat(1,zeros(949,1),ones(428,1));
    X_test = cat(1,non_cancer_data_test ,cancer_data_test);       
    Y_test = cat(1,zeros(200,1),ones(100,1));
    
    Colp_info_train = cat(1,non_cancer_data_train_colp,cancer_data_train_colp);
    Colp_info_test = cat(1,non_cancer_data_test_colp,cancer_data_test_colp);
    Smear_info_train = cat(1,non_cancer_data_train_smear,cancer_data_train_smear);
    Smear_info_test = cat(1,non_cancer_data_test_smear,cancer_data_test_smear);
    
    
    %% grid search----------------------------------------------------------------------------------------------------------------------

    treeModel = TreeBagger(NumTrees_set, X_train, Y_train, 'MaxNumSplits', MaxNumSplits_set ,'MinLeafSize',MinLeafSize_set,'NumPredictorsToSample',2,'Method','classification');

    [Y_pred_train,score_train] = predict(treeModel, X_train);
    [Y_pred_test,score_test]    = predict(treeModel, X_test);
    [Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);

    [x_, y_, T_, AUC_test] = perfcurve(Y_test, score_test(:,2), 1);
    [x_, y_, T_, AUC_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);

    %% ------------------------------------------------------------------------------------------------
    %% step 1
    % find the best threshold based on training data
    % to make the Yuden score on the training results to be the best
    % J = Sensitivity + Specificity -1
    [threshold_best_final, training_specificity_final ,training_sensitivity_final] = threshold_selection(score_train(:,2), Y_train);
    
    %% ------------------------------------------------------------------------------------------------
    %% step 3
    %% calculate the metics on testing set  for Group 1
    [accuracy_test,recall_test ,specificity_test,sensitivity_test] = ConfusionMatrix_cal(score_test(:,2),threshold_best_final,Y_test);
    %% calculate the metics on testing set  for Group 2 from London
    [accuracy_test_London,recall_test_London ,specificity_test_London,sensitivity_test_London] = ConfusionMatrix_cal(score_test_London(:,2),threshold_best_final,Y_test_Group_2);
                   
    %% step 4
    % considering the prior knowledge
    %% 4.1 calculate the prob of each dignosis statistics
    % -----------------------------------------------------------------------------------------------
    % only colp
    
    Train_HG_1_colp_0 = 0;
    Train_HG_1_colp_1 = 0;
    Train_HG_0_colp_0 = 0;
    Train_HG_0_colp_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) 
            Train_HG_1_colp_0 = Train_HG_1_colp_0 +1;
        else
            Train_HG_1_colp_1 = Train_HG_1_colp_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) 
            Train_HG_0_colp_0 = Train_HG_0_colp_0 +1;
        else
            Train_HG_0_colp_1 = Train_HG_0_colp_1 +1;
        end
    end
    
    % -----------------------------------------------------------------------------------------------
    % only smear
    
    Train_HG_1_smear_0 = 0;
    Train_HG_1_smear_1 = 0;
    Train_HG_0_smear_0 = 0;
    Train_HG_0_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_smear(i) == 0) 
            Train_HG_1_smear_0 = Train_HG_1_smear_0 +1;
        else
            Train_HG_1_smear_1 = Train_HG_1_smear_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_smear(i) == 0) 
            Train_HG_0_smear_0 = Train_HG_0_smear_0 +1;
        else
            Train_HG_0_smear_1 = Train_HG_0_smear_1 +1;
        end
    end
    
    
    
    %---------------------------------------------------------------------------------------------------------------
    % colp and smear
    Train_HG_1_colp_0_smear_0 = 0;
    Train_HG_1_colp_0_smear_1 = 0;
    Train_HG_1_colp_1_smear_0 = 0;
    Train_HG_1_colp_1_smear_1 = 0;
    
    Train_HG_0_colp_0_smear_0 = 0;
    Train_HG_0_colp_0_smear_1 = 0;
    Train_HG_0_colp_1_smear_0 = 0;
    Train_HG_0_colp_1_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_0_smear_0 = Train_HG_1_colp_0_smear_0 +1;
    
        elseif (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 1)
            Train_HG_1_colp_0_smear_1 = Train_HG_1_colp_0_smear_1 +1;
    
        elseif (cancer_data_train_colp(i) == 1) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_1_smear_0 = Train_HG_1_colp_1_smear_0 +1;
    
        else
            Train_HG_1_colp_1_smear_1 = Train_HG_1_colp_1_smear_1 +1;
          
        end
    end
    
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_0_smear_0 = Train_HG_0_colp_0_smear_0 +1;
    
        elseif (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 1)
            Train_HG_0_colp_0_smear_1 = Train_HG_0_colp_0_smear_1 +1;
    
        elseif (non_cancer_data_train_colp(i) == 1) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_1_smear_0 = Train_HG_0_colp_1_smear_0 +1;
    
        else
            Train_HG_0_colp_1_smear_1 = Train_HG_0_colp_1_smear_1 +1;
          
        end
    end
        
    %% 4.2 calculate the prob of each dignosis
    % ---------------------------------------------------------------------------------------------------------------
    %% colp
    % colp 0 
    p_h_colp_0 = Train_HG_1_colp_0 / (Train_HG_1_colp_0 + Train_HG_0_colp_0);
    % colp 1
    p_h_colp_1 = Train_HG_1_colp_1/ (Train_HG_1_colp_1 + Train_HG_0_colp_1);
    
    % ---------------------------------------------------------------------------------------------------------------
    %% smear
    % smear 0 
    p_h_smear_0 = Train_HG_1_smear_0 / (Train_HG_1_smear_0 + Train_HG_0_smear_0);
    % smear 1
    p_h_smear_1 = Train_HG_1_smear_1/ (Train_HG_1_smear_1 + Train_HG_0_smear_1);
    
    
    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    %% colp 0 smear 0
    p_h_colp_smear_00 = Train_HG_1_colp_0_smear_0 / (Train_HG_1_colp_0_smear_0 + Train_HG_0_colp_0_smear_0);
    % colp 0 smear 1
    p_h_colp_smear_01 = Train_HG_1_colp_0_smear_1 / (Train_HG_1_colp_0_smear_1 + Train_HG_0_colp_0_smear_1);
    % colp 1 smear 0
    p_h_colp_smear_10 = Train_HG_1_colp_1_smear_0 / (Train_HG_1_colp_1_smear_0 + Train_HG_0_colp_1_smear_0);
    % colp 1 smear 1
    p_h_colp_smear_11 = Train_HG_1_colp_1_smear_1 / (Train_HG_1_colp_1_smear_1 + Train_HG_0_colp_1_smear_1); 


    %% step 5
    % calculate
    % for testing data
    AA_prediction_results_with_bayes_smear = zeros(300,1);


    % ---------------------------------------------------------------------------------------------------------------
    % just colp
    for i=1:size(Y_test,1)
        if (score_test(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Smear_info_test(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Smear_info_test(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_test(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Smear_info_test(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Smear_info_test(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end
                   
    [x_, y_, T_, AUC_test_add_Bayes_smear] = perfcurve(Y_test, AA_prediction_results_with_bayes_smear, 1);

    % for gourp 2 data from London
    AA_prediction_results_with_bayes_smear_London = zeros(112,1);

    % ---------------------------------------------------------------------------------------------------------------


    for i=1:size(Y_test_Group_2,1)
        if (score_test_London(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Smear_info_test_London(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Smear_info_test_London(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_test_London(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Smear_info_test_London(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Smear_info_test_London(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end
    [x_, y_, T_, AUC_test_add_Bayes_smear_London] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_smear_London, 1);




    %% Step 6
    % Bayes results in Training dataset
    % using prior on training results (Y_pred_train,   score_train )
    % and using threshold selection method to find the best threshold on Training 

    AA_prediction_results_with_bayes_smear_train = zeros(1377,1);
    %% step 6.1 calulate the training results processed by prior knowledge
    % just colp
    for i=1:size(Y_train,1)
        if (score_train(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Smear_info_train(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Smear_info_train(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_train(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Smear_info_train(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Smear_info_train(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end

    %% Step 6.2 
    %% choose the best threshold from Bayes

    score_train_Bayes_Smear = AA_prediction_results_with_bayes_smear_train;
    % find the best threshold on training curves when using prior knowledge
    [threshold_best_final_train_Bayes_Smear, nono , nono] = threshold_selection(score_train_Bayes_Smear, Y_train);

    [accuracy_test_Smear,recall_test_Smear,specificity_test_Smear,sensitivity_test_Smear]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_smear,threshold_best_final_train_Bayes_Smear,Y_test);
    [accuracy_test_Smear_London,recall_test_Smear_London,specificity_test_Smear_London,sensitivity_test_Smear_London]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_smear_London,threshold_best_final_train_Bayes_Smear,Y_test_Group_2);

    AAA_FINAL_METRICS_SAVE(seed_nn,1:3) = [AUC_test,specificity_test,sensitivity_test] ;
    AAA_FINAL_METRICS_SAVE(seed_nn,4:6) = [AUC_test_add_Bayes_smear,specificity_test_Smear,sensitivity_test_Smear];
    AAA_FINAL_METRICS_SAVE(seed_nn,7:9) = [AUC_test_London,specificity_test_London,sensitivity_test_London];
    AAA_FINAL_METRICS_SAVE(seed_nn,10:12) = [AUC_test_add_Bayes_smear_London, specificity_test_Smear_London, sensitivity_test_Smear_London];


end
AAA_compare = [];
%% calculate the CI mean and std value
for i =1:12
     [mean_val,std_val,ci_lower,ci_upper] = CI_cal(AAA_FINAL_METRICS_SAVE(:,i));
     AAA_compare(i,1) = mean_val;
     AAA_compare(i,2) = std_val;
     AAA_compare(i,3) = ci_lower;
     AAA_compare(i,4) = ci_upper;
end
[Y_pred_train,score_train] = predict(treeModel, X_train);
[Y_pred_test,score_test]    = predict(treeModel, X_test);
[Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);
[x_train, y_train, T_train, AUC_train, theop_train] = perfcurve(Y_train, score_train(:,2), 1);
[x_G1, y_G1, T_G1, AUC_test,theop_test] = perfcurve(Y_test, score_test(:,2), 1);
[x_G1_b, y_G1_b, T_, AUC_test_add_Bayes_smear,theop_test_b] = perfcurve(Y_test, AA_prediction_results_with_bayes_smear, 1);
[x_G2, y_G2, T_G2, AUC_test_London,theop_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);
[x_G2_b, y_G2_b, T_, AUC_test_add_Bayes_smear_London,theop_test_London_b] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_smear_London, 1);
%% for plotting
color_1 = '[ 0 0.78 0.55]';
color_2 = '[0.25 0.41 0.88]';
color_3 = '[1 0.6 0]';
%% for group 1
figure(1);subplot(4,4,10)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G1,y_G1,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G1_b, y_G1_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_b(1),theop_test_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_smear,threshold_best_final_train_Bayes_Smear,Y_test);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group1 ROC (RF)');legend([p_1,p_2],'Test results','Test results (PK)')

%% for group 2
figure(2);subplot(4,4,10)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G2,y_G2,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G2_b, y_G2_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_London_b(1),theop_test_London_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_smear_London, threshold_best_final_train_Bayes_Smear, Y_test_Group_2);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group2 ROC (RF)');legend([p_1,p_2],'Test results','Test results (PK)')

%% -----------------------------------------------------------------------------------------------------------------------
%% -----------------------------------------------------------------------------------------------------------------------
clc
clear
%% load data ---------------------------------------------------------------------------------------------------------
% Group 1
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_Cancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_NonCancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_cancer_data_and_info.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_non_cancer_data_and_info.mat')
% Group 2
load('../../data/cervical data London/postprocessed_by_Lin/Cervical_Group_2_coleModel_MaxDiffMean_112.mat')
%% data filtering ----------------------------------------------------------------------------------------------------
%% Group 2
G2_cancer          = cat(2,Cervical_Group_2_cancer_MeanValues,          Cervical_Group_2_cancer_MaxDiff);
G2_non_cancer = cat(2,Cervical_Group_2_non_cancer_MeanValues,Cervical_Group_2_non_cancer_MaxDiff);
X_test_Group_2 = cat(1,G2_non_cancer,G2_cancer);
Y_test_Group_2 = cat(1,zeros(93,1),        ones(19,1));
Group_2_Colp_info     =cat(1,Cervical_Group_2_non_cancer_info.Colp,    Cervical_Group_2_cancer_info.Colp);
Group_2_Smear_info  =cat(1,Cervical_Group_2_non_cancer_info.Smear,Cervical_Group_2_cancer_info.Smear);
Colp_info_test_London = Group_2_Colp_info;
Smear_info_test_London = Group_2_Smear_info;
%% Group 1
G1_cancer          = cat(2,Cervical_Group_1_cancer_MeanValues,          Cervical_Group_1_cancer_MaxDiff);
G1_non_cancer = cat(2,Cervical_Group_1_non_cancer_MeanValues,Cervical_Group_1_non_cancer_MaxDiff);

%% ----------------------------------------------------------------------------------------------------------------------
% the best pair of hyper-para
AAA_FINAL_METRICS_SAVE = zeros(100,9);
%  AUC_test,                                    specificity_test,                    sensitivity_test,
%  AUC_test_add_Bayes_G1,       specificity_test_G1,             sensitivity_test_G1,
%  AUC_test_add_Bayes_G2,       specificity_test_G2,             sensitivity_test_G2,

for seed_nn = 4
    fprintf('the round is in %d \n',seed_nn);
    rng(seed_nn);index_record_line = 1;

    %% split the data Group1  to training and testing dataset --------------------------------------------------------------------------------------------------------------------
    % cancer data 528             vali and test      428:100
    % non cancer data 1149   vali and test      949:200
    indices_1 = randperm(528);
    Indices_train_1 = indices_1(1:428);
    Indices_test_1 = indices_1(429:end);
    
    cancer_data_train                 = G1_cancer(Indices_train_1,:);
    cancer_data_test                  =  G1_cancer(Indices_test_1,:);
    cancer_data_train_colp      = Cervical_Group_1_cancer_info.Colp_list(Indices_train_1);
    cancer_data_test_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_test_1);
    cancer_data_train_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_train_1);
    cancer_data_test_smear   = Cervical_Group_1_cancer_info.Smear_list(Indices_test_1);
    
    indices_0 = randperm(1149);
    Indices_train_0 = indices_0(1:949);
    Indices_test_0 = indices_0(950:end);
    
    non_cancer_data_train             = G1_non_cancer(Indices_train_0,:);
    non_cancer_data_test               = G1_non_cancer(Indices_test_0,:);
    non_cancer_data_train_colp    = Cervical_Group_1_non_cancer_info.Colp_list(Indices_train_0);
    non_cancer_data_test_colp      = Cervical_Group_1_non_cancer_info.Colp_list(Indices_test_0);
    non_cancer_data_train_smear = Cervical_Group_1_non_cancer_info.Smear_list(Indices_train_0);
    non_cancer_data_test_smear   = Cervical_Group_1_non_cancer_info.Smear_list(Indices_test_0);
    
    
    X_train = cat(1,non_cancer_data_train ,cancer_data_train); 
    Y_train = cat(1,zeros(949,1),ones(428,1));
    X_test = cat(1,non_cancer_data_test ,cancer_data_test);       
    Y_test = cat(1,zeros(200,1),ones(100,1));
    
    Colp_info_train = cat(1,non_cancer_data_train_colp,cancer_data_train_colp);
    Colp_info_test = cat(1,non_cancer_data_test_colp,cancer_data_test_colp);
    Smear_info_train = cat(1,non_cancer_data_train_smear,cancer_data_train_smear);
    Smear_info_test = cat(1,non_cancer_data_test_smear,cancer_data_test_smear);
    
    
    %% grid search----------------------------------------------------------------------------------------------------------------------

    treeModel = fitcsvm(X_train, Y_train,'KernelFunction','rbf','BoxConstraint', 0.001,'Standardize',true);

    [Y_pred_train,score_train] = predict(treeModel, X_train);
    [Y_pred_test,score_test]    = predict(treeModel, X_test);
    [Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);

    [x_, y_, T_, AUC_test] = perfcurve(Y_test, score_test(:,2), 1);
    [x_, y_, T_, AUC_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);

    %% ------------------------------------------------------------------------------------------------
    %% step 1
    % find the best threshold based on training data
    % to make the Yuden score on the training results to be the best
    % J = Sensitivity + Specificity -1
    [threshold_best_final, training_specificity_final ,training_sensitivity_final] = threshold_selection(score_train(:,2), Y_train);
    
    %% ------------------------------------------------------------------------------------------------
    %% step 3
    %% calculate the metics on testing set  for Group 1
    [accuracy_test,recall_test ,specificity_test,sensitivity_test] = ConfusionMatrix_cal(score_test(:,2),threshold_best_final,Y_test);
    %% calculate the metics on testing set  for Group 2 from London
    [accuracy_test_London,recall_test_London ,specificity_test_London,sensitivity_test_London] = ConfusionMatrix_cal(score_test_London(:,2),threshold_best_final,Y_test_Group_2);
                   
    %% step 4
    % considering the prior knowledge
    %% 4.1 calculate the prob of each dignosis statistics
    % -----------------------------------------------------------------------------------------------
    % only colp
    
    Train_HG_1_colp_0 = 0;
    Train_HG_1_colp_1 = 0;
    Train_HG_0_colp_0 = 0;
    Train_HG_0_colp_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) 
            Train_HG_1_colp_0 = Train_HG_1_colp_0 +1;
        else
            Train_HG_1_colp_1 = Train_HG_1_colp_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) 
            Train_HG_0_colp_0 = Train_HG_0_colp_0 +1;
        else
            Train_HG_0_colp_1 = Train_HG_0_colp_1 +1;
        end
    end
    
    % -----------------------------------------------------------------------------------------------
    % only smear
    
    Train_HG_1_smear_0 = 0;
    Train_HG_1_smear_1 = 0;
    Train_HG_0_smear_0 = 0;
    Train_HG_0_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_smear(i) == 0) 
            Train_HG_1_smear_0 = Train_HG_1_smear_0 +1;
        else
            Train_HG_1_smear_1 = Train_HG_1_smear_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_smear(i) == 0) 
            Train_HG_0_smear_0 = Train_HG_0_smear_0 +1;
        else
            Train_HG_0_smear_1 = Train_HG_0_smear_1 +1;
        end
    end
    
    
    
    %---------------------------------------------------------------------------------------------------------------
    % colp and smear
    Train_HG_1_colp_0_smear_0 = 0;
    Train_HG_1_colp_0_smear_1 = 0;
    Train_HG_1_colp_1_smear_0 = 0;
    Train_HG_1_colp_1_smear_1 = 0;
    
    Train_HG_0_colp_0_smear_0 = 0;
    Train_HG_0_colp_0_smear_1 = 0;
    Train_HG_0_colp_1_smear_0 = 0;
    Train_HG_0_colp_1_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_0_smear_0 = Train_HG_1_colp_0_smear_0 +1;
    
        elseif (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 1)
            Train_HG_1_colp_0_smear_1 = Train_HG_1_colp_0_smear_1 +1;
    
        elseif (cancer_data_train_colp(i) == 1) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_1_smear_0 = Train_HG_1_colp_1_smear_0 +1;
    
        else
            Train_HG_1_colp_1_smear_1 = Train_HG_1_colp_1_smear_1 +1;
          
        end
    end
    
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_0_smear_0 = Train_HG_0_colp_0_smear_0 +1;
    
        elseif (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 1)
            Train_HG_0_colp_0_smear_1 = Train_HG_0_colp_0_smear_1 +1;
    
        elseif (non_cancer_data_train_colp(i) == 1) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_1_smear_0 = Train_HG_0_colp_1_smear_0 +1;
    
        else
            Train_HG_0_colp_1_smear_1 = Train_HG_0_colp_1_smear_1 +1;
          
        end
    end
        
    %% 4.2 calculate the prob of each dignosis
    % ---------------------------------------------------------------------------------------------------------------
    %% colp
    % colp 0 
    p_h_colp_0 = Train_HG_1_colp_0 / (Train_HG_1_colp_0 + Train_HG_0_colp_0);
    % colp 1
    p_h_colp_1 = Train_HG_1_colp_1/ (Train_HG_1_colp_1 + Train_HG_0_colp_1);
    
    % ---------------------------------------------------------------------------------------------------------------
    %% smear
    % smear 0 
    p_h_smear_0 = Train_HG_1_smear_0 / (Train_HG_1_smear_0 + Train_HG_0_smear_0);
    % smear 1
    p_h_smear_1 = Train_HG_1_smear_1/ (Train_HG_1_smear_1 + Train_HG_0_smear_1);
    
    
    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    %% colp 0 smear 0
    p_h_colp_smear_00 = Train_HG_1_colp_0_smear_0 / (Train_HG_1_colp_0_smear_0 + Train_HG_0_colp_0_smear_0);
    % colp 0 smear 1
    p_h_colp_smear_01 = Train_HG_1_colp_0_smear_1 / (Train_HG_1_colp_0_smear_1 + Train_HG_0_colp_0_smear_1);
    % colp 1 smear 0
    p_h_colp_smear_10 = Train_HG_1_colp_1_smear_0 / (Train_HG_1_colp_1_smear_0 + Train_HG_0_colp_1_smear_0);
    % colp 1 smear 1
    p_h_colp_smear_11 = Train_HG_1_colp_1_smear_1 / (Train_HG_1_colp_1_smear_1 + Train_HG_0_colp_1_smear_1); 


    %% step 5
    % calculate
    % for testing data
    AA_prediction_results_with_bayes_smear = zeros(300,1);


    % ---------------------------------------------------------------------------------------------------------------
    % just colp
    for i=1:size(Y_test,1)
        if (score_test(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Smear_info_test(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Smear_info_test(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_test(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Smear_info_test(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Smear_info_test(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end
                   
    [x_, y_, T_, AUC_test_add_Bayes_smear] = perfcurve(Y_test, AA_prediction_results_with_bayes_smear, 1);

    % for gourp 2 data from London
    AA_prediction_results_with_bayes_smear_London = zeros(112,1);

    % ---------------------------------------------------------------------------------------------------------------


    for i=1:size(Y_test_Group_2,1)
        if (score_test_London(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Smear_info_test_London(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Smear_info_test_London(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_test_London(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Smear_info_test_London(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Smear_info_test_London(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end
    [x_, y_, T_, AUC_test_add_Bayes_smear_London] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_smear_London, 1);




    %% Step 6
    % Bayes results in Training dataset
    % using prior on training results (Y_pred_train,   score_train )
    % and using threshold selection method to find the best threshold on Training 

    AA_prediction_results_with_bayes_smear_train = zeros(1377,1);
    %% step 6.1 calulate the training results processed by prior knowledge
    % just colp
    for i=1:size(Y_train,1)
        if (score_train(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Smear_info_train(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Smear_info_train(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_train(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Smear_info_train(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Smear_info_train(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end

    %% Step 6.2 
    %% choose the best threshold from Bayes

    score_train_Bayes_Smear = AA_prediction_results_with_bayes_smear_train;
    % find the best threshold on training curves when using prior knowledge
    [threshold_best_final_train_Bayes_Smear, nono , nono] = threshold_selection(score_train_Bayes_Smear, Y_train);

    [accuracy_test_Smear,recall_test_Smear,specificity_test_Smear,sensitivity_test_Smear]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_smear,threshold_best_final_train_Bayes_Smear,Y_test);
    [accuracy_test_Smear_London,recall_test_Smear_London,specificity_test_Smear_London,sensitivity_test_Smear_London]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_smear_London,threshold_best_final_train_Bayes_Smear,Y_test_Group_2);

    AAA_FINAL_METRICS_SAVE(seed_nn,1:3) = [AUC_test,specificity_test,sensitivity_test] ;
    AAA_FINAL_METRICS_SAVE(seed_nn,4:6) = [AUC_test_add_Bayes_smear,specificity_test_Smear,sensitivity_test_Smear];
    AAA_FINAL_METRICS_SAVE(seed_nn,7:9) = [AUC_test_London,specificity_test_London,sensitivity_test_London];
    AAA_FINAL_METRICS_SAVE(seed_nn,10:12) = [AUC_test_add_Bayes_smear_London, specificity_test_Smear_London, sensitivity_test_Smear_London];
end
AAA_compare = [];
%% calculate the CI mean and std value
for i =1:12
     [mean_val,std_val,ci_lower,ci_upper] = CI_cal(AAA_FINAL_METRICS_SAVE(:,i));
     AAA_compare(i,1) = mean_val;
     AAA_compare(i,2) = std_val;
     AAA_compare(i,3) = ci_lower;
     AAA_compare(i,4) = ci_upper;
end
[Y_pred_train,score_train] = predict(treeModel, X_train);
[Y_pred_test,score_test]    = predict(treeModel, X_test);
[Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);
[x_train, y_train, T_train, AUC_train, theop_train] = perfcurve(Y_train, score_train(:,2), 1);
[x_G1, y_G1, T_G1, AUC_test,theop_test] = perfcurve(Y_test, score_test(:,2), 1);
[x_G1_b, y_G1_b, T_, AUC_test_add_Bayes_smear,theop_test_b] = perfcurve(Y_test, AA_prediction_results_with_bayes_smear, 1);
[x_G2, y_G2, T_G2, AUC_test_London,theop_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);
[x_G2_b, y_G2_b, T_, AUC_test_add_Bayes_smear_London,theop_test_London_b] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_smear_London, 1);
%% for plotting
color_1 = '[ 0 0.78 0.55]';
color_2 = '[0.25 0.41 0.88]';
color_3 = '[1 0.6 0]';
%% for group 1
figure(1);subplot(4,4,11)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G1,y_G1,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G1_b, y_G1_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_b(1),theop_test_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_smear,threshold_best_final_train_Bayes_Smear,Y_test);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group1 ROC (SVM)');legend([p_1,p_2],'Test results','Test results (PK)')

%% for group 2
figure(2);subplot(4,4,11)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G2,y_G2,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G2_b, y_G2_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_London_b(1),theop_test_London_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_smear_London, threshold_best_final_train_Bayes_Smear, Y_test_Group_2);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group2 ROC (SVM)');legend([p_1,p_2],'Test results','Test results (PK)')

%% -----------------------------------------------------------------------------------------------------------------------
%% -----------------------------------------------------------------------------------------------------------------------
clc
clear
%% load data ---------------------------------------------------------------------------------------------------------
% Group 1
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_Cancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_NonCancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_cancer_data_and_info.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_non_cancer_data_and_info.mat')
% Group 2
load('../../data/cervical data London/postprocessed_by_Lin/Cervical_Group_2_coleModel_MaxDiffMean_112.mat')
%% data filtering ----------------------------------------------------------------------------------------------------
%% Group 2
G2_cancer          = cat(2,Cervical_Group_2_cancer_MeanValues,          Cervical_Group_2_cancer_MaxDiff);
G2_non_cancer = cat(2,Cervical_Group_2_non_cancer_MeanValues,Cervical_Group_2_non_cancer_MaxDiff);
X_test_Group_2 = cat(1,G2_non_cancer,G2_cancer);
Y_test_Group_2 = cat(1,zeros(93,1),        ones(19,1));
Group_2_Colp_info     =cat(1,Cervical_Group_2_non_cancer_info.Colp,    Cervical_Group_2_cancer_info.Colp);
Group_2_Smear_info  =cat(1,Cervical_Group_2_non_cancer_info.Smear,Cervical_Group_2_cancer_info.Smear);
Colp_info_test_London = Group_2_Colp_info;
Smear_info_test_London = Group_2_Smear_info;
%% Group 1
G1_cancer          = cat(2,Cervical_Group_1_cancer_MeanValues,          Cervical_Group_1_cancer_MaxDiff);
G1_non_cancer = cat(2,Cervical_Group_1_non_cancer_MeanValues,Cervical_Group_1_non_cancer_MaxDiff);

%% ----------------------------------------------------------------------------------------------------------------------
% the best pair of hyper-para


AAA_FINAL_METRICS_SAVE = zeros(100,9);
%  AUC_test,                                    specificity_test,                    sensitivity_test,
%  AUC_test_add_Bayes_G1,       specificity_test_G1,             sensitivity_test_G1,
%  AUC_test_add_Bayes_G2,       specificity_test_G2,             sensitivity_test_G2,

for seed_nn = 4
    fprintf('the round is in %d \n',seed_nn);
    rng(seed_nn);index_record_line = 1;

    %% split the data Group1  to training and testing dataset --------------------------------------------------------------------------------------------------------------------
    % cancer data 528             vali and test      428:100
    % non cancer data 1149   vali and test      949:200
    indices_1 = randperm(528);
    Indices_train_1 = indices_1(1:428);
    Indices_test_1 = indices_1(429:end);
    
    cancer_data_train                 = G1_cancer(Indices_train_1,:);
    cancer_data_test                  =  G1_cancer(Indices_test_1,:);
    cancer_data_train_colp      = Cervical_Group_1_cancer_info.Colp_list(Indices_train_1);
    cancer_data_test_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_test_1);
    cancer_data_train_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_train_1);
    cancer_data_test_smear   = Cervical_Group_1_cancer_info.Smear_list(Indices_test_1);
    
    indices_0 = randperm(1149);
    Indices_train_0 = indices_0(1:949);
    Indices_test_0 = indices_0(950:end);
    
    non_cancer_data_train             = G1_non_cancer(Indices_train_0,:);
    non_cancer_data_test               = G1_non_cancer(Indices_test_0,:);
    non_cancer_data_train_colp    = Cervical_Group_1_non_cancer_info.Colp_list(Indices_train_0);
    non_cancer_data_test_colp      = Cervical_Group_1_non_cancer_info.Colp_list(Indices_test_0);
    non_cancer_data_train_smear = Cervical_Group_1_non_cancer_info.Smear_list(Indices_train_0);
    non_cancer_data_test_smear   = Cervical_Group_1_non_cancer_info.Smear_list(Indices_test_0);
    
    
    X_train = cat(1,non_cancer_data_train ,cancer_data_train); 
    Y_train = cat(1,zeros(949,1),ones(428,1));
    X_test = cat(1,non_cancer_data_test ,cancer_data_test);       
    Y_test = cat(1,zeros(200,1),ones(100,1));
    
    Colp_info_train = cat(1,non_cancer_data_train_colp,cancer_data_train_colp);
    Colp_info_test = cat(1,non_cancer_data_test_colp,cancer_data_test_colp);
    Smear_info_train = cat(1,non_cancer_data_train_smear,cancer_data_train_smear);
    Smear_info_test = cat(1,non_cancer_data_test_smear,cancer_data_test_smear);
    
    
    %% grid search----------------------------------------------------------------------------------------------------------------------

    treeModel = fitcnet(X_train, Y_train, ...
                                        'Standardize', true, ...
                                        'LayerSizes', [10], ...  % 
                                        'Activations', 'relu');     % 可选：'relu', 'tanh', 'sigmoid'
    [Y_pred_train,score_train] = predict(treeModel, X_train);
    [Y_pred_test,score_test]    = predict(treeModel, X_test);
    [Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);

    [x_, y_, T_, AUC_test] = perfcurve(Y_test, score_test(:,2), 1);
    [x_, y_, T_, AUC_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);

    %% ------------------------------------------------------------------------------------------------
    %% step 1
    % find the best threshold based on training data
    % to make the Yuden score on the training results to be the best
    % J = Sensitivity + Specificity -1
    [threshold_best_final, training_specificity_final ,training_sensitivity_final] = threshold_selection(score_train(:,2), Y_train);
    
    %% ------------------------------------------------------------------------------------------------
    %% step 3
    %% calculate the metics on testing set  for Group 1
    [accuracy_test,recall_test ,specificity_test,sensitivity_test] = ConfusionMatrix_cal(score_test(:,2),threshold_best_final,Y_test);
    %% calculate the metics on testing set  for Group 2 from London
    [accuracy_test_London,recall_test_London ,specificity_test_London,sensitivity_test_London] = ConfusionMatrix_cal(score_test_London(:,2),threshold_best_final,Y_test_Group_2);
                   
    %% step 4
    % considering the prior knowledge
    %% 4.1 calculate the prob of each dignosis statistics
    % -----------------------------------------------------------------------------------------------
    % only colp
    
    Train_HG_1_colp_0 = 0;
    Train_HG_1_colp_1 = 0;
    Train_HG_0_colp_0 = 0;
    Train_HG_0_colp_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) 
            Train_HG_1_colp_0 = Train_HG_1_colp_0 +1;
        else
            Train_HG_1_colp_1 = Train_HG_1_colp_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) 
            Train_HG_0_colp_0 = Train_HG_0_colp_0 +1;
        else
            Train_HG_0_colp_1 = Train_HG_0_colp_1 +1;
        end
    end
    
    % -----------------------------------------------------------------------------------------------
    % only smear
    
    Train_HG_1_smear_0 = 0;
    Train_HG_1_smear_1 = 0;
    Train_HG_0_smear_0 = 0;
    Train_HG_0_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_smear(i) == 0) 
            Train_HG_1_smear_0 = Train_HG_1_smear_0 +1;
        else
            Train_HG_1_smear_1 = Train_HG_1_smear_1 +1;
        end
    end
    
    for i = 1:949
        if (non_cancer_data_train_smear(i) == 0) 
            Train_HG_0_smear_0 = Train_HG_0_smear_0 +1;
        else
            Train_HG_0_smear_1 = Train_HG_0_smear_1 +1;
        end
    end
    
    
    
    %---------------------------------------------------------------------------------------------------------------
    % colp and smear
    Train_HG_1_colp_0_smear_0 = 0;
    Train_HG_1_colp_0_smear_1 = 0;
    Train_HG_1_colp_1_smear_0 = 0;
    Train_HG_1_colp_1_smear_1 = 0;
    
    Train_HG_0_colp_0_smear_0 = 0;
    Train_HG_0_colp_0_smear_1 = 0;
    Train_HG_0_colp_1_smear_0 = 0;
    Train_HG_0_colp_1_smear_1 = 0;
    
    for i=1:428
        if (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_0_smear_0 = Train_HG_1_colp_0_smear_0 +1;
    
        elseif (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 1)
            Train_HG_1_colp_0_smear_1 = Train_HG_1_colp_0_smear_1 +1;
    
        elseif (cancer_data_train_colp(i) == 1) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_1_smear_0 = Train_HG_1_colp_1_smear_0 +1;
    
        else
            Train_HG_1_colp_1_smear_1 = Train_HG_1_colp_1_smear_1 +1;
          
        end
    end
    
    
    for i = 1:949
        if (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_0_smear_0 = Train_HG_0_colp_0_smear_0 +1;
    
        elseif (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 1)
            Train_HG_0_colp_0_smear_1 = Train_HG_0_colp_0_smear_1 +1;
    
        elseif (non_cancer_data_train_colp(i) == 1) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_1_smear_0 = Train_HG_0_colp_1_smear_0 +1;
    
        else
            Train_HG_0_colp_1_smear_1 = Train_HG_0_colp_1_smear_1 +1;
          
        end
    end
        
    %% 4.2 calculate the prob of each dignosis
    % ---------------------------------------------------------------------------------------------------------------
    %% colp
    % colp 0 
    p_h_colp_0 = Train_HG_1_colp_0 / (Train_HG_1_colp_0 + Train_HG_0_colp_0);
    % colp 1
    p_h_colp_1 = Train_HG_1_colp_1/ (Train_HG_1_colp_1 + Train_HG_0_colp_1);
    
    % ---------------------------------------------------------------------------------------------------------------
    %% smear
    % smear 0 
    p_h_smear_0 = Train_HG_1_smear_0 / (Train_HG_1_smear_0 + Train_HG_0_smear_0);
    % smear 1
    p_h_smear_1 = Train_HG_1_smear_1/ (Train_HG_1_smear_1 + Train_HG_0_smear_1);
    
    
    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    %% colp 0 smear 0
    p_h_colp_smear_00 = Train_HG_1_colp_0_smear_0 / (Train_HG_1_colp_0_smear_0 + Train_HG_0_colp_0_smear_0);
    % colp 0 smear 1
    p_h_colp_smear_01 = Train_HG_1_colp_0_smear_1 / (Train_HG_1_colp_0_smear_1 + Train_HG_0_colp_0_smear_1);
    % colp 1 smear 0
    p_h_colp_smear_10 = Train_HG_1_colp_1_smear_0 / (Train_HG_1_colp_1_smear_0 + Train_HG_0_colp_1_smear_0);
    % colp 1 smear 1
    p_h_colp_smear_11 = Train_HG_1_colp_1_smear_1 / (Train_HG_1_colp_1_smear_1 + Train_HG_0_colp_1_smear_1); 


    %% step 5
    % calculate
    % for testing data
    AA_prediction_results_with_bayes_smear = zeros(300,1);


    % ---------------------------------------------------------------------------------------------------------------
    % just colp
    for i=1:size(Y_test,1)
        if (score_test(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Smear_info_test(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Smear_info_test(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_test(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Smear_info_test(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Smear_info_test(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end
                   
    [x_, y_, T_, AUC_test_add_Bayes_smear] = perfcurve(Y_test, AA_prediction_results_with_bayes_smear, 1);

    % for gourp 2 data from London
    AA_prediction_results_with_bayes_smear_London = zeros(112,1);

    % ---------------------------------------------------------------------------------------------------------------


    for i=1:size(Y_test_Group_2,1)
        if (score_test_London(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Smear_info_test_London(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Smear_info_test_London(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear_London(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_test_London(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Smear_info_test_London(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Smear_info_test_London(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear_London(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end
    [x_, y_, T_, AUC_test_add_Bayes_smear_London] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_smear_London, 1);




    %% Step 6
    % Bayes results in Training dataset
    % using prior on training results (Y_pred_train,   score_train )
    % and using threshold selection method to find the best threshold on Training 

    AA_prediction_results_with_bayes_smear_train = zeros(1377,1);
    %% step 6.1 calulate the training results processed by prior knowledge
    % just colp
    for i=1:size(Y_train,1)
        if (score_train(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Smear_info_train(i)==1) %  colp =1 
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
            if (Smear_info_train(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear_train(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
            end
        end
        if (score_train(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Smear_info_train(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_smear_1;
                AA_prediction_results_with_bayes_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
            end
             if (Smear_info_train(i)==0) %  colp =0 
                % colp =0      结合统计学患癌的概率
                p_h = p_h_smear_0;
                AA_prediction_results_with_bayes_smear_train(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
             end
        end
    end

    %% Step 6.2 
    %% choose the best threshold from Bayes

    score_train_Bayes_Smear = AA_prediction_results_with_bayes_smear_train;
    % find the best threshold on training curves when using prior knowledge
    [threshold_best_final_train_Bayes_Smear, nono , nono] = threshold_selection(score_train_Bayes_Smear, Y_train);

    [accuracy_test_Smear,recall_test_Smear,specificity_test_Smear,sensitivity_test_Smear]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_smear,threshold_best_final_train_Bayes_Smear,Y_test);
    [accuracy_test_Smear_London,recall_test_Smear_London,specificity_test_Smear_London,sensitivity_test_Smear_London]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_smear_London,threshold_best_final_train_Bayes_Smear,Y_test_Group_2);

    AAA_FINAL_METRICS_SAVE(seed_nn,1:3) = [AUC_test,specificity_test,sensitivity_test] ;
    AAA_FINAL_METRICS_SAVE(seed_nn,4:6) = [AUC_test_add_Bayes_smear,specificity_test_Smear,sensitivity_test_Smear];
    AAA_FINAL_METRICS_SAVE(seed_nn,7:9) = [AUC_test_London,specificity_test_London,sensitivity_test_London];
    AAA_FINAL_METRICS_SAVE(seed_nn,10:12) = [AUC_test_add_Bayes_smear_London, specificity_test_Smear_London, sensitivity_test_Smear_London];


end

AAA_compare = [];
%% calculate the CI mean and std value
for i =1:12
     [mean_val,std_val,ci_lower,ci_upper] = CI_cal(AAA_FINAL_METRICS_SAVE(:,i));
     AAA_compare(i,1) = mean_val;
     AAA_compare(i,2) = std_val;
     AAA_compare(i,3) = ci_lower;
     AAA_compare(i,4) = ci_upper;
end
[Y_pred_train,score_train] = predict(treeModel, X_train);
[Y_pred_test,score_test]    = predict(treeModel, X_test);
[Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);
[x_train, y_train, T_train, AUC_train, theop_train] = perfcurve(Y_train, score_train(:,2), 1);
[x_G1, y_G1, T_G1, AUC_test,theop_test] = perfcurve(Y_test, score_test(:,2), 1);
[x_G1_b, y_G1_b, T_, AUC_test_add_Bayes_smear,theop_test_b] = perfcurve(Y_test, AA_prediction_results_with_bayes_smear, 1);
[x_G2, y_G2, T_G2, AUC_test_London,theop_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);
[x_G2_b, y_G2_b, T_, AUC_test_add_Bayes_smear_London,theop_test_London_b] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_smear_London, 1);
%% for plotting
color_1 = '[ 0 0.78 0.55]';
color_2 = '[0.25 0.41 0.88]';
color_3 = '[1 0.6 0]';
%% for group 1
figure(1);subplot(4,4,12)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G1,y_G1,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G1_b, y_G1_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_b(1),theop_test_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_smear,threshold_best_final_train_Bayes_Smear,Y_test);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group1 ROC (MLP)');legend([p_1,p_2],'Test results','Test results (PK)')

%% for group 2
figure(2);subplot(4,4,12)
%% step 1
plot(0:0.1:1,0:0.1:1,'LineWidth',1.5,'LineStyle','--',"Color",color_1); hold on;
%% step 2 before bayes
p_1=plot(x_G2,y_G2,'LineWidth',1.5,"Color",color_2); hold on;
%% step 3 after bayes
p_2=plot(x_G2_b, y_G2_b,'LineWidth',1.5,"Color",color_3); hold on;
% plot(theop_test_London_b(1),theop_test_London_b(2),'rd','linewidth',2);hold on
% to locate one point in the test ROC using training best threshold
% to calculate TPR TFR
[TPR,FPR]=ConfusionMatrix_TPR_FPR_cal(AA_prediction_results_with_bayes_smear_London, threshold_best_final_train_Bayes_Smear, Y_test_Group_2);
plot(FPR,TPR,'rd','linewidth',2);hold on
set(gca, 'LineWidth', 1.0, 'FontSize',12,'FontWeight', 'bold');  % 设置 x 和 y 轴的线宽
xlabel('FPR');ylabel('TPR');title('Group2 ROC (MLP)');legend([p_1,p_2],'Test results','Test results (PK)')

%% -----------------------------------------------------------------------------------------------------------------------
%% -----------------------------------------------------------------------------------------------------------------------