clc
clear

load AA_save_AUC_Bayes_Cervical_MLP_Smear.mat

AA_compare = zeros(216,7);
dddd = AA_save_group_1_AUC_Bayes_Smear;
AA_compare(:,1:3) = dddd(:,1:3);


for i =1:216
     [mean_val,std_val,ci_lower,ci_upper] = CI_cal(dddd(i,4:103));
     AA_compare(i,4) = mean_val;
     AA_compare(i,5) = std_val;
     AA_compare(i,6) = ci_lower;
     AA_compare(i,7) = ci_upper;
end

[max_val, row_idx] = max(AA_compare(:,4)) % compare the mean

fprintf('the best pair is under setting \n MaxNumSplits_set =  %d   \n MinParentSize_set = %d \n MinLeafSize_set = %d \n \n', AA_compare(row_idx,1), ...
    AA_compare(row_idx,2),AA_compare(row_idx,3));

fprintf('the best metrics \n mean =%.2f \n std = %.2f \n 95CI [%.2f %.2f]',AA_compare(row_idx,4),AA_compare(row_idx,5),AA_compare(row_idx,6),AA_compare(row_idx,7));




