clc
clear
%% load data ---------------------------------------------------------------------------------------------------------
% Group 1
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_Cancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_NonCancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_cancer_data_and_info.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_non_cancer_data_and_info.mat')
% Group 2
load('../../data/cervical data London/postprocessed_by_Lin/Cervical_Group_2_coleModel_MaxDiffMean_112.mat')
%% data filtering ----------------------------------------------------------------------------------------------------
%% Group 2
G2_cancer          = cat(2,Cervical_Group_2_cancer_MeanValues,          Cervical_Group_2_cancer_MaxDiff);
G2_non_cancer = cat(2,Cervical_Group_2_non_cancer_MeanValues,Cervical_Group_2_non_cancer_MaxDiff);
X_test_Group_2 = cat(1,G2_non_cancer,G2_cancer);
Y_test_Group_2 = cat(1,zeros(93,1),        ones(19,1));
Group_2_Colp_info     =cat(1,Cervical_Group_2_non_cancer_info.Colp,    Cervical_Group_2_cancer_info.Colp);
Group_2_Smear_info  =cat(1,Cervical_Group_2_non_cancer_info.Smear,Cervical_Group_2_cancer_info.Smear);
Colp_info_test_London = Group_2_Colp_info;
Smear_info_test_London = Group_2_Smear_info;
%% Group 1
G1_cancer          = cat(2,Cervical_Group_1_cancer_MeanValues,          Cervical_Group_1_cancer_MaxDiff);
G1_non_cancer = cat(2,Cervical_Group_1_non_cancer_MeanValues,Cervical_Group_1_non_cancer_MaxDiff);
%% ----------------------------------------------------------------------------------------------------------------------

AA_save_group_1_AUC_Bayes_Colp = zeros(216,103); % first 3 record hyper-pare, and later 100 record the AUC

for seed_nn = 1:100
    fprintf('the round is in %d \n',seed_nn);
    rng(seed_nn);index_record_line = 1;

    %% split the data Group1  to training and testing dataset --------------------------------------------------------------------------------------------------------------------
    % cancer data 528             vali and test      428:100
    % non cancer data 1149   vali and test      949:200
    indices_1 = randperm(528);
    Indices_train_1 = indices_1(1:428);
    Indices_test_1 = indices_1(429:end);
    
    cancer_data_train                 = G1_cancer(Indices_train_1,:);
    cancer_data_test                  =  G1_cancer(Indices_test_1,:);
    cancer_data_train_colp      = Cervical_Group_1_cancer_info.Colp_list(Indices_train_1);
    cancer_data_test_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_test_1);
    cancer_data_train_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_train_1);
    cancer_data_test_smear   = Cervical_Group_1_cancer_info.Smear_list(Indices_test_1);
    
    indices_0 = randperm(1149);
    Indices_train_0 = indices_0(1:949);
    Indices_test_0 = indices_0(950:end);
    
    non_cancer_data_train             = G1_non_cancer(Indices_train_0,:);
    non_cancer_data_test               = G1_non_cancer(Indices_test_0,:);
    non_cancer_data_train_colp    = Cervical_Group_1_non_cancer_info.Colp_list(Indices_train_0);
    non_cancer_data_test_colp      = Cervical_Group_1_non_cancer_info.Colp_list(Indices_test_0);
    non_cancer_data_train_smear = Cervical_Group_1_non_cancer_info.Smear_list(Indices_train_0);
    non_cancer_data_test_smear   = Cervical_Group_1_non_cancer_info.Smear_list(Indices_test_0);
    
    
    X_train = cat(1,non_cancer_data_train ,cancer_data_train); 
    Y_train = cat(1,zeros(949,1),ones(428,1));
    X_test = cat(1,non_cancer_data_test ,cancer_data_test);       
    Y_test = cat(1,zeros(200,1),ones(100,1));
    
    Colp_info_train = cat(1,non_cancer_data_train_colp,cancer_data_train_colp);
    Colp_info_test = cat(1,non_cancer_data_test_colp,cancer_data_test_colp);
    Smear_info_train = cat(1,non_cancer_data_train_smear,cancer_data_train_smear);
    Smear_info_test = cat(1,non_cancer_data_test_smear,cancer_data_test_smear);
    
    %% grid search----------------------------------------------------------------------------------------------------------------------
     for NumTrees_set = 20:20:120
         for MinLeafSize_set = 5:5:30
                for MaxNumSplits_set = 5:5:30
                    AA_save_group_1_AUC_Bayes_Colp(index_record_line,1) = NumTrees_set ;
                    AA_save_group_1_AUC_Bayes_Colp(index_record_line,2) = MinLeafSize_set ;
                    AA_save_group_1_AUC_Bayes_Colp(index_record_line,3) = MaxNumSplits_set ;

                    treeModel = TreeBagger(NumTrees_set, X_train, Y_train, 'MaxNumSplits', MaxNumSplits_set ,'MinLeafSize',MinLeafSize_set,'NumPredictorsToSample',2,'Method','classification');

                    [Y_pred_train,score_train] = predict(treeModel, X_train);
                    [Y_pred_test,score_test]    = predict(treeModel, X_test);
                    
                    [x_, y_, T_, AUC_test] = perfcurve(Y_test, score_test(:,2), 1);

                    %% ------------------------------------------------------------------------------------------------
                    %% step 1
                    % find the best threshold based on training data
                    % to make the Yuden score on the training results to be the best
                    % J = Sensitivity + Specificity -1
                    [threshold_best_final, training_specificity_final ,training_sensitivity_final] = threshold_selection(score_train(:,2), Y_train);
                    
                    %% ------------------------------------------------------------------------------------------------
                    %% step 3
                    %% calculate the metics on testing set  for Group 1
                    [accuracy_test,recall_test ,specificity_test,sensitivity_test] = ConfusionMatrix_cal(score_test(:,2),threshold_best_final,Y_test);
                        
                    %% step 4
                    % considering the prior knowledge
                    %% 4.1 calculate the prob of each dignosis statistics
                      %---------------------------------------------------------------------------------------------------------------
                    % -----------------------------------------------------------------------------------------------
                    % only colp
                    
                    Train_HG_1_colp_0 = 0;
                    Train_HG_1_colp_1 = 0;
                    Train_HG_0_colp_0 = 0;
                    Train_HG_0_colp_1 = 0;
                    
                    for i=1:428
                        if (cancer_data_train_colp(i) == 0) 
                            Train_HG_1_colp_0 = Train_HG_1_colp_0 +1;
                        else
                            Train_HG_1_colp_1 = Train_HG_1_colp_1 +1;
                        end
                    end
                    
                    for i = 1:949
                        if (non_cancer_data_train_colp(i) == 0) 
                            Train_HG_0_colp_0 = Train_HG_0_colp_0 +1;
                        else
                            Train_HG_0_colp_1 = Train_HG_0_colp_1 +1;
                        end
                    end
                    
                    % -----------------------------------------------------------------------------------------------
                    % only smear
                    
                    Train_HG_1_smear_0 = 0;
                    Train_HG_1_smear_1 = 0;
                    Train_HG_0_smear_0 = 0;
                    Train_HG_0_smear_1 = 0;
                    
                    for i=1:428
                        if (cancer_data_train_smear(i) == 0) 
                            Train_HG_1_smear_0 = Train_HG_1_smear_0 +1;
                        else
                            Train_HG_1_smear_1 = Train_HG_1_smear_1 +1;
                        end
                    end
                    
                    for i = 1:949
                        if (non_cancer_data_train_smear(i) == 0) 
                            Train_HG_0_smear_0 = Train_HG_0_smear_0 +1;
                        else
                            Train_HG_0_smear_1 = Train_HG_0_smear_1 +1;
                        end
                    end

                    %---------------------------------------------------------------------------------------------------------------
                    % colp and smear
                    Train_HG_1_colp_0_smear_0 = 0;
                    Train_HG_1_colp_0_smear_1 = 0;
                    Train_HG_1_colp_1_smear_0 = 0;
                    Train_HG_1_colp_1_smear_1 = 0;
                    
                    Train_HG_0_colp_0_smear_0 = 0;
                    Train_HG_0_colp_0_smear_1 = 0;
                    Train_HG_0_colp_1_smear_0 = 0;
                    Train_HG_0_colp_1_smear_1 = 0;
                    
                    for i=1:428
                        if (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 0)
                            Train_HG_1_colp_0_smear_0 = Train_HG_1_colp_0_smear_0 +1;
                    
                        elseif (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 1)
                            Train_HG_1_colp_0_smear_1 = Train_HG_1_colp_0_smear_1 +1;
                    
                        elseif (cancer_data_train_colp(i) == 1) &&(cancer_data_train_smear(i) == 0)
                            Train_HG_1_colp_1_smear_0 = Train_HG_1_colp_1_smear_0 +1;
                    
                        else
                            Train_HG_1_colp_1_smear_1 = Train_HG_1_colp_1_smear_1 +1;
                          
                        end
                    end
                    
                    
                    for i = 1:949
                        if (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 0)
                            Train_HG_0_colp_0_smear_0 = Train_HG_0_colp_0_smear_0 +1;
                    
                        elseif (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 1)
                            Train_HG_0_colp_0_smear_1 = Train_HG_0_colp_0_smear_1 +1;
                    
                        elseif (non_cancer_data_train_colp(i) == 1) &&(non_cancer_data_train_smear(i) == 0)
                            Train_HG_0_colp_1_smear_0 = Train_HG_0_colp_1_smear_0 +1;
                    
                        else
                            Train_HG_0_colp_1_smear_1 = Train_HG_0_colp_1_smear_1 +1;
                          
                        end
                    end

                    %% 4.2 ---------------------------------------------------------------------------------------------------------------
                    % ---------------------------------------------------------------------------------------------------------------
                    %% colp
                    % colp 0 
                    p_h_colp_0 = Train_HG_1_colp_0 / (Train_HG_1_colp_0 + Train_HG_0_colp_0);
                    % colp 1
                    p_h_colp_1 = Train_HG_1_colp_1/ (Train_HG_1_colp_1 + Train_HG_0_colp_1);
                    
                    % ---------------------------------------------------------------------------------------------------------------
                    %% smear
                    % smear 0 
                    p_h_smear_0 = Train_HG_1_smear_0 / (Train_HG_1_smear_0 + Train_HG_0_smear_0);
                    % smear 1
                    p_h_smear_1 = Train_HG_1_smear_1/ (Train_HG_1_smear_1 + Train_HG_0_smear_1);

                    % colp and smear
                    %% colp 0 smear 0
                    p_h_colp_smear_00 = Train_HG_1_colp_0_smear_0 / (Train_HG_1_colp_0_smear_0 + Train_HG_0_colp_0_smear_0);
                    % colp 0 smear 1
                    p_h_colp_smear_01 = Train_HG_1_colp_0_smear_1 / (Train_HG_1_colp_0_smear_1 + Train_HG_0_colp_0_smear_1);
                    % colp 1 smear 0
                    p_h_colp_smear_10 = Train_HG_1_colp_1_smear_0 / (Train_HG_1_colp_1_smear_0 + Train_HG_0_colp_1_smear_0);
                    % colp 1 smear 1
                    p_h_colp_smear_11 = Train_HG_1_colp_1_smear_1 / (Train_HG_1_colp_1_smear_1 + Train_HG_0_colp_1_smear_1); 
               




                    %% step 5
                    % calculate
                    % for testing data
                    AA_prediction_results_with_bayes_colp = zeros(300,1);


                    % ---------------------------------------------------------------------------------------------------------------
                    % just colp
                    for i=1:size(Y_test,1)
                        if (score_test(i,2)>=threshold_best_final) % model prediction is cancer case
                            % 
                            if (Colp_info_test(i)==1) %  colp =1 
                                % colp =1      结合统计学患癌的概率
                                p_h = p_h_colp_1;
                                AA_prediction_results_with_bayes_colp(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
                            end
                            if (Colp_info_test(i)==0) %  colp =0 
                                % colp =0      结合统计学患癌的概率
                                p_h = p_h_colp_0;
                                AA_prediction_results_with_bayes_colp(i,1)= (training_sensitivity_final*p_h)/((training_sensitivity_final*p_h)+(1-training_specificity_final)*(1-p_h));
                            end
                        end
                        if (score_test(i,2)<threshold_best_final) % model prediction is healthy case
                            % 
                            if (Colp_info_test(i)==1) %  colp =1
                                % colp =1      结合统计学患癌的概率
                                p_h = p_h_colp_1;
                                AA_prediction_results_with_bayes_colp(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
                            end
                             if (Colp_info_test(i)==0) %  colp =0 
                                % colp =0      结合统计学患癌的概率
                                p_h = p_h_colp_0;
                                AA_prediction_results_with_bayes_colp(i,1)= ((1-training_sensitivity_final)*p_h)/(((1-training_sensitivity_final)*p_h)+training_specificity_final*(1-p_h));
                             end
                        end
                    end
                   

                    [x_, y_, T_, AUC_test_add_Bayes_colp] = perfcurve(Y_test, AA_prediction_results_with_bayes_colp, 1);

                     index_record_col = 3+seed_nn;
                     AA_save_group_1_AUC_Bayes_Colp(index_record_line, index_record_col) = AUC_test_add_Bayes_colp;
                     index_record_line = index_record_line+1;
                end
         end
     end
end


save('AA_save_AUC_Bayes_Cervical_RF_Colp.mat','AA_save_group_1_AUC_Bayes_Colp')






