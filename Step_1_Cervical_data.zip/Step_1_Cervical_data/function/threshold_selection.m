function [threshold_best_final,training_specificity_final,training_sensitivity_final] = threshold_selection(score_train,Y_train)

% find the best threshold based on training data
% to make the Yuden score on the training results to be the best
% J = Sensitivity + Specificity -1

num_train = size(score_train,1);
threshold_best_final = 0;
J_max = 0;

for tt = 1:num_train
    threshold_best = score_train(tt,1);
    TP = 0;FP = 0;TN = 0;FN = 0;
    for ttt = 1:num_train
        if (score_train(ttt,1)>=threshold_best)&&(Y_train(ttt)==1)
            TP = TP+1;
        elseif (score_train(ttt,1)>=threshold_best)&&(Y_train(ttt)==0)
            FP = FP+1;
        elseif (score_train(ttt,1)<threshold_best)&&(Y_train(ttt)==0)
            TN = TN+1;
        else
            FN = FN+1;
        end
    end
    J = (TP/(TP+FN)) +(TN/(TN+FP)) -1;
    if J >(J_max)
        J_max = J;
        threshold_best_final = threshold_best;
    end
end

%% step 2
% set the threshold ratio to optimal threshold achieved above
% a is from 1.0 to 0.1
alpha_t = [1.0 0.9 0.8 0.7 0.6 0.5 0.4 0.3 0.2 0.1];
for ee = 1:10
    threshold_middle = alpha_t(ee)*threshold_best_final;
            
    TP = 0;FP = 0;TN = 0;FN = 0;
    for ttt = 1:num_train

        if (score_train(ttt,1)>=threshold_middle)&&(Y_train(ttt)==1)
            TP = TP+1;
        elseif (score_train(ttt,1)>=threshold_middle)&&(Y_train(ttt)==0)
            FP = FP+1;
        elseif (score_train(ttt,1)<threshold_middle)&&(Y_train(ttt)==0)
            TN = TN+1;
        else
            FN = FN+1;
        end

    end
    specificity_middle = TN/ (TN + FP);
    sensitivity_middle = TP/ (TP + FN);
    FPR_middle = FP/(FP+TN);
    TNR_middle = TN/(TN+FP);

    if sensitivity_middle > 0.50
        alpha_final = alpha_t(ee);
        training_specificity_final = specificity_middle;
        training_sensitivity_final = sensitivity_middle;
        training_FPR_final = FPR_middle;
        training_TNR_final = TNR_middle;
        break;
    else 
        alpha_final =1;
        training_specificity_final = specificity_middle;
        training_sensitivity_final = sensitivity_middle;
        training_FPR_final = FPR_middle;
        training_TNR_final = TNR_middle;
    end
end
threshold_best_final = alpha_final*threshold_best_final;




end