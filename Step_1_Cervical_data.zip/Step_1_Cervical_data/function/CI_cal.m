function [mean_val, std_val,ci_lower,ci_upper] = CI_cal(data)

% 平均值
mean_val = mean(data);

% 方差（无偏估计，除以 n-1）
std_val = std(data);

% 样本数量
n = length(data);

% 标准误差
stderr = std(data) / sqrt(n);

% t 分布临界值（双尾 95% 置信区间）
t_crit = tinv(0.975, n - 1);  % 0.975 = (1 + 0.95) / 2

% 置信区间
ci_lower = mean_val - t_crit * stderr;
ci_upper = mean_val + t_crit * stderr;


end