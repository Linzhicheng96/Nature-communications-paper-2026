function [accuracy_test,recall_test,specificity_test,sensitivity_test] = ConfusionMatrix_cal(score_test,threshold_best_final,Y_test)
TP_test = 0;FP_test= 0;TN_test= 0;FN_test= 0;

for oo = 1:size(score_test,1)
    if (score_test(oo,1)>=threshold_best_final)&&(Y_test(oo)==1)
        TP_test= TP_test+1;
    elseif (score_test(oo,1)>=threshold_best_final)&&(Y_test(oo)==0)
        FP_test = FP_test+1;
    elseif (score_test(oo,1)<threshold_best_final)&&(Y_test(oo)==0)
        TN_test = TN_test+1;
    else
        FN_test = FN_test+1;
    end
end


accuracy_test  = (TP_test + TN_test) / (TP_test + FP_test + FN_test + TN_test);
recall_test         = TP_test / (TP_test + FN_test); % 召回率，也称为真正率或灵敏度
specificity_test = TN_test / (TN_test + FP_test); % 特异性
sensitivity_test = TP_test / (TP_test + FN_test);% 灵敏度，与召回率相同
TPR_test = TP_test/(TP_test+FN_test);
FPR_test= FP_test/(FP_test+TN_test);

end