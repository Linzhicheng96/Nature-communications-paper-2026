clc
clear

%% data loading ----------------------------------------------------------------------------------------------------
% Group 1
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_Cancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_NonCancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_cancer_data_and_info.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_non_cancer_data_and_info.mat')

% Group 2
load('../../data/cervical data London/postprocessed_by_Lin/Cervical_Group_2_coleModel_MaxDiffMean_112.mat')
rng(1)
%% data filtering ----------------------------------------------------------------------------------------------------
%% Group 2
G2_cancer          = cat(2,Cervical_Group_2_cancer_MeanValues,          Cervical_Group_2_cancer_MaxDiff);
G2_non_cancer = cat(2,Cervical_Group_2_non_cancer_MeanValues,Cervical_Group_2_non_cancer_MaxDiff);

X_test_Group_2 = cat(1,G2_non_cancer,G2_cancer);
Y_test_Group_2 = cat(1,zeros(93,1),        ones(19,1));

Group_2_Colp_info     =cat(1,Cervical_Group_2_non_cancer_info.Colp,    Cervical_Group_2_cancer_info.Colp);
Group_2_Smear_info  =cat(1,Cervical_Group_2_non_cancer_info.Smear,Cervical_Group_2_cancer_info.Smear);

%% Group 1
G1_cancer          = cat(2,Cervical_Group_1_cancer_MeanValues,          Cervical_Group_1_cancer_MaxDiff);
G1_non_cancer = cat(2,Cervical_Group_1_non_cancer_MeanValues,Cervical_Group_1_non_cancer_MaxDiff);



%%  --------------------------------------------------------------------------------------------------------------------


%% split the data Group1  to training and testing dataset
% cancer data 528             vali and test      428:100
% non cancer data 1149   vali and test      949:200
indices_1 = randperm(528);
Indices_train_1 = indices_1(1:428);
Indices_test_1 = indices_1(429:end);

cancer_data_train                 = G1_cancer(Indices_train_1,:);
cancer_data_test                  =  G1_cancer(Indices_test_1,:);
cancer_data_train_colp      = Cervical_Group_1_cancer_info.Colp_list(Indices_train_1);
cancer_data_test_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_test_1);
cancer_data_train_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_train_1);
cancer_data_test_smear   = Cervical_Group_1_cancer_info.Smear_list(Indices_test_1);

indices_0 = randperm(1149);
Indices_train_0 = indices_0(1:949);
Indices_test_0 = indices_0(950:end);

non_cancer_data_train             = G1_non_cancer(Indices_train_0,:);
non_cancer_data_test               = G1_non_cancer(Indices_test_0,:);
non_cancer_data_train_colp    = Cervical_Group_1_non_cancer_info.Colp_list(Indices_train_0);
non_cancer_data_test_colp      = Cervical_Group_1_non_cancer_info.Colp_list(Indices_test_0);
non_cancer_data_train_smear = Cervical_Group_1_non_cancer_info.Smear_list(Indices_train_0);
non_cancer_data_test_smear   = Cervical_Group_1_non_cancer_info.Smear_list(Indices_test_0);


X_train = cat(1,non_cancer_data_train ,cancer_data_train); 
Y_train = cat(1,zeros(949,1),ones(428,1));
X_test = cat(1,non_cancer_data_test ,cancer_data_test);       
Y_test = cat(1,zeros(200,1),ones(100,1));

%% just use MaxDiff
% X_train = X_train(:,5:8);
% X_test = X_test(:,5:8);
% X_test_Group_2 = X_test_Group_2(:,5:8);

%% ------------------------------------------------------------------------------------------------
%% KNN
% knnModel = fitcknn(X_train, Y_train, 'NumNeighbors', 6, 'Standardize', 1);
% [Y_pred_test,score_test] =  predict(knnModel, X_test);
% [Y_pred_train,score_train] = predict(knnModel, X_train);

%% Decision tree
MinParentSize_set = 30;
MinLeafSize_set = 10;
treeModel = fitctree(X_train, Y_train,'MinParentSize',MinParentSize_set,'MinLeafSize',MinLeafSize_set);


[Y_pred_train,score_train] = predict(treeModel, X_train);
[Y_pred_test,score_test]    = predict(treeModel, X_test);
[Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);

[x_, y_, T_, AUC_test] = perfcurve(Y_test, score_test(:,2), 1);
[x_, y_, T_, AUC_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);




%% ------------------------------------------------------------------------------------------------
%% step 1
% find the best threshold based on training data
% to make the Yuden score on the training results to be the best
% J = Sensitivity + Specificity -1

num_train = size(score_train,1);
threshold_best_final = 0;
J_max = 0;

for tt = 1:num_train
    threshold_best = score_train(tt,2);
    TP = 0;FP = 0;TN = 0;FN = 0;
    for ttt = 1:num_train
        if (score_train(ttt,2)>=threshold_best)&&(Y_train(ttt)==1)
            TP = TP+1;
        elseif (score_train(ttt,2)>=threshold_best)&&(Y_train(ttt)==0)
            FP = FP+1;
        elseif (score_train(ttt,2)<threshold_best)&&(Y_train(ttt)==0)
            TN = TN+1;
        else
            FN = FN+1;
        end
    end
    J = (TP/(TP+FN)) +(TN/(TN+FP)) -1;
  
    if J >(J_max)
        J_max = J;
        threshold_best_final = threshold_best;
    end
end
%% ------------------------------------------------------------------------------------------------
%% step 2
% set the threshold ratio to optimal threshold achieved above
% a is from 1.0 to 0.1
alpha_t = [1.0 0.9 0.8 0.7 0.6 0.5 0.4 0.3 0.2 0.1];
for ee = 1:10
    threshold_middle = alpha_t(ee)*threshold_best_final;
            
    TP = 0;FP = 0;TN = 0;FN = 0;
    for ttt = 1:num_train

        if (score_train(ttt,2)>=threshold_middle)&&(Y_train(ttt)==1)
            TP = TP+1;
        elseif (score_train(ttt,2)>=threshold_middle)&&(Y_train(ttt)==0)
            FP = FP+1;
        elseif (score_train(ttt,2)<threshold_middle)&&(Y_train(ttt)==0)
            TN = TN+1;
        else
            FN = FN+1;
        end

    end
    specificity_middle = TN/ (TN + FP);
    sensitivity_middle = TP/ (TP + FN);
    FPR_middle = FP/(FP+TN);
    TNR_middle = TN/(TN+FP);

    if sensitivity_middle > 0.75
        alpha_final = alpha_t(ee);
        training_specificity_final = specificity_middle;
        training_sensitivity_final = sensitivity_middle;
        training_FPR_final = FPR_middle;
        training_TNR_final = TNR_middle;
        break;
    end
end
threshold_best_final = alpha_final*threshold_best_final;


%% ------------------------------------------------------------------------------------------------
%% step 3
%% calculate the metics on testing set  for Group 1
TP_test = 0;FP_test = 0;TN_test = 0;FN_test = 0;
for oo = 1:size(score_test,1)
    if (score_test(oo,2)>=threshold_best_final)&&(Y_test(oo)==1)
        TP_test = TP_test+1;
    elseif (score_test(oo,2)>=threshold_best_final)&&(Y_test(oo)==0)
        FP_test = FP_test+1;
    elseif (score_test(oo,2)<threshold_best_final)&&(Y_test(oo)==0)
        TN_test = TN_test+1;
    else
        FN_test = FN_test+1;
    end
end
accuracy_test = (TP_test + TN_test) / (TP_test + FP_test + FN_test + TN_test);
recall_test = TP_test / (TP_test + FN_test); % 召回率，也称为真正率或灵敏度
specificity_test = TN_test / (TN_test + FP_test) % 特异性
sensitivity_test = TP_test / (TP_test + FN_test)% 灵敏度，与召回率相同


%% calculate the metics on testing set  for Group 2 from London
TP_test_London = 0;FP_test_London = 0;TN_test_London = 0;FN_test_London = 0;
for oo = 1:size(score_test_London,1)
    if (score_test_London(oo,2)>=threshold_best_final)&&(Y_test_Group_2(oo)==1)
        TP_test_London= TP_test_London+1;
    elseif (score_test_London(oo,2)>=threshold_best_final)&&(Y_test_Group_2(oo)==0)
        FP_test_London = FP_test_London+1;
    elseif (score_test_London(oo,2)<threshold_best_final)&&(Y_test_Group_2(oo)==0)
        TN_test_London = TN_test_London+1;
    else
        FN_test_London = FN_test_London+1;
    end
end

accuracy_test_London  = (TP_test_London + TN_test_London) / (TP_test_London + FP_test_London + FN_test_London + TN_test_London);
recall_test_London         = TP_test_London / (TP_test_London + FN_test_London); % 召回率，也称为真正率或灵敏度
specificity_test_London = TN_test_London / (TN_test_London + FP_test_London) % 特异性
sensitivity_test_London = TP_test_London / (TP_test_London + FN_test_London)% 灵敏度，与召回率相同
























