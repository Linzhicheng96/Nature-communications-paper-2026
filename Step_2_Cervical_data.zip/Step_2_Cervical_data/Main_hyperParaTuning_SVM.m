clc
clear
%% load data ---------------------------------------------------------------------------------------------------------
% Group 1
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_Cancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_NonCancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_cancer_data_and_info.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_non_cancer_data_and_info.mat')
% Group 2
load('../../data/cervical data London/postprocessed_by_Lin/Cervical_Group_2_coleModel_MaxDiffMean_112.mat')
% data filtering ----------------------------------------------------------------------------------------------------
% Group 2
G2_cancer          = cat(2,Cervical_Group_2_cancer_MeanValues,          Cervical_Group_2_cancer_MaxDiff);
G2_non_cancer = cat(2,Cervical_Group_2_non_cancer_MeanValues,Cervical_Group_2_non_cancer_MaxDiff);
X_test_Group_2 = cat(1,G2_non_cancer,G2_cancer);
Y_test_Group_2 = cat(1,zeros(93,1),        ones(19,1));
Group_2_Colp_info     =cat(1,Cervical_Group_2_non_cancer_info.Colp,    Cervical_Group_2_cancer_info.Colp);
Group_2_Smear_info  =cat(1,Cervical_Group_2_non_cancer_info.Smear,Cervical_Group_2_cancer_info.Smear);
Colp_info_test_London = Group_2_Colp_info;
Smear_info_test_London = Group_2_Smear_info;
%% Group 1
G1_cancer          = cat(2,Cervical_Group_1_cancer_MeanValues,          Cervical_Group_1_cancer_MaxDiff);
G1_non_cancer = cat(2,Cervical_Group_1_non_cancer_MeanValues,Cervical_Group_1_non_cancer_MaxDiff);
%% ----------------------------------------------------------------------------------------------------------------------
AA_save_AUC_vali = zeros(216,103); % first 3 record hyper-pare, and later 100 record the AUC
for seed_nn = 1:100
    fprintf('the round is in %d \n',seed_nn);  rng(seed_nn);  index_record_line = 1;
    %% split  Group1  to training, validation and test dataset ------------------------------------------------------
    % cancer data 528                 422:53:53
    % non cancer data 1149      919:115:115
    indices_1 = randperm(528);
    Indices_train_1 = indices_1(1:422);
    Indices_vali_1   = indices_1(423:475);
    Indices_test_1   = indices_1(476:end);

    cancer_data_train                 = G1_cancer(Indices_train_1,:);
    cancer_data_vali                   = G1_cancer(Indices_vali_1,:);
    cancer_data_test                  =  G1_cancer(Indices_test_1,:);
    cancer_data_train_colp      = Cervical_Group_1_cancer_info.Colp_list(Indices_train_1);
    cancer_data_vali_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_vali_1);
    cancer_data_test_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_test_1);
    cancer_data_train_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_train_1);
    cancer_data_vali_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_vali_1);
    cancer_data_test_smear   = Cervical_Group_1_cancer_info.Smear_list(Indices_test_1);

    indices_0 = randperm(1149);
    Indices_train_0 = indices_0(1:919);
    Indices_vali_0   = indices_0(920:1034);
    Indices_test_0 = indices_0(1035:end);

    non_cancer_data_train              = G1_non_cancer(Indices_train_0,:);
    non_cancer_data_vali                = G1_non_cancer(Indices_vali_0,:);
    non_cancer_data_test                = G1_non_cancer(Indices_test_0,:);
    non_cancer_data_train_colp     = Cervical_Group_1_non_cancer_info.Colp_list(Indices_train_0);
    non_cancer_data_vali_colp       = Cervical_Group_1_non_cancer_info.Colp_list(Indices_vali_0);
    non_cancer_data_test_colp       = Cervical_Group_1_non_cancer_info.Colp_list(Indices_test_0);
    non_cancer_data_train_smear  = Cervical_Group_1_non_cancer_info.Smear_list(Indices_train_0);
    non_cancer_data_vali_smear    = Cervical_Group_1_non_cancer_info.Smear_list(Indices_vali_0);
    non_cancer_data_test_smear    = Cervical_Group_1_non_cancer_info.Smear_list(Indices_test_0);

    X_train = cat(1,non_cancer_data_train ,cancer_data_train); 
    Y_train = cat(1,zeros(919,1),ones(422,1));
    X_vali = cat(1,non_cancer_data_vali ,cancer_data_vali); 
    Y_vali = cat(1,zeros(115,1),ones(53,1));
    X_test = cat(1,non_cancer_data_test ,cancer_data_test);       
    Y_test = cat(1,zeros(115,1),ones(53,1));

    Colp_info_train = cat(1,non_cancer_data_train_colp,cancer_data_train_colp);
    Colp_info_vali = cat(1,non_cancer_data_vali_colp,cancer_data_vali_colp);
    Colp_info_test = cat(1,non_cancer_data_test_colp,cancer_data_test_colp);
    Smear_info_train = cat(1,non_cancer_data_train_smear,cancer_data_train_smear);
    Smear_info_vali = cat(1,non_cancer_data_vali_smear,cancer_data_vali_smear);
    Smear_info_test = cat(1,non_cancer_data_test_smear,cancer_data_test_smear);

    BoxConstraint_set = [0.0001, 0.001, 0.01, 0.1, 1, 10, 100];
    KernelFunction = {'rbf', 'linear'};
    %% grid search----------------------------------------------------------------------------------------------------------------------
     for BoxConstraint_set_i = 1:1:7
         for KernelFunction_set_i = 1:1:2

                    AA_save_AUC_vali(index_record_line,1) = BoxConstraint_set(BoxConstraint_set_i) ;
                    if isequal(KernelFunction{KernelFunction_set_i} ,'rbf')
                        jh = 1;
                    else
                        jh = 2;
                    end
                    AA_save_AUC_vali(index_record_line,2) = jh ;


                    treeModel = fitcsvm(X_train, Y_train,'KernelFunction',string(KernelFunction(KernelFunction_set_i)),'BoxConstraint', BoxConstraint_set(BoxConstraint_set_i),'Standardize',true);

                    [Y_pred_train,score_train] = predict(treeModel, X_train);
                    [Y_pred_vali,  score_vali] = predict(treeModel, X_vali);
                    [Y_pred_test,score_test]    = predict(treeModel, X_test);

                    [x_, y_, T_, AUC_vali] = perfcurve(Y_test, score_vali(:,2), 1);
                    [x_, y_, T_, AUC_test] = perfcurve(Y_test, score_test(:,2), 1);

                    
             
                    %% calculate the AUC of vali and compare
                    index_record_col = 3+seed_nn;
                    AA_save_AUC_vali(index_record_line, index_record_col) = AUC_vali;
                    index_record_line = index_record_line+1;
                end
         end

end

save('./Tuning/AA_save_AUC_vali_SVM_Cervical.mat','AA_save_AUC_vali')







