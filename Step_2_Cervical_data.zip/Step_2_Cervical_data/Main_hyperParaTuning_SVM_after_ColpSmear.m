clc
clear
%% load data ---------------------------------------------------------------------------------------------------------
% Group 1
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_Cancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_NonCancer_data_coleModel_MaxDiffMean.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_cancer_data_and_info.mat')
load('../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_non_cancer_data_and_info.mat')
% Group 2
load('../../data/cervical data London/postprocessed_by_Lin/Cervical_Group_2_coleModel_MaxDiffMean_112.mat')
% data filtering ----------------------------------------------------------------------------------------------------
% Group 2
G2_cancer          = cat(2,Cervical_Group_2_cancer_MeanValues,          Cervical_Group_2_cancer_MaxDiff);
G2_non_cancer = cat(2,Cervical_Group_2_non_cancer_MeanValues,Cervical_Group_2_non_cancer_MaxDiff);
X_test_Group_2 = cat(1,G2_non_cancer,G2_cancer);
Y_test_Group_2 = cat(1,zeros(93,1),        ones(19,1));
Group_2_Colp_info     =cat(1,Cervical_Group_2_non_cancer_info.Colp,    Cervical_Group_2_cancer_info.Colp);
Group_2_Smear_info  =cat(1,Cervical_Group_2_non_cancer_info.Smear,Cervical_Group_2_cancer_info.Smear);
Colp_info_test_London = Group_2_Colp_info;
Smear_info_test_London = Group_2_Smear_info;
%% Group 1
G1_cancer          = cat(2,Cervical_Group_1_cancer_MeanValues,          Cervical_Group_1_cancer_MaxDiff);
G1_non_cancer = cat(2,Cervical_Group_1_non_cancer_MeanValues,Cervical_Group_1_non_cancer_MaxDiff);
%% ----------------------------------------------------------------------------------------------------------------------
% the best pair of hyper-para


AAA_FINAL_METRICS_SAVE = zeros(100,9);
%  AUC_test,                                    specificity_test,                    sensitivity_test,
%  AUC_test_add_Bayes_G1,       specificity_test_G1,             sensitivity_test_G1,
%  AUC_test_add_Bayes_G2,       specificity_test_G2,             sensitivity_test_G2,

for seed_nn = 1:100
    fprintf('the round is in %d \n',seed_nn);  rng(seed_nn);  index_record_line = 1;
    %% split  Group1  to training, validation and test dataset ------------------------------------------------------
    % cancer data 528                 422:53:53
    % non cancer data 1149      919:115:115
    indices_1 = randperm(528);
    Indices_train_1 = indices_1(1:422);
    Indices_vali_1   = indices_1(423:475);
    Indices_test_1   = indices_1(476:end);

    cancer_data_train                 = G1_cancer(Indices_train_1,:);
    cancer_data_vali                   = G1_cancer(Indices_vali_1,:);
    cancer_data_test                  =  G1_cancer(Indices_test_1,:);
    cancer_data_train_colp      = Cervical_Group_1_cancer_info.Colp_list(Indices_train_1);
    cancer_data_vali_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_vali_1);
    cancer_data_test_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_test_1);
    cancer_data_train_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_train_1);
    cancer_data_vali_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_vali_1);
    cancer_data_test_smear   = Cervical_Group_1_cancer_info.Smear_list(Indices_test_1);

    indices_0 = randperm(1149);
    Indices_train_0 = indices_0(1:919);
    Indices_vali_0   = indices_0(920:1034);
    Indices_test_0 = indices_0(1035:end);

    non_cancer_data_train              = G1_non_cancer(Indices_train_0,:);
    non_cancer_data_vali                = G1_non_cancer(Indices_vali_0,:);
    non_cancer_data_test                = G1_non_cancer(Indices_test_0,:);
    non_cancer_data_train_colp     = Cervical_Group_1_non_cancer_info.Colp_list(Indices_train_0);
    non_cancer_data_vali_colp       = Cervical_Group_1_non_cancer_info.Colp_list(Indices_vali_0);
    non_cancer_data_test_colp       = Cervical_Group_1_non_cancer_info.Colp_list(Indices_test_0);
    non_cancer_data_train_smear  = Cervical_Group_1_non_cancer_info.Smear_list(Indices_train_0);
    non_cancer_data_vali_smear    = Cervical_Group_1_non_cancer_info.Smear_list(Indices_vali_0);
    non_cancer_data_test_smear    = Cervical_Group_1_non_cancer_info.Smear_list(Indices_test_0);

    X_train = cat(1,non_cancer_data_train ,cancer_data_train); 
    Y_train = cat(1,zeros(919,1),ones(422,1));
    X_vali = cat(1,non_cancer_data_vali ,cancer_data_vali); 
    Y_vali = cat(1,zeros(115,1),ones(53,1));
    X_test = cat(1,non_cancer_data_test ,cancer_data_test);       
    Y_test = cat(1,zeros(115,1),ones(53,1));

    Colp_info_train = cat(1,non_cancer_data_train_colp,cancer_data_train_colp);
    Colp_info_vali = cat(1,non_cancer_data_vali_colp,cancer_data_vali_colp);
    Colp_info_test = cat(1,non_cancer_data_test_colp,cancer_data_test_colp);
    Smear_info_train = cat(1,non_cancer_data_train_smear,cancer_data_train_smear);
    Smear_info_vali = cat(1,non_cancer_data_vali_smear,cancer_data_vali_smear);
    Smear_info_test = cat(1,non_cancer_data_test_smear,cancer_data_test_smear);

    %% ----------------------------------------------------------------------------------------------------------------------

    treeModel = fitcsvm(X_train, Y_train,'KernelFunction','rbf','BoxConstraint', 0.1,'Standardize',true);

    [Y_pred_train,score_train] = predict(treeModel, X_train);
    [Y_pred_vali,  score_vali] = predict(treeModel, X_vali);
    [Y_pred_test,score_test]    = predict(treeModel, X_test);
    [Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);

    [x_, y_, T_, AUC_vali] = perfcurve(Y_test, score_vali(:,2), 1);
    [x_, y_, T_, AUC_test] = perfcurve(Y_test, score_test(:,2), 1);
    [x_, y_, T_, AUC_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);

    %% ------------------------------------------------------------------------------------------------
    %% step 1
    % find the best threshold based on 'validation' data
    % to make the Yuden score on the validation results to be the best
    % J = Sensitivity + Specificity -1
    [threshold_best_final, validation_specificity_final ,validation_sensitivity_final] = threshold_selection(score_vali(:,2), Y_vali);
    %% step 2
    % calculate the metrics of test set
    [accuracy_test,recall_test ,specificity_test,sensitivity_test] = ConfusionMatrix_cal(score_test(:,2),threshold_best_final,Y_test);
    [accuracy_test_London,recall_test_London ,specificity_test_London,sensitivity_test_London] = ConfusionMatrix_cal(score_test_London(:,2),threshold_best_final,Y_test_Group_2);
    %% step 3
    % considering the prior knowledge
    %% 3.1 calculate the prob of each dignosis statistics
    %% step 3
    % considering the prior knowledge
    %% 3.1 calculate the prob of each dignosis statistics
    % only colp
    Train_HG_1_colp_0 = 0; Train_HG_1_colp_1 = 0;
    Train_HG_0_colp_0 = 0; Train_HG_0_colp_1 = 0;

    for i=1:size(cancer_data_train_colp,1)
        if (cancer_data_train_colp(i) == 0) 
            Train_HG_1_colp_0 = Train_HG_1_colp_0 +1;
        else
            Train_HG_1_colp_1 = Train_HG_1_colp_1 +1;
        end
    end
    
    for i = 1:size(non_cancer_data_train_colp,1)
        if (non_cancer_data_train_colp(i) == 0) 
            Train_HG_0_colp_0 = Train_HG_0_colp_0 +1;
        else
            Train_HG_0_colp_1 = Train_HG_0_colp_1 +1;
        end
    end
    
    % only smear
    Train_HG_1_smear_0 = 0;Train_HG_1_smear_1 = 0;
    Train_HG_0_smear_0 = 0;Train_HG_0_smear_1 = 0;   

    for i=1:size(cancer_data_train_smear,1)
        if (cancer_data_train_smear(i) == 0) 
            Train_HG_1_smear_0 = Train_HG_1_smear_0 +1;
        else
            Train_HG_1_smear_1 = Train_HG_1_smear_1 +1;
        end
    end
   
    for i = 1:size(non_cancer_data_train_smear,1)
        if (non_cancer_data_train_smear(i) == 0) 
            Train_HG_0_smear_0 = Train_HG_0_smear_0 +1;
        else
            Train_HG_0_smear_1 = Train_HG_0_smear_1 +1;
        end
    end
    
    % colp and smear
    Train_HG_1_colp_0_smear_0 = 0;Train_HG_1_colp_0_smear_1 = 0;
    Train_HG_1_colp_1_smear_0 = 0;Train_HG_1_colp_1_smear_1 = 0;
    
    Train_HG_0_colp_0_smear_0 = 0;Train_HG_0_colp_0_smear_1 = 0;
    Train_HG_0_colp_1_smear_0 = 0;Train_HG_0_colp_1_smear_1 = 0;
    
    for i=1:size(cancer_data_train_colp,1)
        if (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_0_smear_0 = Train_HG_1_colp_0_smear_0 +1;
        elseif (cancer_data_train_colp(i) == 0) &&(cancer_data_train_smear(i) == 1)
            Train_HG_1_colp_0_smear_1 = Train_HG_1_colp_0_smear_1 +1;
        elseif (cancer_data_train_colp(i) == 1) &&(cancer_data_train_smear(i) == 0)
            Train_HG_1_colp_1_smear_0 = Train_HG_1_colp_1_smear_0 +1;
        else
            Train_HG_1_colp_1_smear_1 = Train_HG_1_colp_1_smear_1 +1;
        end
    end
    
    for i = 1:size(non_cancer_data_train_colp,1)
        if (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_0_smear_0 = Train_HG_0_colp_0_smear_0 +1;  
        elseif (non_cancer_data_train_colp(i) == 0) &&(non_cancer_data_train_smear(i) == 1)
            Train_HG_0_colp_0_smear_1 = Train_HG_0_colp_0_smear_1 +1;
        elseif (non_cancer_data_train_colp(i) == 1) &&(non_cancer_data_train_smear(i) == 0)
            Train_HG_0_colp_1_smear_0 = Train_HG_0_colp_1_smear_0 +1;
        else
            Train_HG_0_colp_1_smear_1 = Train_HG_0_colp_1_smear_1 +1;
        end
    end
    
    %% 3.2 ---------------------------------------------------------------------------------------------------------------
    % ---------------------------------------------------------------------------------------------------------------
    % colp
    % colp 0 
    p_h_colp_0 = Train_HG_1_colp_0 / (Train_HG_1_colp_0 + Train_HG_0_colp_0);
    % colp 1
    p_h_colp_1 = Train_HG_1_colp_1/ (Train_HG_1_colp_1 + Train_HG_0_colp_1);
    
    % ---------------------------------------------------------------------------------------------------------------
    % smear
    % smear 0 
    p_h_smear_0 = Train_HG_1_smear_0 / (Train_HG_1_smear_0 + Train_HG_0_smear_0);
    % smear 1
    p_h_smear_1 = Train_HG_1_smear_1/ (Train_HG_1_smear_1 + Train_HG_0_smear_1);

    % colp and smear
    % colp 0 smear 0
    p_h_colp_smear_00 = Train_HG_1_colp_0_smear_0 / (Train_HG_1_colp_0_smear_0 + Train_HG_0_colp_0_smear_0);
    % colp 0 smear 1
    p_h_colp_smear_01 = Train_HG_1_colp_0_smear_1 / (Train_HG_1_colp_0_smear_1 + Train_HG_0_colp_0_smear_1);
    % colp 1 smear 0
    p_h_colp_smear_10 = Train_HG_1_colp_1_smear_0 / (Train_HG_1_colp_1_smear_0 + Train_HG_0_colp_1_smear_0);
    % colp 1 smear 1
    p_h_colp_smear_11 = Train_HG_1_colp_1_smear_1 / (Train_HG_1_colp_1_smear_1 + Train_HG_0_colp_1_smear_1); 
               
    %% step 4
    % calculate Bayes prob
    % for testing data
    AA_prediction_results_with_bayes_colp_smear  = zeros(size(Y_test,1),1);
    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    for i=1:size(Y_test,1)
        if (score_test(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_test(i)==1)&&(Smear_info_test(i)==1) %  colp =1 smear 1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (validation_sensitivity_final*p_h)/((validation_sensitivity_final*p_h)+(1-validation_specificity_final)*(1-p_h));
            end
                    
            if (Colp_info_test(i)==1)&&(Smear_info_test(i)==0) %  colp =1 smear 0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (validation_sensitivity_final*p_h)/((validation_sensitivity_final*p_h)+(1-validation_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test(i)==0)&&(Smear_info_test(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (validation_sensitivity_final*p_h)/((validation_sensitivity_final*p_h)+(1-validation_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test(i)==0)&&(Smear_info_test(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear(i,1)= (validation_sensitivity_final*p_h)/((validation_sensitivity_final*p_h)+(1-validation_specificity_final)*(1-p_h));
            end
    
    
        end
    
        if (score_test(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_test(i)==1)&&(Smear_info_test(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-validation_sensitivity_final)*p_h)/(((1-validation_sensitivity_final)*p_h)+validation_specificity_final*(1-p_h));
            end
    
             if (Colp_info_test(i)==1)&&(Smear_info_test(i)==0) %  colp =0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-validation_sensitivity_final)*p_h)/(((1-validation_sensitivity_final)*p_h)+validation_specificity_final*(1-p_h));
             end
    
             if (Colp_info_test(i)==0)&&(Smear_info_test(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-validation_sensitivity_final)*p_h)/(((1-validation_sensitivity_final)*p_h)+validation_specificity_final*(1-p_h));
            end
    
            if (Colp_info_test(i)==0)&&(Smear_info_test(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear(i,1)= ((1-validation_sensitivity_final)*p_h)/(((1-validation_sensitivity_final)*p_h)+validation_specificity_final*(1-p_h));
            end
        end
    end
    [x_, y_, T_, AUC_test_add_Bayes_colp_smear] = perfcurve(Y_test, AA_prediction_results_with_bayes_colp_smear, 1);
    
    
    % for gourp 2 data from London
    AA_prediction_results_with_bayes_colp_smear_London = zeros(112,1);


    % ---------------------------------------------------------------------------------------------------------------
    % colp and smear
    for i=1:size(Y_test_Group_2,1)
        if (score_test_London(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==1) %  colp =1 smear 1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= (validation_sensitivity_final*p_h)/((validation_sensitivity_final*p_h)+(1-validation_specificity_final)*(1-p_h));
            end
                    
            if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==0) %  colp =1 smear 0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)=  (validation_sensitivity_final*p_h)/((validation_sensitivity_final*p_h)+(1-validation_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)=  (validation_sensitivity_final*p_h)/((validation_sensitivity_final*p_h)+(1-validation_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)=  (validation_sensitivity_final*p_h)/((validation_sensitivity_final*p_h)+(1-validation_specificity_final)*(1-p_h));
            end
        end
    
        if (score_test_London(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-validation_sensitivity_final)*p_h)/(((1-validation_sensitivity_final)*p_h)+validation_specificity_final*(1-p_h));
            end
    
             if (Colp_info_test_London(i)==1)&&(Smear_info_test_London(i)==0) %  colp =0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-validation_sensitivity_final)*p_h)/(((1-validation_sensitivity_final)*p_h)+validation_specificity_final*(1-p_h));
             end
    
             if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-validation_sensitivity_final)*p_h)/(((1-validation_sensitivity_final)*p_h)+validation_specificity_final*(1-p_h));
            end
    
            if (Colp_info_test_London(i)==0)&&(Smear_info_test_London(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_London(i,1)= ((1-validation_sensitivity_final)*p_h)/(((1-validation_sensitivity_final)*p_h)+validation_specificity_final*(1-p_h));
            end
        end
    end

    [x_, y_, T_, AUC_test_add_Bayes_colp_smear_London] = perfcurve(Y_test_Group_2, AA_prediction_results_with_bayes_colp_smear_London, 1);

    %% Step 5
    % Bayes results in validation dataset
    % using prior on validation results (Y_pred_vali,   score_vali )
    % and using threshold selection method to find the best threshold on Bayes validation
    AA_prediction_results_with_bayes_colp_smear_vali = zeros(size(Y_vali,1),1);
    % colp and smear
    for i=1:size(Y_vali,1)
        if (score_vali(i,2)>=threshold_best_final) % model prediction is cancer case
            % 
            if (Colp_info_vali(i)==1)&&(Smear_info_vali(i)==1) %  colp =1 smear 1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_vali(i,1)= (validation_sensitivity_final*p_h)/((validation_sensitivity_final*p_h)+(1-validation_specificity_final)*(1-p_h));
            end
                    
            if (Colp_info_vali(i)==1)&&(Smear_info_vali(i)==0) %  colp =1 smear 0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_vali(i,1)= (validation_sensitivity_final*p_h)/((validation_sensitivity_final*p_h)+(1-validation_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_vali(i)==0)&&(Smear_info_vali(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_vali(i,1)= (validation_sensitivity_final*p_h)/((validation_sensitivity_final*p_h)+(1-validation_specificity_final)*(1-p_h));
            end
    
            if (Colp_info_vali(i)==0)&&(Smear_info_vali(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_vali(i,1)= (validation_sensitivity_final*p_h)/((validation_sensitivity_final*p_h)+(1-validation_specificity_final)*(1-p_h));
            end
    
    
        end
    
        if (score_vali(i,2)<threshold_best_final) % model prediction is healthy case
            % 
            if (Colp_info_vali(i)==1)&&(Smear_info_vali(i)==1) %  colp =1
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_11;
                AA_prediction_results_with_bayes_colp_smear_vali(i,1)= ((1-validation_sensitivity_final)*p_h)/(((1-validation_sensitivity_final)*p_h)+validation_specificity_final*(1-p_h));
            end
    
             if (Colp_info_vali(i)==1)&&(Smear_info_vali(i)==0) %  colp =0
                % colp =1      结合统计学患癌的概率
                p_h = p_h_colp_smear_10;
                AA_prediction_results_with_bayes_colp_smear_vali(i,1)= ((1-validation_sensitivity_final)*p_h)/(((1-validation_sensitivity_final)*p_h)+validation_specificity_final*(1-p_h));
             end
    
             if (Colp_info_vali(i)==0)&&(Smear_info_vali(i)==0) %  colp =0 smear 0
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_00;
                AA_prediction_results_with_bayes_colp_smear_vali(i,1)= ((1-validation_sensitivity_final)*p_h)/(((1-validation_sensitivity_final)*p_h)+validation_specificity_final*(1-p_h));
            end
    
            if (Colp_info_vali(i)==0)&&(Smear_info_vali(i)==1) %  colp =0 smear 1
                % colp =0      结合统计学患癌的概率
                p_h = p_h_colp_smear_01;
                AA_prediction_results_with_bayes_colp_smear_vali(i,1)= ((1-validation_sensitivity_final)*p_h)/(((1-validation_sensitivity_final)*p_h)+validation_specificity_final*(1-p_h));
            end
        end
    end

    [threshold_best_final_vali_Bayes_Colp_Smear, nono , nono] = threshold_selection(AA_prediction_results_with_bayes_colp_smear_vali, Y_vali);


    [accuracy_test_Colp_Smear,recall_test_Colp_Smear,specificity_test_Colp_Smear,sensitivity_test_Colp_Smear]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_colp_smear,threshold_best_final_vali_Bayes_Colp_Smear, Y_test);
    [accuracy_test_Colp_Smear_London,recall_test_Colp_Smear_London,specificity_test_Colp_Smear_London,sensitivity_test_Colp_Smear_London]             =  ConfusionMatrix_cal(AA_prediction_results_with_bayes_colp_smear_London,threshold_best_final_vali_Bayes_Colp_Smear,Y_test_Group_2);
    
    AAA_FINAL_METRICS_SAVE(seed_nn,1:3) = [AUC_test,specificity_test,sensitivity_test] ;
    AAA_FINAL_METRICS_SAVE(seed_nn,4:6) = [AUC_test_add_Bayes_colp_smear,specificity_test_Colp_Smear,sensitivity_test_Colp_Smear];
    AAA_FINAL_METRICS_SAVE(seed_nn,7:9) = [AUC_test_London,specificity_test_London,sensitivity_test_London];
    AAA_FINAL_METRICS_SAVE(seed_nn,10:12) = [AUC_test_add_Bayes_colp_smear_London, specificity_test_Colp_Smear_London, sensitivity_test_Colp_Smear_London];


end

AAA_compare = [];
%% calculate the CI mean and std value
for i =1:12
     [mean_val,std_val,ci_lower,ci_upper] = CI_cal(AAA_FINAL_METRICS_SAVE(:,i));
     AAA_compare(i,1) = mean_val;
     AAA_compare(i,2) = std_val;
     AAA_compare(i,3) = ci_lower;
     AAA_compare(i,4) = ci_upper;
end

save('./AA_save_AUC_SVM_Cervical_ColpSmear.mat','AAA_FINAL_METRICS_SAVE')
















