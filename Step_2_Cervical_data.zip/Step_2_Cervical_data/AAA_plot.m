clc
clear

% run the sub plot mat file one by one
% DT
AA_Main_plot_DT

AA_Main_plot_RF


AA_Main_plot_SVM


AA_Main_plot_MLP