clc
clear
%% calculate the P-value

%% results based on ML and our method
A1 = load('../AA_save_AUC_MLP_Cervical_Smear.mat');

%% results based on ML without bayes
A2 = load('../补充实验1_noBayes/AA_save_AUC_MLP_Cervical_Smear_NoBayes.mat');


%% Group1

% AUC vs 1 2 3
% our method
p_AUC1 = signrank(A1.AAA_FINAL_METRICS_SAVE(:,1),...
                       A1.AAA_FINAL_METRICS_SAVE(:,4) );
% ML no bayes
p_AUC2 = signrank(A1.AAA_FINAL_METRICS_SAVE(:,1),...
                       A2.AAA_FINAL_METRICS_SAVE(:,1) );



% Speci vs 1 2 3
% our method
p_Speci1 = signrank(A1.AAA_FINAL_METRICS_SAVE(:,2),...
                       A1.AAA_FINAL_METRICS_SAVE(:,5) );
% ML no bayes
p_Speci2 = signrank(A1.AAA_FINAL_METRICS_SAVE(:,2),...
                       A2.AAA_FINAL_METRICS_SAVE(:,2) );


% Sensi vs 1 2 3
% our method
p_Sensi1 = signrank(A1.AAA_FINAL_METRICS_SAVE(:,3),...
                       A1.AAA_FINAL_METRICS_SAVE(:,6) );
% ML no bayes
p_Sensi2 = signrank(A1.AAA_FINAL_METRICS_SAVE(:,3),...
                       A2.AAA_FINAL_METRICS_SAVE(:,3) );









%% Group2

% AUC vs 1 2 3
% our method
p_AUC1_London = signrank(A1.AAA_FINAL_METRICS_SAVE(:,1+6),...
                       A1.AAA_FINAL_METRICS_SAVE(:,4+6) );
% ML no bayes
p_AUC2_London = signrank(A1.AAA_FINAL_METRICS_SAVE(:,1+6),...
                       A2.AAA_FINAL_METRICS_SAVE(:,1+6) );



% Speci vs 1 2 3
% our method
p_Speci1_London = signrank(A1.AAA_FINAL_METRICS_SAVE(:,2+6),...
                       A1.AAA_FINAL_METRICS_SAVE(:,5+6) );
% ML no bayes
p_Speci2_London = signrank(A1.AAA_FINAL_METRICS_SAVE(:,2+6),...
                       A2.AAA_FINAL_METRICS_SAVE(:,2+6) );


% Sensi vs 1 2 3
% our method
p_Sensi1_London = signrank(A1.AAA_FINAL_METRICS_SAVE(:,3+6),...
                       A1.AAA_FINAL_METRICS_SAVE(:,6+6) );
% ML no bayes
p_Sensi2_London = signrank(A1.AAA_FINAL_METRICS_SAVE(:,3+6),...
                       A2.AAA_FINAL_METRICS_SAVE(:,3+6) );
