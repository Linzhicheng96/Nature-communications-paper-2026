clc
clear
%% load data ---------------------------------------------------------------------------------------------------------
% Group 1
load('../../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_Cancer_data_coleModel_MaxDiffMean.mat')
load('../../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_NonCancer_data_coleModel_MaxDiffMean.mat')
load('../../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_cancer_data_and_info.mat')
load('../../../data/cervical data/postprocessed_by_Lin/Cervical_Group_1_non_cancer_data_and_info.mat')
% Group 2
load('../../../data/cervical data London/postprocessed_by_Lin/Cervical_Group_2_coleModel_MaxDiffMean_112.mat')
% data filtering ----------------------------------------------------------------------------------------------------
% Group 2
G2_cancer          = cat(2,Cervical_Group_2_cancer_MeanValues,          Cervical_Group_2_cancer_MaxDiff);
G2_non_cancer = cat(2,Cervical_Group_2_non_cancer_MeanValues,Cervical_Group_2_non_cancer_MaxDiff);
X_test_Group_2 = cat(1,G2_non_cancer,G2_cancer);
Y_test_Group_2 = cat(1,zeros(93,1),        ones(19,1));
Group_2_Colp_info     =cat(1,Cervical_Group_2_non_cancer_info.Colp,    Cervical_Group_2_cancer_info.Colp);
Group_2_Smear_info  =cat(1,Cervical_Group_2_non_cancer_info.Smear,Cervical_Group_2_cancer_info.Smear);
Colp_info_test_London = Group_2_Colp_info;
Smear_info_test_London = Group_2_Smear_info;
%% Group 1
G1_cancer          = cat(2,Cervical_Group_1_cancer_MeanValues,          Cervical_Group_1_cancer_MaxDiff);
G1_non_cancer = cat(2,Cervical_Group_1_non_cancer_MeanValues,Cervical_Group_1_non_cancer_MaxDiff);
%% ----------------------------------------------------------------------------------------------------------------------
% the best pair of hyper-para


AAA_FINAL_METRICS_SAVE = zeros(100,9);
%  AUC_test,                                    specificity_test,                    sensitivity_test,
%  AUC_test_add_Bayes_G1,       specificity_test_G1,             sensitivity_test_G1,
%  AUC_test_add_Bayes_G2,       specificity_test_G2,             sensitivity_test_G2,


%%
X_test_Group_2 = cat(2,X_test_Group_2,Smear_info_test_London,Colp_info_test_London);

for seed_nn = 1:100
    fprintf('the round is in %d \n',seed_nn);  rng(seed_nn);  index_record_line = 1;
    %% split  Group1  to training, validation and test dataset ------------------------------------------------------
    % cancer data 528                 422:53:53
    % non cancer data 1149      919:115:115
    indices_1 = randperm(528);
    Indices_train_1 = indices_1(1:422);
    Indices_vali_1   = indices_1(423:475);
    Indices_test_1   = indices_1(476:end);

    cancer_data_train                 = G1_cancer(Indices_train_1,:);
    cancer_data_vali                   = G1_cancer(Indices_vali_1,:);
    cancer_data_test                  =  G1_cancer(Indices_test_1,:);
    cancer_data_train_colp      = Cervical_Group_1_cancer_info.Colp_list(Indices_train_1);
    cancer_data_vali_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_vali_1);
    cancer_data_test_colp        = Cervical_Group_1_cancer_info.Colp_list(Indices_test_1);
    cancer_data_train_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_train_1);
    cancer_data_vali_smear  = Cervical_Group_1_cancer_info.Smear_list(Indices_vali_1);
    cancer_data_test_smear   = Cervical_Group_1_cancer_info.Smear_list(Indices_test_1);

    indices_0 = randperm(1149);
    Indices_train_0 = indices_0(1:919);
    Indices_vali_0   = indices_0(920:1034);
    Indices_test_0 = indices_0(1035:end);

    non_cancer_data_train              = G1_non_cancer(Indices_train_0,:);
    non_cancer_data_vali                = G1_non_cancer(Indices_vali_0,:);
    non_cancer_data_test                = G1_non_cancer(Indices_test_0,:);
    non_cancer_data_train_colp     = Cervical_Group_1_non_cancer_info.Colp_list(Indices_train_0);
    non_cancer_data_vali_colp       = Cervical_Group_1_non_cancer_info.Colp_list(Indices_vali_0);
    non_cancer_data_test_colp       = Cervical_Group_1_non_cancer_info.Colp_list(Indices_test_0);
    non_cancer_data_train_smear  = Cervical_Group_1_non_cancer_info.Smear_list(Indices_train_0);
    non_cancer_data_vali_smear    = Cervical_Group_1_non_cancer_info.Smear_list(Indices_vali_0);
    non_cancer_data_test_smear    = Cervical_Group_1_non_cancer_info.Smear_list(Indices_test_0);

    X_train = cat(1,non_cancer_data_train ,cancer_data_train); 
    Y_train = cat(1,zeros(919,1),ones(422,1));
    X_vali = cat(1,non_cancer_data_vali ,cancer_data_vali); 
    Y_vali = cat(1,zeros(115,1),ones(53,1));
    X_test = cat(1,non_cancer_data_test ,cancer_data_test);       
    Y_test = cat(1,zeros(115,1),ones(53,1));

    Colp_info_train = cat(1,non_cancer_data_train_colp,cancer_data_train_colp);
    Colp_info_vali = cat(1,non_cancer_data_vali_colp,cancer_data_vali_colp);
    Colp_info_test = cat(1,non_cancer_data_test_colp,cancer_data_test_colp);
    Smear_info_train = cat(1,non_cancer_data_train_smear,cancer_data_train_smear);
    Smear_info_vali = cat(1,non_cancer_data_vali_smear,cancer_data_vali_smear);
    Smear_info_test = cat(1,non_cancer_data_test_smear,cancer_data_test_smear);

    %%
    %% 直接用Smear 和数据联合
    X_train = cat(2,X_train,Smear_info_train,Colp_info_train);
    X_vali = cat(2,X_vali,Smear_info_vali,Colp_info_vali);
    X_test = cat(2,X_test,Smear_info_test,Colp_info_test);

    %% ----------------------------------------------------------------------------------------------------------------------

    treeModel = fitcnet(X_train, Y_train, ...
                                        'Standardize', true, ...
                                        'LayerSizes', [10], ...  % 两层隐藏层，分别有 10 和 5 个神经元
                                        'Activations', 'relu');     % 可选：'relu', 'tanh', 'sigmoid'


    [Y_pred_train,score_train] = predict(treeModel, X_train);
    [Y_pred_vali,  score_vali] = predict(treeModel, X_vali);
    [Y_pred_test,score_test]    = predict(treeModel, X_test);
    [Y_pred_test_London,score_test_London]    = predict(treeModel, X_test_Group_2);

    [x_, y_, T_, AUC_vali] = perfcurve(Y_test, score_vali(:,2), 1);
    [x_, y_, T_, AUC_test] = perfcurve(Y_test, score_test(:,2), 1);
    [x_, y_, T_, AUC_test_London] = perfcurve(Y_test_Group_2, score_test_London(:,2), 1);

    %% ------------------------------------------------------------------------------------------------
    %% step 1
    % find the best threshold based on 'validation' data
    % to make the Yuden score on the validation results to be the best
    % J = Sensitivity + Specificity -1
    [threshold_best_final, validation_specificity_final ,validation_sensitivity_final] = threshold_selection(score_vali(:,2), Y_vali);
    %% step 2
    % calculate the metrics of test set
    [accuracy_test,recall_test ,specificity_test,sensitivity_test] = ConfusionMatrix_cal(score_test(:,2),threshold_best_final,Y_test);
    [accuracy_test_London,recall_test_London ,specificity_test_London,sensitivity_test_London] = ConfusionMatrix_cal(score_test_London(:,2),threshold_best_final,Y_test_Group_2);

    
    AAA_FINAL_METRICS_SAVE(seed_nn,1:3) = [AUC_test,specificity_test,sensitivity_test] ;
%     AAA_FINAL_METRICS_SAVE(seed_nn,4:6) = [AUC_test_add_Bayes_colp_smear,specificity_test_Colp_Smear,sensitivity_test_Colp_Smear];
    AAA_FINAL_METRICS_SAVE(seed_nn,7:9) = [AUC_test_London,specificity_test_London,sensitivity_test_London];
%     AAA_FINAL_METRICS_SAVE(seed_nn,10:12) = [AUC_test_add_Bayes_colp_smear_London, specificity_test_Colp_Smear_London, sensitivity_test_Colp_Smear_London];


end

AAA_compare = [];
%% calculate the CI mean and std value
for i =1:9
     [mean_val,std_val,ci_lower,ci_upper] = CI_cal(AAA_FINAL_METRICS_SAVE(:,i));
     AAA_compare(i,1) = mean_val;
     AAA_compare(i,2) = std_val;
     AAA_compare(i,3) = ci_lower;
     AAA_compare(i,4) = ci_upper;
end

save('./AA_save_AUC_MLP_Cervical_ColpSmear_NoBayes.mat','AAA_FINAL_METRICS_SAVE')
















